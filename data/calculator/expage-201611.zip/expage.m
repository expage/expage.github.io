% Wrapper script for 10Be and 26Al exposure age calculator.
% Read and fix input, use get_al_be_age to calculate exposure ages, and fix and write output.
% Jakob Heyman - 2015-2016

clear all;

tic();

% What version is this?
ver = '201611';

% read input file
[samplein.sample_name,samplein.lat,samplein.long,samplein.elv,samplein.aa,samplein.thick,samplein.rho,samplein.othercorr,samplein.E,samplein.N10,samplein.delN10,samplein.be_stds,samplein.N26,samplein.delN26,samplein.al_stds,samplein.samplingyr] = textread('input.txt','%s %n %n %n %s %n %n %n %n %n %n %s %n %n %s %n');

% fix strings in input
samplein.sample_name = strvcat(samplein.sample_name);
samplein.aa = strvcat(samplein.aa);
samplein.be_stds = strvcat(samplein.be_stds);
samplein.al_stds = strvcat(samplein.al_stds);

% run and load al_be constants
make_al_be_consts;
load al_be_consts;

% run and load LSD consts
make_consts_LSD;
load consts_LSD;

% constants
P_ref_nu10 = al_be_consts.P10_ref_nu; delP_ref_nu10 = al_be_consts.delP10_ref_nu;
P_ref_nu26 = al_be_consts.P26_ref_nu; delP_ref_nu26 = al_be_consts.delP26_ref_nu;
% Decay constant
l10 = al_be_consts.l10; dell10 = al_be_consts.dell10;
l26 = al_be_consts.l26; dell26 = al_be_consts.dell26;

% convert 10Be concentrations according to standards
for i = 1:numel(samplein.N10);
	be_mult(i,1) = al_be_consts.be_stds_cfs(strmatch(samplein.be_stds(i,:),al_be_consts.be_stds_names,'exact'));
end;

samplein.N10 = samplein.N10 .* be_mult;
samplein.delN10 = samplein.delN10 .* be_mult;

% convert 26Al concentrations according to standards
for i = 1:numel(samplein.N26);
	al_mult(i,1) = al_be_consts.al_stds_cfs(strmatch(samplein.al_stds(i,:),al_be_consts.al_stds_names,'exact'));
end;

samplein.N26 = samplein.N26 .* al_mult;
samplein.delN26 = samplein.delN26 .* al_mult;

% initial Lsp for simple age calculation
Lsp1 = al_be_consts.Lsp;

% pick out samples one by one
for i = 1:numel(samplein.lat);
	sample.sample_name = samplein.sample_name(i,:);
	sample.lat = samplein.lat(i);
	sample.long = samplein.long(i);
	sample.elv = samplein.elv(i);
	sample.aa = samplein.aa(i,:);
	sample.thick = samplein.thick(i);
	sample.rho = samplein.rho(i);
	sample.othercorr = samplein.othercorr(i);
	sample.E = samplein.E(i);
	sample.N10 = samplein.N10(i);
	sample.delN10 = samplein.delN10(i);
	sample.be_stds = samplein.be_stds(i,:);
	sample.N26 = samplein.N26(i);
	sample.delN26 = samplein.delN26(i);
	sample.al_stds = samplein.al_stds(i,:);
	sample.samplingyr = samplein.samplingyr(i);
	
	if sample.N10 + sample.delN10 + sample.N26 + sample.delN26 > 0;
		fprintf(1,'%.0f. %s',i,num2str(sample.sample_name))
		
		% define sample site atmospheric pressure
		if (strcmp(sample.aa,'std'));
			sample.pressure = ERA40atm(sample.lat,sample.long,sample.elv);
		elseif (strcmp(sample.aa,'ant'));
			sample.pressure = antatm(sample.elv);
		elseif (strcmp(sample.aa,'pre'));
			sample.pressure = sample.elv;
		end;
		
		% Initial thickness scaling factor for simple age calculation
		if sample.thick > 0;
			thickSF = thickness(sample.thick,Lsp1,sample.rho);
		else
			thickSF = 1;
		end;
		
		% Find P scaling factor according to Stone/Lal
		P_St_SF = stone2000(sample.lat,sample.pressure,1) * thickSF * sample.othercorr;
		
		% Set nucl and mt to 0 for both 10/26
		nucl10 = 0; nucl26 = 0; mt10 = 0; mt26 = 0;
		
		% if 10Be measured: calculate max time
		if (sample.N10 + sample.delN10) > 0;
			nucl10 = 1;
			
			% Find P according to Stone/Lal
			% no muon production here!
			% P_ref_nu used as ref prod rate
			P_St10 = P_ref_nu10 * P_St_SF;
			A10 = l10 + sample.rho * sample.E ./Lsp1;

			if (sample.N10 >= (P_St10./A10));
				% if appears to be saturated in simple-age-world, simple age equation
				% would evaluate to NaN. Avoid this.
				% set results to -1; this flags it
				t_simple10 = -1;
			else;
				% Actually do calculation if possible
				t_simple10 = (-1/A10)*log(1-(sample.N10 * A10 / P_St10));
			end;
			
			% max time (mt10) for 10Be in LSDfix
			mt10 = t_simple10 .* 1.5;
			
			% clip to limit computations...
			if mt10 < 0; % Saturated WRT simple age - use full tv
				mt10 = 1e7;
			elseif  mt10 < 12060;
				mt10 = 12060; % Don't allow unreasonably short times
			elseif mt10 > 1e7;
				mt10 = 1e7;
			end;
		end;
		
		% if 26Al measured: calculate max time
		if (sample.N26 + sample.delN26) > 0;
			nucl26 = 1;
			
			% Find P according to Stone/Lal
			% no muon production here!
			% P_ref_nu used as ref prod rate
			P_St26 = P_ref_nu26 * P_St_SF;
			A26 = l26 + sample.rho * sample.E ./Lsp1;

			if (sample.N26 >= (P_St26./A26));
				% if appears to be saturated in simple-age-world, simple age equation
				% would evaluate to NaN. Avoid this.
				% set results to -1; this flags it
				t_simple26 = -1;
			else;
				% Actually do calculation if possible
				t_simple26 = (-1/A26)*log(1-(sample.N26 * A26 / P_St26));
			end;
			
			% max time (mt26) for 26Al in LSDfix
			mt26 = t_simple26 .* 1.5;
			
			% clip to limit computations...
			if mt26 < 0; % Saturated WRT simple age - use full tv
				mt26 = 1e7;
			elseif  mt26 < 12060;
				mt26 = 12060; % Don't allow unreasonably short times
			elseif mt26 > 1e7;
				mt26 = 1e7;
			end;
		end;
		
		% pick largest of mt10 and mt26 as max time
		mt = max(mt10,mt26);
		
		% catch for negative longitudes before Rc interpolation
		if sample.long < 0; sample.long = sample.long + 360;end;
		
		% Age Relative to t0=2010 - LSD tv from LSDfix
		% tv = [0:10:50 60:100:50060 51060:1000:2000060 logspace(log10(2001060),7,200)];
		
		% Fix w,Rc,SPhi, for sp and mu prod rate scaling
		LSDfix = LSD_fix(sample.lat,sample.long,mt,-1,consts);
		
		% time vector tv1
		tv1 = LSDfix.tv;

		% adjust tv, Rc, and SPhi to sampling year
		if sample.samplingyr <= 2010;
			clipidx = min(find(tv1 > 2010-sample.samplingyr));
			tv = [2010-sample.samplingyr tv1(clipidx:end)];
			Rc = interp1(tv1,LSDfix.Rc,tv);
			SPhi = interp1(tv1,LSDfix.SPhi,tv);
			tv = tv - 2010 + sample.samplingyr;
		else; % assume 2010 value for all years >2010
			Rc = [LSDfix.Rc(1) LSDfix.Rc];
			SPhi = [LSDfix.SPhi(1) LSDfix.SPhi];
			tv = [0 (tv1 + sample.samplingyr - 2010)];
		end;
		
		% Production from muons
		if sample.E <= 0;
			P_mu = P_mu_LSD(sample.thick.*sample.rho./2,sample.pressure,LSDfix.RcEst,consts.SPhiInf,nucl10,nucl26,consts,'no');
			if nucl10 == 1; sample.mu10 = P_mu.Be .* sample.othercorr; end;
			if nucl26 == 1; sample.mu26 = P_mu.Al .* sample.othercorr; end;
		else;
			tv_z = (tv.*sample.E + sample.thick./2) .* sample.rho; % time - depth vect (g/cm^2)
			if nucl10 == 1;
				aged10 = sample.E .* t_simple10; % depth at t simple
				maxd10 = sample.E .* mt10; % max depth
				mu_z10 = ([linspace(0,aged10,9) maxd10] + sample.thick./2) .* sample.rho; % d vect (g/cm^2)
				if mu_z10(end) < tv_z(end); mu_z10(end+1) = tv_z(end); end; % add value at end of mu_z if shorter than tv_z
				P_mu_d10 = P_mu_LSD(mu_z10,sample.pressure,LSDfix.RcEst,consts.SPhiInf,1,0,consts,'no'); % Pmu at d
				sample.mu10 = interp1(mu_z10,P_mu_d10.Be,tv_z,'pchip') .* sample.othercorr; % P_mu over time
			end;
			if nucl26 == 1;
				aged26 = sample.E .* t_simple26; % depth at t simple
				maxd26 = sample.E .* mt26; % max depth
				mu_z26 = ([linspace(0,aged26,9) maxd26] + sample.thick./2) .* sample.rho; % d vect (g/cm^2)
				if mu_z26(end) < tv_z(end); mu_z26(end+1) = tv_z(end); end; % add value at end of mu_z if shorter than tv_z
				P_mu_d26 = P_mu_LSD(mu_z26,sample.pressure,LSDfix.RcEst,consts.SPhiInf,0,1,consts,'no'); % Pmu at d
				sample.mu26 = interp1(mu_z26,P_mu_d26.Al,tv_z,'pchip') .* sample.othercorr; % P_mu over time
			end;
		end;
		
		% sp and nu spallation production scaling
		%LSDsp = LSDspal(sample.pressure,LSDfix.Rc,LSDfix.SPhi,LSDfix.w,nucl10,nucl26);
		LSDnu = LSDspal(sample.pressure,Rc,SPhi,LSDfix.w,nucl10,nucl26,consts);
		
		% interpolate Lsp using CRONUScalc method (Sato 2008; Marrero et al. 2016)
		Lsp = rawattenuationlength(sample.pressure,Rc);
		
		% Thickness scaling factor.
		if sample.thick > 0;
			thickSF = thickness(sample.thick,Lsp,sample.rho);
		else
			thickSF = 1;
		end;
		
		if nucl10 == 1;
			% sample surface spallation production rate over time
			sample.nu10 = LSDnu.Be.*P_ref_nu10.*thickSF.*sample.othercorr;
		end;
		
		if nucl26 == 1;
			% sample surface spallation production rate over time
			sample.nu26 = LSDnu.Al.*P_ref_nu26.*thickSF.*sample.othercorr;
		end;
		
		sample.tv = tv;
		sample.Lsp = Lsp;
		
		results = get_al_be_age(sample,al_be_consts,nucl10,nucl26);
		
		if nucl10 == 1;
			output10(i,1) = results.t_nu10;
			output10(i,2) = results.delt_ext_nu10;
			output10(i,3) = results.delt_int_nu10;
			fprintf(1,'   10Be = %.0f %s %.0f yr',output10(i,1),char(241),output10(i,2))
		end;
		
		if nucl26 == 1;
			output26(i,1) = results.t_nu26;
			output26(i,2) = results.delt_ext_nu26;
			output26(i,3) = results.delt_int_nu26;
			fprintf(1,'   26Al = %.0f %s %.0f yr',output26(i,1),char(241),output26(i,2))
		end;
		fprintf(1,'\n')
	end;
	
	clear sample;
end;

% if any 10Be: fix and save expages10.txt
if sum(samplein.N10 + samplein.delN10)>0;
	if numel(output10(:,1))<numel(samplein.N10);
	%	output10(numel(samplein.N10),6) = 0;
		output10(numel(samplein.N10),3) = 0;
	end;
	
	nanmatr = output10>0;
	output10 = output10.*nanmatr./nanmatr;
	
	out10 = fopen('expages10.txt','w');
	dlmwrite('expages10.txt',output10,'delimiter','\t','precision','%.0f');
	fclose(out10);
end;

% if any 26Al: fix and save expages26.txt
if sum(samplein.N26 + samplein.delN26)>0;
	if numel(output26(:,1))<numel(samplein.N26);
	%	output26(numel(samplein.N26),6) = 0;
		output26(numel(samplein.N26),3) = 0;
	end;
	
	nanmatr = output26>0;
	output26 = output26.*nanmatr./nanmatr;
	
	out26 = fopen('expages26.txt','w');
	dlmwrite('expages26.txt',output26,'delimiter','\t','precision','%.0f');
	fclose(out26);
end;

toc()
