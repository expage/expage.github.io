% Wrapper script for 10Be and 26Al erosion rate calculator.
% Read and fix input, use get_al_be_erosion to calculate erosion rates, and fix and write output.
% Jakob Heyman - 2015-2016

clear all;

tic();

% What version is this?
ver = '201611';

% read input file
[samplein.sample_name,samplein.lat,samplein.long,samplein.elv,samplein.aa,samplein.thick,samplein.rho,samplein.othercorr,samplein.N10,samplein.delN10,samplein.be_stds,samplein.N26,samplein.delN26,samplein.al_stds,samplein.samplingyr] = textread('input.txt','%s %n %n %n %s %n %n %n %n %n %s %n %n %s %n');

% fix strings in input
samplein.sample_name = strvcat(samplein.sample_name);
samplein.aa = strvcat(samplein.aa);
samplein.be_stds = strvcat(samplein.be_stds);
samplein.al_stds = strvcat(samplein.al_stds);

% run and load al_be constants
make_al_be_consts;
load al_be_consts;

% run and load LSD consts
make_consts_LSD;
load consts_LSD;

% convert 10Be concentrations according to standards
for i = 1:numel(samplein.N10);
	be_mult(i,1) = al_be_consts.be_stds_cfs(strmatch(samplein.be_stds(i,:),al_be_consts.be_stds_names,'exact'));
end;

samplein.N10 = samplein.N10 .* be_mult;
samplein.delN10 = samplein.delN10 .* be_mult;

% convert 26Al concentrations according to standards
for i = 1:numel(samplein.N26);
	al_mult(i,1) = al_be_consts.al_stds_cfs(strmatch(samplein.al_stds(i,:),al_be_consts.al_stds_names,'exact'));
end;

samplein.N26 = samplein.N26 .* al_mult;
samplein.delN26 = samplein.delN26 .* al_mult;

% pick out samples one by one
for i = 1:numel(samplein.lat);
	sample.sample_name = samplein.sample_name(i,:);
	sample.lat = samplein.lat(i);
	sample.long = samplein.long(i);
	sample.elv = samplein.elv(i);
	sample.aa = samplein.aa(i,:);
	sample.thick = samplein.thick(i);
	sample.rho = samplein.rho(i);
	sample.othercorr = samplein.othercorr(i);
	sample.N10 = samplein.N10(i);
	sample.delN10 = samplein.delN10(i);
	sample.be_stds = samplein.be_stds(i,:);
	sample.N26 = samplein.N26(i);
	sample.delN26 = samplein.delN26(i);
	sample.al_stds = samplein.al_stds(i,:);
	sample.samplingyr = samplein.samplingyr(i);
	
	if sample.N10 + sample.delN10 + sample.N26 + sample.delN26 > 0;
		fprintf(1,'%.0f. %s',i,num2str(sample.sample_name))
		
		% define sample site atmospheric pressure
		if (strcmp(sample.aa,'std'));
			sample.pressure = ERA40atm(sample.lat,sample.long,sample.elv);
		elseif (strcmp(sample.aa,'ant'));
			sample.pressure = antatm(sample.elv);
		elseif (strcmp(sample.aa,'pre'));
			sample.pressure = sample.elv;
		end;
		
		% catch for negative longitudes before Rc interpolation
		if sample.long < 0; sample.long = sample.long + 360; end;
		
		results = get_al_be_erosion(sample,al_be_consts,consts);
		
		% report
		if (sample.N10 + sample.delN10) > 0;
			output10(i,1) = results.EmMyr10;
			output10(i,2) = results.delE_ext10;
			output10(i,3) = results.delE_int10;
			fprintf(1,'   10Be = %.2f %s %.2f mm/ka',output10(i,1),char(241),output10(i,2))
		end;
		if (sample.N26 + sample.delN26) > 0;
			output26(i,1) = results.EmMyr26;
			output26(i,2) = results.delE_ext26;
			output26(i,3) = results.delE_int26;
			fprintf(1,'   26Al = %.2f %s %.2f mm/ka',output26(i,1),char(241),output26(i,2))
		end;
		fprintf(1,'\n')
	end;
	clear sample;
end;

if sum(samplein.N10 + samplein.delN10)>0;
	if numel(output10(:,1))<numel(samplein.N10);
		output10(numel(samplein.N10),3) = 0;
	end;
	
	nanmatr = abs(output10)>0;
	output10 = output10.*nanmatr./nanmatr;
	Ematr = output10>0;
	output10 = abs(output10.*Ematr);
	
	out10 = fopen('erosion10.txt','w');
	dlmwrite('erosion10.txt',output10,'delimiter','\t','precision','%.3f');
	fclose(out10);
end;

if sum(samplein.N26 + samplein.delN26)>0;
	if numel(output26(:,1))<numel(samplein.N26);
		output26(numel(samplein.N26),3) = 0;
	end;
	
	nanmatr = abs(output26)>0;
	output26 = output26.*nanmatr./nanmatr;
	Ematr = output26>0;
	output26 = abs(output26.*Ematr);
	
	out26 = fopen('erosion26.txt','w');
	dlmwrite('erosion26.txt',output26,'delimiter','\t','precision','%.3f');
	fclose(out26);
end;

toc()
