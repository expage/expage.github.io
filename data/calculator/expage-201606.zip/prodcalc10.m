% Script for 10Be reference production rate calibration.
% Calibrate site reference 10Be production rate using chi-square minimization.
% Jakob Heyman - 2016

clear all;

% What version is this?
ver = '201606';

% min and max Pref
Pmin = 3;
Pmax = 5;

% read and fix input file
[samplein.sample_name,samplein.lat,samplein.long,samplein.elv,samplein.aa,samplein.thick,samplein.rho,samplein.othercorr,samplein.E,samplein.N10,samplein.delN10,samplein.be_stds,samplein.N26,samplein.delN26,samplein.al_stds,samplein.samplingyr,samplein.truet,samplein.deltruet] = textread('input.txt','%s %n %n %n %s %n %n %n %n %n %n %s %n %n %s %n %n %n');

samplein.sample_name = strvcat(samplein.sample_name);
samplein.aa = strvcat(samplein.aa);
samplein.be_stds = strvcat(samplein.be_stds);
samplein.al_stds = strvcat(samplein.al_stds);

% run and load constants
make_al_be_consts;
load al_be_consts;

consts = al_be_consts;

% make consts_LSD
make_consts_LSD;

% convert 10Be concentrations according to standards
for i = 1:numel(samplein.N10);
	be_mult(i,1) = consts.be_stds_cfs(strmatch(samplein.be_stds(i,:),consts.be_stds_names,'exact'));
end;

samplein.N10 = samplein.N10 .* be_mult;
samplein.delN10 = samplein.delN10 .* be_mult;

% convert 26Al concentrations according to standards
for i = 1:numel(samplein.N26);
	al_mult(i,1) = consts.al_stds_cfs(strmatch(samplein.al_stds(i,:),consts.al_stds_names,'exact'));
end;

samplein.N26 = samplein.N26 .* al_mult;
samplein.delN26 = samplein.delN26 .* al_mult;

% Be-10 decay constant and sp and mu attenuation approximation
l = consts.l10;
Lsp1 = consts.Lsp;

% make Pref vector
Pvect = [Pmin:0.01:Pmax];

% declare age and unc matrixes
% age_sp = []; unc_sp = [];
age_nu = []; unc_nu = [];
calage = []; calunc = [];

% nuclide is Be-10
nuclide = 10;

% Production rate for age estimate A
P_ref_St = consts.P10_ref_nu; delP_ref_St = consts.delP10_ref_nu;

% pick out samples one by one
for i = 1:numel(samplein.lat);
	i
	
	sample.sample_name = samplein.sample_name(i,:);
	sample.lat = samplein.lat(i);
	sample.long = samplein.long(i);
	sample.elv = samplein.elv(i);
	sample.aa = samplein.aa(i,:);
	sample.thick = samplein.thick(i);
	sample.rho = samplein.rho(i);
	sample.othercorr = samplein.othercorr(i);
	sample.E = samplein.E(i);
	sample.N10 = samplein.N10(i);
	sample.delN10 = samplein.delN10(i);
	sample.be_stds = samplein.be_stds(i,:);
	sample.N26 = samplein.N26(i);
	sample.delN26 = samplein.delN26(i);
	sample.al_stds = samplein.al_stds(i,:);
	sample.samplingyr = samplein.samplingyr(i,:);
	sample.truet = samplein.truet(i);
	sample.deltruet = samplein.deltruet(i);
	
	% define sample site atmospheric pressure
	if (strcmp(sample.aa,'std'));
		sample.pressure = ERA40atm(sample.lat,sample.long,sample.elv);
	elseif (strcmp(sample.aa,'ant'));
		sample.pressure = antatm(sample.elv);
	elseif (strcmp(sample.aa,'pre'));
		sample.pressure = sample.elv;
	end;
	
	% Atoms/g measurement
	N = sample.N10; delN = sample.delN10;
	
	% 1a. Initial thickness scaling factor for simple age calculation
	if sample.thick > 0;
		sample.thickSF = thickness(sample.thick,Lsp1,sample.rho);
	else
		sample.thickSF = 1;
	end;
	
	% 2. Make an initial guess at the age. This mainly serves to limit the
	% length of the forward calculation and speed things up slightly.
	% Find P according to Stone/Lal SF
	
	% Don't double-count muons in the following line
	S_St = stone2000(sample.lat,sample.pressure,1);
	% spallation production - no muon production here
	P_St = P_ref_St * sample.thickSF * sample.othercorr * S_St;
	A = l + sample.rho * sample.E ./Lsp1;
	
	if (N >= (P_St./A));
		% if appears to be saturated in simple-age-world, simple age equation
		% would evaluate to NaN. Avoid this.
		% set results to -1; this flags it
		t_simple = -1;
	else; 
		% Actually do calculation if possible
		t_simple = (-1/A)*log(1-(N * A / P_St));
	end;
	
	mt = t_simple .* 1.5; % mt is max time
	
	% catch for negative longitudes before Rc interpolation
	if sample.long < 0; sample.long = sample.long + 360;end;
	
	% clip to limit computations...
	if mt < 0; % Saturated WRT simple age - use full tv
		mt = 1e7;
	elseif  mt < 12060;
		mt = 12060; % Don't allow unreasonably short times
	elseif mt > 1e7; 
		mt = 1e7;
	end;
	
	% Fix w,Rc,SPhi, for mu,sp,nu prod rate scaling
	LSDfix = LSD_fix(sample.lat,sample.long,sample.pressure,mt,-1);
	
	% sp and Be production scaling
%	LSDsp = LSDspal(sample.pressure,LSDfix.Rc,LSDfix.SPhi,LSDfix.w,0);
	LSDnu = LSDspal(sample.pressure,LSDfix.Rc,LSDfix.SPhi,LSDfix.w,nuclide);
	
	% interpolate Lsp (Sato, 2008; Marrero et al., 2016)
	Lsp2 = rawattenuationlength(sample.pressure,LSDfix.Rc);

	% 1a. Thickness scaling factor.
	if sample.thick > 0;
		sample.thickSF1 = thickness(sample.thick,Lsp2,sample.rho);
	else 
		sample.thickSF = 1;
	end;
	
	% time vector tv - LSD
	tv1 = LSDfix.tv;
	
	% adjust tv and S to sampling year
	if sample.samplingyr <= 2010;
		clipidx = min(find(tv1 > 2010-sample.samplingyr));
		tv = [2010-sample.samplingyr tv1(clipidx:end)];
	%	S_sp = interp1(tv1,LSDsp.sp,tv);
		S_nu = interp1(tv1,LSDnu.Be,tv);
		Lsp = interp1(tv1,Lsp2,tv);
		if sample.thick > 0;
			sample.thickSF = interp1(tv1,sample.thickSF1,tv);
		end;
		tv = tv - 2010 + sample.samplingyr;
	else;
	%	S_sp = [LSDsp.sp(1) LSDsp.sp];
		S_nu = [LSDnu.Be(1) LSDnu.Be];
		Lsp = [Lsp2(1) Lsp2];
		if sample.thick > 0;
			sample.thickSF = [sample.thickSF1(1) sample.thickSF1];
		end;
		tv = [0 (tv1 + sample.samplingyr - 2010)];
	end;
	
	% For decay and erosion
	dcf = exp(-tv.*l); % decay factor;
	dpfs = exp(-tv.*sample.E.*sample.rho./Lsp); % spallation depth dependence
	
	% Production from muons
	if sample.E > 0;
		maxd = sample.E .* max(tv); % max depth
		mu_z = linspace(0,maxd,50).*sample.rho + sample.thick.*sample.rho./2; % depth vect (g/cm^2)
		P_mu_d = P_mu_LSD(mu_z,sample.pressure,LSDfix.RcEst,LSDfix.SPhiInf,nuclide,'no').*sample.othercorr; % Pmu at depth
		tv_z = tv.*sample.E.*sample.rho + sample.thick.*sample.rho./2; % time - depth vect (g/cm^2)
		P_mu = interp1(mu_z,P_mu_d,tv_z,'pchip'); % P_mu over time
	else;
		P_mu = P_mu_LSD((sample.thick.*sample.rho./2),sample.pressure,LSDfix.RcEst,LSDfix.SPhiInf,nuclide,'no').*sample.othercorr; % P_mu if no erosion
	end;
	
	% loop for Pref
	for j = 1:numel(Pvect);
		
		% sample prod rate
	%	P_sp = S_sp.*Pvect(j).*sample.thickSF.*sample.othercorr;
		P_nu = S_nu.*Pvect(j).*sample.thickSF.*sample.othercorr;
		
		% Calculate N(t) including decay and erosion
	%	N_sp = cumtrapz(tv,(P_sp.*dcf.*dpfs + P_mu.*dcf));
		N_nu = cumtrapz(tv,(P_nu.*dcf.*dpfs + P_mu.*dcf));
		
		% Look for saturation with respect to various scaling factors -- 
		% If not saturated, get the age by reverse-interpolation.
		% Note that this is not necessarily rigorous and doesn't attempt to take
		% account of uncertainties in deciding if a sample is saturated. If you
		% need rigorous analysis of close-to-saturation measurements, this code is
		% not for you.
		
		nstring='Be-10';
		
	%	if N > max(N_sp); 
	%		flag = ['Sample ' sample.sample_name ' -- ' nstring ' appears to be saturated WRT sp SF.'];
	%		results.flags = [results.flags '<br>' flag];
	%		t_sp = 0;
	%	else;
	%		t_sp = interp1(N_sp,tv,N);
	%	end;
		
		if N > max(N_nu); 
			flag = ['Sample ' sample.sample_name ' -- ' nstring ' appears to be saturated WRT nu SF.'];
			results.flags = [results.flags '<br>' flag];
			t_nu = 0;
		else;
			t_nu = interp1(N_nu,tv,N);
		end;
		
		% Error propagation scheme. 
		% This is highly simplified. We approximate the error by figuring out what the
		% effective production rate is (disregarding the special depth dependence
		% for muons) which gives the right age in the simple age equation. 
		% Error in this taken to be linear WRT the reference production rate.
		% Then we linearly propagate errors through the S.A.E. 
		% We ignore the nominal error in production by muons. This is OK
		% because it's small compared to the total error in the reference
		% production rate. Future versions will use Monte Carlo error analysis.
		
		% A with interpolated Lsp
		Lsp_avg = interp1(tv,cumtrapz(tv,Lsp),t_nu)./t_nu;
		A = l + sample.rho * sample.E ./Lsp_avg;
		
		% extract t, Pref, delPref for SF
		tt = t_nu;
		if tt < 10000000; % Not saturated, is an age
			% do most of computation
			FP = (N.*A)./(1 - exp(-A.*tt));
			dtdN = 1./(FP - N.*A);
			% make respective delt's
			delt_int_nu = sqrt(dtdN.^2 * delN.^2);
			FP_nu = FP;
		else; % t set to 10000000, was saturated - set unc to 1
			delt_int_nu = 1;
			FP_nu = 0;
		end;
		
		% fill age matrix
	%	age_sp(i,j) = t_sp;
		age_nu(i,j) = t_nu;
		
		% fill uncertainty matrix
	%	unc_sp(i,j) = delt_int_sp;
		unc_nu(i,j) = delt_int_nu;
	end;
	
	% fill calage and calunc matrix
	calage(i,:) = repmat(sample.truet,[1,numel(Pvect)]);
	calunc(i,:) = repmat(sample.deltruet,[1,numel(Pvect)]);
	
	clear sample;
end;

% calculate weighted ages for ages minus calage
% agetest_sp = sum((age_sp - calage)./unc_sp.^2)./sum(1./unc_sp.^2);
agetest_nu = sum((age_nu - calage)./unc_nu.^2)./sum(1./unc_nu.^2);

% pick out Pref
% Pref_sp = interp1(agetest_sp,Pvect,0);
Pref_nu = interp1(agetest_nu,Pvect,0);

% find individual sample age for Pref
for k = 1:numel(samplein.lat);
%	ageP_sample_sp(k,:) = interp1(Pvect,age_sp(k,:),Pref_sp);
	ageP_sample_nu(k,:) = interp1(Pvect,age_nu(k,:),Pref_nu);
end;

% find individual sample age unc for Pref
for k = 1:numel(samplein.lat);
%	uncP_sample_sp(k,:) = interp1(Pvect,unc_sp(k,:),Pref_sp);
	uncP_sample_nu(k,:) = interp1(Pvect,unc_nu(k,:),Pref_nu);
end;

% pick out exact chi square
% chisq_sp = 1/(numel(samplein.N10)-1) .* sum(((ageP_sample_sp - calage(:,1))./uncP_sample_sp).^2);
chisq_nu = 1/(numel(samplein.N10)-1) .* sum(((ageP_sample_nu - calage(:,1))./uncP_sample_nu).^2);

% calculate P value
Pvalue = 1 - chi2cdf(chisq_nu.*(numel(samplein.N10)-1),(numel(samplein.N10)-1));

% calculate reduced chi square for full Pvect
% chi_sp = 1/(numel(samplein.N10)-1) .* sum(((age_sp - calage)./unc_sp).^2);
chi_nu = 1/(numel(samplein.N10)-1) .* sum(((age_nu - calage)./unc_nu).^2);

% find minimum chi square and index
% [chimin_sp,idx_sp] = min(chi_sp);
[chimin_nu,idx_nu] = min(chi_nu);

% find low and high point of Pref based on chi square + 1
% low_sp = interp1(chi_sp(1:idx_sp),Pvect(1:idx_sp),chisq_sp+1);
low_nu = interp1(chi_nu(1:idx_nu),Pvect(1:idx_nu),chisq_nu+1);
% high_sp = interp1(chi_sp(idx_sp:end),Pvect(idx_sp:end),chisq_sp+1);
high_nu = interp1(chi_nu(idx_nu:end),Pvect(idx_nu:end),chisq_nu+1);

% calculate reference prod rate uncertainty (not including calib age unc) from low and high Pref values
% delP1_sp = (high_sp-low_sp)/2;
delP1_nu = (high_nu-low_nu)/2;

% calculate calib age unc part
calage_unc = mean(samplein.deltruet./samplein.truet);

% calculate total prod rate uncertainty
% delP_sp = sqrt(delP1_sp^2 + (calage_unc * Pref_sp)^2);
delP_nu = sqrt(delP1_nu^2 + (calage_unc * Pref_nu)^2);

% find individual sample Pref
for k = 1:numel(samplein.lat);
%	Pref_sample_sp(k) = interp1(age_sp(k,:),Pvect,samplein.truet(k));
	Pref_sample_nu(k) = interp1(age_nu(k,:),Pvect,samplein.truet(k));
end;

% find individual sample Pref uncertainty
for k = 1:numel(samplein.lat);
%	Pref_sampleunc_sp(k) = sqrt((interp1(Pvect,unc_sp(k,:),Pref_sample_sp(k)) / samplein.truet(k) * Pref_sample_sp(k))^2 + (calage_unc * Pref_sample_sp(k))^2);
	Pref_sampleunc_nu(k) = sqrt((interp1(Pvect,unc_nu(k,:),Pref_sample_nu(k)) / samplein.truet(k) * Pref_sample_nu(k))^2 + (calage_unc * Pref_sample_nu(k))^2);
end;


% plot probdens graphs
Pmin2 = Pmin - 0.5;
Pmax2 = Pmax + 0.5;
steg = 0.01;

medel = Pref_sample_nu';
stdav = sqrt(Pref_sampleunc_nu'.^2 - (calage_unc .* medel).^2);

Pvect2 = linspace (Pmin2, Pmax2, (Pmax2-Pmin2)/steg+1);

tidm = repmat(Pvect2, numel(medel), 1);
medelm = repmat(medel, 1, numel(Pvect2));
stdavm = repmat(stdav, 1, numel(Pvect2));

probdensmatr = normpdf(tidm, medelm, stdavm);

hold on;
for k = 1:numel(samplein.lat);
	plot(Pvect2',probdensmatr(k,:)','r');
end

plot(Pvect2',sum(probdensmatr)','k');

% plot Pref and unc
plot([Pref_nu-delP_nu,Pref_nu-delP_nu],[0,1],'b');
plot([Pref_nu,Pref_nu],[0,1],'b');
plot([Pref_nu+delP_nu,Pref_nu+delP_nu],[0,1],'b');

hold off;
% end plotting

% pick out individual sample P-ref and unc
for k = 1:numel(samplein.lat);
	output(k,1) = Pref_sample_nu(k);
	output(k,2) = Pref_sampleunc_nu(k);
%	output(k,3) = Pref_sample_sp(k);
%	output(k,4) = Pref_sampleunc_sp(k);
end;

% pick out full dataset P-ref, unc, and chisquare
output(end+1,1) = Pref_nu;
output(end,2) = delP_nu;
% output(end,3) = Pref_sp;
% output(end,4) = delP_sp;
output(end+1,1) = chisq_nu;
output(end,2) = Pvalue;
% output(end,3) = chisq_sp;

out10 = fopen('prodrate10.txt','w');
dlmwrite('prodrate10.txt',output,'delimiter','\t','precision','%.3f');
fclose(out10);

% Pref_sp = sprintf('%s %s %s   R-chisq = %s',num2str(Pref_sp),char(241),num2str(delP_sp),num2str(chisq_sp))
Pref_Be = sprintf('%s %s %s   R-chisq = %s   P-value = %s',num2str(Pref_nu),char(241),num2str(delP_nu),num2str(chisq_nu),num2str(Pvalue))

for k = 1:7;
	beep;
end
