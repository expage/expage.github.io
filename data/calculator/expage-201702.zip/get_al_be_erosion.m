function results = get_al_be_erosion(sample,albe_consts,consts);

% This function calculates the erosion rate for a sample by
% optimizing the forward model for E. It then packages the results.
%
% syntax : results = get_al_be_erosion(sample,albe_consts,nuclide);
%
% argument sample is the structure assembled upstream by erosion. 
%
% argument albe_consts is the al_be_consts structure derived from
% make_al_be_consts.m. Many required fields.
%
% argument consts is the LSD consts structure derived from
% make_consts_LSD.m. Many required fields.
% 
% results is a structure with fields:
% results.flags: Non-fatal error message string, mostly to do with saturation
% results.main_version: version of this function
% results.Pmu0: surface production rate due to muons (atoms/g/yr)
%
% Scaling-scheme-specific information:
% NOTE: in this version only nuclide-specific LSD scaling (Lifton et al. 2014) is used (nu)
%
% results.Egcm2yr: erosion rate (g/cm2/yr) -- order of scaling schemes is St,De,Du,Li,Lm
% results.EmMyr: erosion rate (m/Myr)
% results.delE_int: internal uncertainty on erosion rate (m/Myr)
% results.delE_ext: external uncertainty on erosion rate (m/Myr)
%
% Diagnostics:
%
% results.time_mu_precalc: time required to calculate P_mu(z) (s)
% results.fzero_status: 1x5 array containing fzero output flags
% results.fval: 1x5 array containing objective function values at solution
% results.time_fzero: 1x5 array containing optimization times
%
% Modidied by Jakob Heyman (jakob.heyman@gu.se) 2015-2017
% from code written by Greg Balco -- UW Cosmogenic Nuclide Lab
% balcs@u.washington.edu
% April, 2007
%
% Copyright 2001-2007, University of Washington
% All rights reserved
% Developed in part with funding from the National Science Foundation.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License, version 2,
% as published by the Free Software Foundation (www.fsf.org).

% What version is this?
ver = '201702';

% Set nucl to 0 for both 10/26
nucl10 = 0; nucl26 = 0;

% is 10Be measured?
if (sample.N10 + sample.delN10) > 0;
	nucl10 = 1;
	% Pref
	Pref10 = albe_consts.P10_ref_nu; delPref10 = albe_consts.delP10_ref_nu;
	% Decay constant
	l10 = albe_consts.l10; dell10 = albe_consts.dell10;
	% Atoms/g measurement
	N10 = sample.N10; delN10 = sample.delN10;
	% muon parameters
	sigma010 = consts.sigma0_10nu;
	delsigma010 = consts.delsigma0_10nu;
	k_negpartial10 = consts.k_negpartial10;
	delk_negpartial10 = consts.delk_negpartial10;
	fstar10 = consts.fstar10nu;
	delfstar10 = consts.delfstar10nu;
end;

% is 26Al measured?
if (sample.N26 + sample.delN26) > 0;
	nucl26 = 1;
	% Pref
	Pref26 = albe_consts.P26_ref_nu; delPref26 = albe_consts.delP26_ref_nu;
	% Decay constant
	l26 = albe_consts.l26; dell26 = albe_consts.dell26;
	% Atoms/g measurement
	N26 = sample.N26; delN26 = sample.delN26;
	% muon parameters
	sigma026 = consts.sigma0_26nu;
	delsigma026 = consts.delsigma0_26nu;
	k_negpartial26 = consts.k_negpartial26;
	delk_negpartial26 = consts.delk_negpartial26;
	fstar26 = consts.fstar26nu;
	delfstar26 = consts.delfstar26nu;
end;

% LSD prod rate ------------------------------------------------
% Age Relative to t0=2010 - LSD tv from LSD_fix
% tv = [0:10:50 60:100:50060 51060:1000:2000060 logspace(log10(2001060),7,200)];

% Fix w,Rc,SPhi, for sp and nu prod rate scaling 10 Ma back in time
LSDfix = LSD_fix(sample.lat,sample.long,1E7,-1,consts);

% time vector tv1
tv1 = LSDfix.tv;

% adjust tv, Rc, and SPhi to sampling year
if sample.samplingyr <= 2010;
	clipidx = min(find(tv1 > 2010-sample.samplingyr));
	tv = [2010-sample.samplingyr tv1(clipidx:end)];
	Rc = interp1(tv1,LSDfix.Rc,tv);
	SPhi = interp1(tv1,LSDfix.SPhi,tv);
	tv = tv - 2010 + sample.samplingyr;
else; % assume 2010 value for all years >2010
	Rc = [LSDfix.Rc(1) LSDfix.Rc];
	SPhi = [LSDfix.SPhi(1) LSDfix.SPhi];
	tv = [0 (tv1 + sample.samplingyr - 2010)];
end;

% interpolate Lsp (Sato, 2008; Marrero et al., 2016)
Lsp = rawattenuationlength(sample.pressure,Rc);
LspAv = trapz(tv,Lsp)./tv(end); % pick out average

% thickness scaling factor.
if sample.thick > 0;
	thickSF = thickness(sample.thick,Lsp,sample.rho);
else 
	thickSF = 1;
	if numel(tv) > 1; thickSF(1:numel(tv)) = 1; end;
end;

% spallation production scaling
LSDnu = LSDspal(sample.pressure,Rc,SPhi,LSDfix.w,nucl10,nucl26,consts);

% muon production
P_mu_full = P_mu_LSD(0,sample.pressure,LSDfix.RcEst,consts.SPhiInf,nucl10,nucl26,consts,'yes');

% Precompute P_mu(z) to ~200,000 g/cm2
% This log-spacing setup for the step size has relative accuracy near 
% 1e-3 at 1000 m/Myr erosion rate. 
% start at the mid-depth of the sample.
z_mu = [0 logspace(0,5.3,100)]+(sample.thick.*sample.rho./2);
P_mu_z = P_mu_LSD(z_mu,sample.pressure,LSDfix.RcEst,consts.SPhiInf,nucl10,nucl26,consts,'no');

if nucl10 == 1;
	P_nu10 = LSDnu.Be.*Pref10.*sample.othercorr;
	P_mu10 = (P_mu_full.P_fast10 + P_mu_full.P_neg10) .* sample.othercorr;
	P_fast10 = P_mu_full.P_fast10 .* sample.othercorr;
	P_neg10 = P_mu_full.P_neg10 .* sample.othercorr;
	P_mu_z10 = P_mu_z.Be .* sample.othercorr;
	
	% initial guess
	% average P_nu
	P_nu10Av = trapz(tv,P_nu10)./tv(end);
	P_temp10 = P_nu10Av + P_mu10;
	E_lal10 = LspAv.*(P_temp10./N10 - l10);
	x010 = E_lal10;

	% constants block for ET_objective.m
	c3.tv = tv;
	c3.z_mu = z_mu-(sample.thick.*sample.rho./2); % take 1/2 depth away again so t will match P
	c3.P_mu_z = P_mu_z10;
	c3.l = l10;
	c3.tsf = thickSF;
	c3.L = Lsp;
	
	% test saturation and ask fzero for the erosion rates.
	P_mud10 = interp1(z_mu,P_mu_z10,sample.thick.*sample.rho./2,'pchip'); % P_mu at 1/2 sample depth
	Ntest10 = cumtrapz(tv,(P_nu10.*exp(-tv.*l10) + P_mud10.*exp(-tv.*l10))); % zero erosion N
	if N10 > max(Ntest10); % if saturated
		x_nu10 = -1;
		diag_nu10 = 0;
		fval_nu10 = 0;
		exitflag_nu10 = 0;
	else;
		opts = optimset('fzero');
		opts = optimset(opts,'tolx',1e-8,'display','off');

		c3.P_sp_t = P_nu10;
		%tic;
		[x_nu10,fval_nu10,exitflag_nu10,output10] = ...
			fzero(@(x) ET_objective(x,c3,N10),x010,opts);
		%opt_time_nu = toc;
		% diagnostics
		diag_nu10 = ET_objective(x_nu10,c3,N10,'yes');
	end;
	
	% Error propagation
	% Common information
	Pmu010 = P_mu_z10(1);
	delPfast10 = P_fast10 .* (delsigma010 ./ sigma010);
	delPneg10 = P_neg10 .* sqrt((delk_negpartial10 ./ k_negpartial10)^2 + (delfstar10 ./ fstar10)^2);
	delPmu010 = sqrt(delPfast10.^2 + delPneg10.^2);
	L = LspAv;
	
	% SF - varying variable assignments
	diag10 = diag_nu10;
	thisx10 = x_nu10;
	rel_delP010 = delPref10./Pref10;
	
	% Conditional on actually having a result --
	% this is the saturation check
	if thisx10 > 0;
		% find what Lmu ought to be 
		Lmu10 = thisx10 ./ ((Pmu010./diag10.Nmu) - l10);
		
		% Find what P0 ought to be
		Psp010 = diag10.Nsp.*(l10 + (thisx10./L));
		delPsp010 = Psp010 .* rel_delP010;
		
		% Find the derivatives with respect to the uncertain parameters.  
		% Here we're calculating centered derivatives using fzero and
		% the subfunction E_simple.
		dEdN10 = (1e4./(sample.rho.*2.*delN10)) .* ...
			( (fzero(@(y) E_simple(y,Psp010,Pmu010,L,Lmu10,l10,(N10+delN10)),thisx10)) - ...
			(fzero(@(y) E_simple(y,Psp010,Pmu010,L,Lmu10,l10,(N10-delN10)),thisx10)) );
		
		dEdPsp010 = (1e4./(sample.rho.*2.*delPsp010)) .* ...
			( (fzero(@(y) E_simple(y,(Psp010+delPsp010),Pmu010,L,Lmu10,l10,N10),thisx10)) - ...
			(fzero(@(y) E_simple(y,(Psp010-delPsp010),Pmu010,L,Lmu10,l10,N10),thisx10)) );
		
		dEdPmu010 = (1e4./(sample.rho.*2.*delPmu010)) .* ...
			( (fzero(@(y) E_simple(y,Psp010,(Pmu010+delPmu010),L,Lmu10,l10,N10),thisx10)) - ...
			(fzero(@(y) E_simple(y,Psp010,(Pmu010-delPmu010),L,Lmu10,l10,N10),thisx10)) );
		
		% Add in quadrature to get the uncertainties.
		delE_ext10 = sqrt( (dEdPsp010.*delPsp010).^2 + (dEdPmu010.*delPmu010).^2 + (dEdN10.*delN10).^2 );
		delE_int10 = abs(dEdN10 .* delN10);
	else;
		x_nu10 = -1;
		delE_ext10 = 1;
		delE_int10 = 1;
	end;
	% end of uncertainty block
end;

if nucl26 == 1;
	P_nu26 = LSDnu.Al.*Pref26.*sample.othercorr;
	P_mu26 = (P_mu_full.P_fast26 + P_mu_full.P_neg26) .* sample.othercorr;
	P_fast26 = P_mu_full.P_fast26 .* sample.othercorr;
	P_neg26 = P_mu_full.P_neg26 .* sample.othercorr;
	P_mu_z26 = P_mu_z.Al .* sample.othercorr;
	
	% initial guess
	% average P_nu
	P_nu26Av = trapz(tv,P_nu26)./tv(end);
	P_temp26 = P_nu26Av + P_mu26;
	E_lal26 = LspAv.*(P_temp26./N26 - l26);
	x026 = E_lal26;

	% constants block for ET_objective.m
	c3.tv = tv;
	c3.z_mu = z_mu-(sample.thick.*sample.rho./2); % take 1/2 depth away again so t will match P
	c3.P_mu_z = P_mu_z26;
	c3.l = l26;
	c3.tsf = thickSF;
	c3.L = Lsp;
	
	% test saturation and ask fzero for the erosion rates.
	P_mud26 = interp1(z_mu,P_mu_z26,sample.thick.*sample.rho./2,'pchip'); % P_mu at 1/2 sample depth
	Ntest26 = cumtrapz(tv,(P_nu26.*exp(-tv.*l26) + P_mud26.*exp(-tv.*l26))); % zero erosion N
	if N26 > max(Ntest26); % if saturated
		x_nu26 = -1;
		diag_nu26 = 0;
		fval_nu26 = 0;
		exitflag_nu26 = 0;
	else;
		opts = optimset('fzero');
		opts = optimset(opts,'tolx',1e-8,'display','off');

		c3.P_sp_t = P_nu26;
		%tic;
		[x_nu26,fval_nu26,exitflag_nu26,output26] = ...
			fzero(@(x) ET_objective(x,c3,N26),x026,opts);
		%opt_time_nu = toc;
		% diagnostics
		diag_nu26 = ET_objective(x_nu26,c3,N26,'yes');
	end;
	
	% Error propagation
	% Common information
	Pmu026 = P_mu_z26(1);
	delPfast26 = P_fast26 .* (delsigma026 ./ sigma026);
	delPneg26 = P_neg26 .* sqrt((delk_negpartial26 ./ k_negpartial26)^2 + (delfstar26 ./ fstar26)^2);
	delPmu026 = sqrt(delPfast26.^2 + delPneg26.^2);
	L = LspAv;
	
	% SF - varying variable assignments
	diag26 = diag_nu26;
	thisx26 = x_nu26;
	rel_delP026 = delPref26./Pref26;
	
	% Conditional on actually having a result --
	% this is the saturation check
	if thisx26 > 0;
		% find what Lmu ought to be 
		Lmu26 = thisx26 ./ ((Pmu026./diag26.Nmu) - l26);
		
		% Find what P0 ought to be
		Psp026 = diag26.Nsp.*(l26 + (thisx26./L));
		delPsp026 = Psp026 .* rel_delP026;
		
		% Find the derivatives with respect to the uncertain parameters.  
		% Here we're calculating centered derivatives using fzero and
		% the subfunction E_simple.
		dEdN26 = (1e4./(sample.rho.*2.*delN26)) .* ...
			( (fzero(@(y) E_simple(y,Psp026,Pmu026,L,Lmu26,l26,(N26+delN26)),thisx26)) - ...
			(fzero(@(y) E_simple(y,Psp026,Pmu026,L,Lmu26,l26,(N26-delN26)),thisx26)) );
		
		dEdPsp026 = (1e4./(sample.rho.*2.*delPsp026)) .* ...
			( (fzero(@(y) E_simple(y,(Psp026+delPsp026),Pmu026,L,Lmu26,l26,N26),thisx26)) - ...
			(fzero(@(y) E_simple(y,(Psp026-delPsp026),Pmu026,L,Lmu26,l26,N26),thisx26)) );
		
		dEdPmu026 = (1e4./(sample.rho.*2.*delPmu026)) .* ...
			( (fzero(@(y) E_simple(y,Psp026,(Pmu026+delPmu026),L,Lmu26,l26,N26),thisx26)) - ...
			(fzero(@(y) E_simple(y,Psp026,(Pmu026-delPmu026),L,Lmu26,l26,N26),thisx26)) );
		
		% Add in quadrature to get the uncertainties.
		delE_ext26 = sqrt( (dEdPsp026.*delPsp026).^2 + (dEdPmu026.*delPmu026).^2 + (dEdN26.*delN26).^2 );
		delE_int26 = abs(dEdN26 .* delN26);
	else;
		x_nu26 = -1;
		delE_ext26 = 1;
		delE_int26 = 1;
	end;
	% end of uncertainty block
end;


% ----------------------------- REPORT -------------------------------

results.main_version = ver;	% version of this function

if nucl10 == 1;
	results.Pmu010 = Pmu010; % Surface production rate due to muons;
	results.Egcm2yr10 = [x_nu10]; % erosion rate in gcm2/yr
	results.EmMyr10 = results.Egcm2yr10 * 1e4 / sample.rho;	% erosion rate in m/Myr
	results.delE_int10 = [delE_int10]; % internal error in m/Myr
	results.delE_ext10 = [delE_ext10]; % external error in m/Myr
	% diagnostics
	results.fzero_status10 = [exitflag_nu10];% exit status of fzero
	results.fval10 = [fval_nu10];	% objective function value from fzero
end;

if nucl26 == 1;
	results.Pmu026 = Pmu026; % Surface production rate due to muons;
	results.Egcm2yr26 = [x_nu26]; % erosion rate in gcm2/yr
	results.EmMyr26 = results.Egcm2yr26 * 1e4 / sample.rho;	% erosion rate in m/Myr
	results.delE_int26 = [delE_int26]; % internal error in m/Myr
	results.delE_ext26 = [delE_ext26]; % external error in m/Myr
	% diagnostics
	results.fzero_status26 = [exitflag_nu26];% exit status of fzero
	results.fval26 = [fval_nu26];	% objective function value from fzero
end;


% ----------------------------- SUBROUTINES -------------------------------

% -------------------------------------------------------------------------

function out = E_simple(x,Psp,Pmu,Lsp,Lmu,l,target);

% calculates miss between N computed with simple erosion rate expression
% and measured N
%
% Used in simplified error-propagation scheme
%
% x is erosion rate (g/cm2/yr)

N = (Psp./(l + x./Lsp)) + (Pmu./(l + x./Lmu));

out = N - target;

% ------------------------------------------------------------------------
