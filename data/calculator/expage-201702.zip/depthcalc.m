% Depth profile 10Be/26Al exposure age calculator calculating the best fit depth profile exposure
% age. The calculation is done using the expage calculator production rates (nuclide-specific LSD
% scaling). At least two concentrations must be given for the calculator to work.
% Jakob Heyman - 2017

clear all;

tic();

% What version is this?
ver = '201702';

% plotting? 1 = yes, 0 = no
% disabling plotting speeds up the calculation
plotting = 1;

% input data----------------------------------------------------------------------------------------
% lat long alt shielding rho samplingyr
lat = -47.26627;
long = -70.96320;
elv = 583;
shield = 1;
rho = 2.4;
samplingyr = 2007;

% sample names - not really necessary but included anyway...
names = ['BC07-48a';'IBC07-48b';'IBC07-48c';'BC07-48d';'BC07-48e';'BC07-48f';'BC07-48g';'BC07-48h'];

% sample depths (cm)
dv = [10 20 30 40 50 75 100 150];

% sample 10Be conc and unc
N10 = [1508000 1242000 1153000 948000 802000 563000 381000 184000];
delN10 = [47000 39000 33000 29000 23000 18000 10000 6000];

% 10Be standard - can be a vector for different standards but it MUST be in column format!
std10 = ['07KNSTD'];

% sample 26Al conc and unc
N26 = [0];
delN26 = [0];

% 26Al standard - can be a vector for different standards but it MUST be in column format!
std26 = ['0'];

% constant erosion rate (mm/ka)
erosion = 0;
% end of input--------------------------------------------------------------------------------------

% make columns of input given in rows
if isrow(dv); dv = dv'; end;
if isrow(N10); N10 = N10'; end;
if isrow(delN10); delN10 = delN10'; end;
if isrow(N26); N26 = N26'; end;
if isrow(delN26); delN26 = delN26'; end;

% run and load al_be constants
make_al_be_consts;
load al_be_consts;

% run and load consts_LSD
make_consts_LSD;
load consts_LSD;

% Define sample site atmospheric pressure
atm = ERA40atm(lat,long,elv);

% Set nucl to 0 for both 10/26
nucl10 = 0; nucl26 = 0;

% fix erosion cm/yr
erosion = erosion .* 1e-4;

% Check if 10Be and 26Al is measured
n10test = find(N10+delN10 > 0);
n26test = find(N26+delN26 > 0);
N10 = N10(n10test);
N26 = N26(n26test);
delN10 = delN10(n10test);
delN26 = delN26(n26test);
dv10 = dv(n10test);
dv26 = dv(n26test);
if numel(N10)>1; nucl10 = 1; end;
if numel(N26)>1; nucl26 = 1; end;

% convert concentrations according to standards
if nucl10 == 1;
	for i = 1:size(std10,1);
		mult10(i,1) = al_be_consts.be_stds_cfs(strmatch(std10(i,:),al_be_consts.be_stds_names,'exact'));
	end;
	N10 = N10 .* mult10;
	delN10 = delN10 .* mult10;
end;
if nucl26 == 1;
	for i = 1:size(std26,1);
		mult26(i,1) = al_be_consts.al_stds_cfs(strmatch(std26(i,:),al_be_consts.al_stds_names,'exact'));
	end;
	N26 = N26 .* mult26;
	delN26 = delN26 .* mult26;
end;

% Pref
P_ref_nu10 = al_be_consts.P10_ref_nu; delP_ref_nu10 = al_be_consts.delP10_ref_nu;
P_ref_nu26 = al_be_consts.P26_ref_nu; delP_ref_nu26 = al_be_consts.delP26_ref_nu;
% Decay constant
l10 = al_be_consts.l10; dell10 = al_be_consts.dell10;
l26 = al_be_consts.l26; dell26 = al_be_consts.dell26;

% catch for negative longitudes before Rc interpolation
if long < 0; long = long + 360; end;

% Age Relative to t0=2010 - LSD tv from LSDfix
% tv = [0:10:50 60:100:50060 51060:1000:2000060 logspace(log10(2001060),7,200)];

% Fix w,Rc,SPhi, for sp and mu prod rate scaling
LSDfix = LSD_fix(lat,long,1e7,-1,consts);

% time vector tv1
tv1 = LSDfix.tv;

% adjust tv, Rc, and SPhi to sampling year
if samplingyr <= 2010;
	clipidx = min(find(tv1 > 2010-samplingyr));
	tv = [2010-samplingyr tv1(clipidx:end)];
	Rc = interp1(tv1,LSDfix.Rc,tv);
	SPhi = interp1(tv1,LSDfix.SPhi,tv);
	tv = tv - 2010 + samplingyr;
else; % assume 2010 value for all years >2010
	Rc = [LSDfix.Rc(1) LSDfix.Rc];
	SPhi = [LSDfix.SPhi(1) LSDfix.SPhi];
	tv = [0 (tv1 + samplingyr - 2010)];
end;

% muon production
if erosion > 0;
	% depth vector for Pmu calculation
	derosion = linspace(min(dv),1e7.*erosion + max(dv),50);
	
	% calculate Pmu for depth vector
	P_mu = P_mu_LSD(derosion.*rho,atm,LSDfix.RcEst,consts.SPhiInf,nucl10,nucl26,consts,'no');
	
	% interpolate Pmu for individual samples
	if nucl10 == 1;
		for i = 1:numel(dv10);
			Pmu10(i,:) = interp1(derosion,P_mu.Be,dv10(i)+tv.*erosion,'pchip') .* shield;
		end;
	end;
	if nucl26 == 1;
		for i = 1:numel(dv26);
			Pmu26(i,:) = interp1(derosion,P_mu.Al,dv26(i)+tv.*erosion,'pchip') .* shield;
		end;
	end;
else; % no erosion
	P_mu = P_mu_LSD(dv.*rho,atm,LSDfix.RcEst,consts.SPhiInf,nucl10,nucl26,consts,'no');
	
	% pick out Pmu if data exists
	if nucl10 == 1; Pmu10 = P_mu.Be'(n10test) .* shield; end;
	if nucl26 == 1; Pmu26 = P_mu.Al'(n26test) .* shield; end;
end;

% spallation surface production scaling
Psp0 = LSDspal(atm,Rc,SPhi,LSDfix.w,nucl10,nucl26,consts);

% interpolate Lsp using CRONUScalc method (Sato 2008; Marrero et al. 2016)
Lsp = rawattenuationlength(atm,Rc);

% pick out Psp if data exists
if nucl10 == 1;
	for i = 1:numel(N10);
		Psp10(i,:) = Psp0.Be .* P_ref_nu10 .* shield .* exp(-rho.*(tv.*erosion+dv10(i))./Lsp);
	end;
end;
if nucl26 == 1;
	for i = 1:numel(N26);
		Psp26(i,:) = Psp0.Al .* P_ref_nu26 .* shield .* exp(-rho.*(tv.*erosion+dv26(i))./Lsp);
	end;
end;

% Calculate N(t) including decay
if nucl10 == 1; % if 10Be exists
	dcf10 = exp(-tv.*l10); % decay factor;
	for i = 1:numel(N10);
		N_nu10(i,:) = cumtrapz(tv,(Psp10(i,:).*dcf10 + Pmu10(i).*dcf10)); % potential N back in time
		tt(i,1) = interp1(N_nu10(i,:),tv,N10(i)); % individual sample exposure age
		
		% uncertainty estimate
		% A with integrated average Lsp
		Lsp_avg = interp1(tv,cumtrapz(tv,Lsp),tt(i,1))./tt(i,1);
		A = l10./Lsp_avg;
		FP = (N10(i).*A)./(1 - exp(-A.*tt(i,1)));
		dtdN = 1./(FP - N10(i).*A);
		deltt(i,1) = sqrt(dtdN.^2 * delN10(i).^2);
	end;
	
	% find min and max value for interpolation and make new time vector
	minage10 = round(min(tt) - (max(tt)-min(tt)));
	maxage10 = round(max(tt) + (max(tt)-min(tt)));
	if minage10 < 0; minage10 = 0; end;
	if maxage10 > 1e7; maxage10 = 1e7; end;
	tv10 = (minage10:1:maxage10);
	
	% interpret N vectors
	for i = 1:numel(N10);
		N_nu10v(i,:) = interp1(tv,N_nu10(i,:),tv10);
	end;
	
	% calculate chi square vector
	N10m = repmat(N10,1,numel(tv10));
	delN10m = repmat(delN10,1,numel(tv10));
	chi2v = sum((N_nu10v-N10m).^2 ./ delN10m.^2);
	
	% find minimum chi square and index
	[chimin10,idx10] = min(chi2v);
	
	% find best fit age (depth profile age)
	age10 = tv10(idx10);
	
	% estimate depth profile age uncertainty
	age10unc_int = sqrt(1./sum(deltt.^-2) .* 1./(numel(N10)-1) .* sum((age10-tt).^2./deltt.^2));
	age10unc_ext = sqrt(age10unc_int.^2 + (delP_ref_nu10./P_ref_nu10.*age10).^2);
	
	Rchi2_10 = chimin10./(numel(N10)-1);
	Pvalue10 = 1 - chi2cdf(chimin10,numel(N10)-1);
	
	fprintf(1,'10Be age = %.0f ± %.0f (%.0f) yr    R-chisq = %.3f    P-value = %.3f\n',age10,age10unc_ext,age10unc_int,Rchi2_10,Pvalue10)
end;

if nucl26 == 1; % if 26Al exists
	dcf26 = exp(-tv.*l26); % decay factor;
	for i = 1:numel(N26);
		N_nu26(i,:) = cumtrapz(tv,(Psp26(i,:).*dcf26 + Pmu26(i).*dcf26)); % potential N back in time
		tt(i,1) = interp1(N_nu26(i,:),tv,N26(i)); % individual sample exposure age
		
		% uncertainty estimate
		% A with integrated average Lsp
		Lsp_avg = interp1(tv,cumtrapz(tv,Lsp),tt(i,1))./tt(i,1);
		A = l26./Lsp_avg;
		FP = (N26(i).*A)./(1 - exp(-A.*tt(i,1)));
		dtdN = 1./(FP - N26(i).*A);
		deltt(i,1) = sqrt(dtdN.^2 * delN26(i).^2);
	end;
	
	% find min and max value for interpolation and make new time vector
	minage26 = round(min(tt) - (max(tt)-min(tt)));
	maxage26 = round(max(tt) + (max(tt)-min(tt)));
	if minage26 < 0; minage26 = 0; end;
	if maxage26 > 1e7; maxage26 = 1e7; end;
	tv26 = (minage26:1:maxage26);
	
	% interpret N vectors
	for i = 1:numel(N26);
		N_nu26v(i,:) = interp1(tv,N_nu26(i,:),tv26);
	end;
	
	% calculate chi square vector
	N26m = repmat(N26,1,numel(tv26));
	delN26m = repmat(delN26,1,numel(tv26));
	chi2v = sum((N_nu26v-N26m).^2 ./ delN26m.^2);
	
	% find minimum chi square and index
	[chimin26,idx26] = min(chi2v);
	
	% find best fit age (depth profile age)
	age26 = tv26(idx26);
	
	% estimate depth profile age uncertainty
	age26unc_int = sqrt(1./sum(deltt.^-2) .* 1./(numel(N26)-1) .* sum((age26-tt).^2./deltt.^2));
	age26unc_ext = sqrt(age26unc_int.^2 + (delP_ref_nu26./P_ref_nu26.*age26).^2);
	
	Rchi2_26 = chimin26./(numel(N26)-1);
	Pvalue26 = 1 - chi2cdf(chimin26,numel(N26)-1);
	
	fprintf(1,'26Al age = %.0f ± %.0f (%.0f) yr    R-chisq = %.3f    P-value = %.3f\n',age26,age26unc_ext,age26unc_int,Rchi2_26,Pvalue26)
end;


% Plotting---------------------------------------------------
if plotting == 1;
	% make depth vect for plotting
	dplot = linspace(0,max(dv).*1.25,50);
	
	if erosion > 0;
		% pick out oldest age of 10/26
		agetest = [];
		if nucl10 == 1; agetest(end+1) = age10; end;
		if nucl26 == 1; agetest(end+1) = age26; end;
		agemax = max(agetest);
		
		%make depth vect for mu
		dplotmu = linspace(0,max(dv).*1.5 + agemax.*erosion,50);
	else; % if no erosion
		% make depth vect for mu
		dplotmu = dplot;
	end;
	
	% muon production for depth profile points
	fprintf('calculating depth profile P from muons...\n')
	Pmuplot = P_mu_LSD(dplotmu.*rho,atm,LSDfix.RcEst,consts.SPhiInf,nucl10,nucl26,consts,'no');
	
	if nucl10 == 1; % if 10Be exists and plotting = yes
		% clip Psp0 and Lsp for depth profile age
		clipidx10 = max(find(tv < age10));
		tvplot = [tv(1:clipidx10) age10];
		Psp0plot10 = interp1(tv,Psp0.Be,tvplot);
		Lspplot = interp1(tv,Lsp,tvplot);
		
		dcf10plot = exp(-tvplot.*l10); % decay factor;
		
		% pick out Pmu
		if erosion > 0;
			for i = 1:numel(dplot);
				% muon production for depth profile points
				Pmu10plot(i,:) = interp1(dplotmu,Pmuplot.Be.*shield,dplot(i)+tvplot.*erosion);
			end;
		else;
			% muon production for depth profile points
			Pmu10plot = Pmuplot.Be' .* shield;
		end;
		
		% calculate Psp for depth profile points
		for i = 1:numel(dplot);
			Psp10plot(i,:) = Psp0plot10 .* P_ref_nu10 .* shield .* exp(-rho.*(tvplot.*erosion+dplot(i))./Lspplot);
		end;
		
		% calculate N
		for i = 1:numel(dplot);
			N10plot(i,:) = trapz(tvplot,(Psp10plot(i,:).*dcf10plot + Pmu10plot(i).*dcf10plot)); % N after age10 yr
		end;
		
		figure(1);
		hold on;
		
	%	plot standard depth profile
		plot(N10plot,-dplot,'k');
		plot(N10,-dv10,'.1','markersize',10);
		for i = 1:numel(N10);
			plot([N10(i)-delN10(i),N10(i)+delN10(i)],[-dv10(i),-dv10(i)],'r');
		end;
		
	%	plot depth profile with log axis for N
	%	semilogx(N10plot,-dplot,'k');
	%	semilogx(N10,-dv10,'.1','markersize',10);
	%	for i = 1:numel(N10);
	%		semilogx([N10(i)-delN10(i),N10(i)+delN10(i)],[-dv10(i),-dv10(i)],'r');
	%	end;
		
		xlabel('[10Be] (at/g)');
		ylabel('Depth (cm)');
		
		hold off
	end;

	if nucl26 == 1; % if 26Be exists and plotting = yes
		% clip Psp0 and Lsp for depth profile age
		clipidx26 = max(find(tv < age26));
		tvplot = [tv(1:clipidx26) age26];
		Psp0plot26 = interp1(tv,Psp0.Be,tvplot);
		Lspplot = interp1(tv,Lsp,tvplot);
		
		dcf26plot = exp(-tvplot.*l26); % decay factor;
		
		% pick out Pmu
		if erosion > 0;
			for i = 1:numel(dplot);
				% muon production for depth profile points
				Pmu26plot(i,:) = interp1(dplotmu,Pmuplot.Be.*shield,dplot(i)+tvplot.*erosion);
			end;
		else;
			% muon production for depth profile points
			Pmu26plot = Pmuplot.Be' .* shield;
		end;
		
		% calculate Psp for depth profile points
		for i = 1:numel(dplot);
			Psp26plot(i,:) = Psp0plot26 .* P_ref_nu26 .* shield .* exp(-rho.*(tvplot.*erosion+dplot(i))./Lspplot);
		end;
		
		% calculate N
		for i = 1:numel(dplot);
			N26plot(i,:) = trapz(tvplot,(Psp26plot(i,:).*dcf26plot + Pmu26plot(i).*dcf26plot)); % N after age26 yr
		end;
		
		figure(2);
		hold on;
		
	%	plot standard depth profile
		plot(N26plot,-dplot,'k');
		plot(N26,-dv26,'.1','markersize',10);
		for i = 1:numel(N26);
			plot([N26(i)-delN26(i),N26(i)+delN26(i)],[-dv26(i),-dv26(i)],'r');
		end;
		
	%	plot depth profile with log axis for N
	%	semilogx(N26plot,-dplot,'k');
	%	semilogx(N26,-dv26,'.1','markersize',10);
	%	for i = 1:numel(N26);
	%		semilogx([N26(i)-delN26(i),N26(i)+delN26(i)],[-dv26(i),-dv26(i)],'r');
	%	end;
		
		xlabel('[26Al] (at/g)');
		ylabel('Depth (cm)');
		
		hold off
	end;
end;
% End plotting-------------------------------------------------------

toc()
