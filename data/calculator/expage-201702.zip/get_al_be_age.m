function results = get_al_be_age(sample,consts,nucl10,nucl26);

% This function calculates the exposure age of a sample and
% packages the results.
%
% syntax : results = get_al_be_age(sample,consts,nucl10,nucl26);
%
% argument sample is the structure assembled upstream by expage.m.
%
% argument consts is typically the al_be_consts structure derived from
% make_al_be_consts_vx.m. Many required fields.
%
% argument nuclide is 10 or 26. Number not string. 
%
% Many dependencies.
% 
% results is a structure with many fields:
%
% Non-scaling-scheme-dependent results:
%
% results.flags: Error messages, mostly about saturation
% results.main_version: version of this function
% results.P_mu: surface production rate by muons (atoms/g/yr)
% results.thick_sf: thickness scaling factor (nondimensional)
% results.tv: time vector against which to plot Rc and P
%
% Scaling-scheme-dependent results: two of each of these fields, one for
% each scaling scheme. XX in field names below indicates a two-letter code
% identifying each scaling scheme, as follows:
% sp Lifton et al. (2014) LSD spallation scaling
% nu Lifton et al. (2014) LSD nuclide-specific scaling
%
% results.P_XX: P(t) at site in scaling scheme XX (atoms/g/yr) (vector)
% results.t_XX: Exposure age WRT scaling scheme XX (yr)
% results.delt_int_XX: Internal uncertainty WRT scaling scheme XX (yr)
% results.delt_ext_XX: External uncertainty WRT scaling scheme XX (yr)
%
% NOTE: in this version only nu scaling is used and sp scaling is commented out with %
% 
% Modidied by Jakob Heyman (jakob.heyman@gu.se) 2015-2017
% from code written by Greg Balco -- UW Cosmogenic Nuclide Lab
% balcs@u.washington.edu
% April, 2007
%
% Copyright 2001-2007, University of Washington
% All rights reserved
% Developed in part with funding from the National Science Foundation.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License, version 2,
% as published by the Free Software Foundation (www.fsf.org).

% What version is this?
ver = '201702';

tv = sample.tv;

% Calculate ages for nuclide of interest
if nucl10 == 1;
	% Atoms/g measurement
	N10 = sample.N10; delN10 = sample.delN10;
	% Production rates from spallation for one/two schemes
%	P_ref_sp10 = consts.P10_ref_sp; delP_ref_sp10 = consts.delP10_ref_sp;
	P_ref_nu10 = consts.P10_ref_nu; delP_ref_nu10 = consts.delP10_ref_nu;
	% Decay constant
	l10 = consts.l10; dell10 = consts.dell10;
	
	% Calculate N(t) including decay and erosion
	dcf10 = exp(-tv.*l10); % decay factor;
	dpfs10 = exp(-tv.*sample.E.*sample.rho./sample.Lsp); % spallation depth dependence
	N_nu10 = cumtrapz(tv,(sample.nu10.*dcf10.*dpfs10 + sample.mu10.*dcf10)); % potential N back in time
	
	% Look for saturation
	% If not saturated, get the age by reverse-interpolation.
	if N10 > max(N_nu10);
		flag = ['Sample ' sample.sample_name ' appears to be saturated in 10Be'];
		results.flags = flag;
		t_nu10 = 1E7;
	else;
		t_nu10 = interp1(N_nu10,tv,N10);
	end;
end;

if nucl26 == 1;
	% Atoms/g measurement
	N26 = sample.N26; delN26 = sample.delN26;
	% Production rates for one/two schemes
%	P_ref_sp26 = consts.P26_ref_sp; delP_ref_sp26 = consts.delP26_ref_sp;
	P_ref_nu26 = consts.P26_ref_nu; delP_ref_nu26 = consts.delP26_ref_nu;
	% Decay constant
	l26 = consts.l26; dell26 = consts.dell26;
	
	% Calculate N(t) including decay and erosion
	dcf26 = exp(-tv.*l26); % decay factor;
	dpfs26 = exp(-tv.*sample.E.*sample.rho./sample.Lsp); % spallation depth dependence
	N_nu26 = cumtrapz(tv,(sample.nu26.*dcf26.*dpfs26 + sample.mu26.*dcf26)); % potential N back in time
	
	% Look for saturation
	% If not saturated, get the age by reverse-interpolation.
	if N26 > max(N_nu26);
		flag = ['Sample ' sample.sample_name ' appears to be saturated in 26Al'];
		results.flags = flag;
		t_nu26 = 1E7;
	else;
		t_nu26 = interp1(N_nu26,tv,N26);
	end;
end;


% Error propagation scheme. 
% This is highly simplified. We approximate the error by figuring out what the
% effective production rate is (disregarding the special depth dependence
% for muons) which gives the right age in the simple age equation. 
% Error in this taken to be linear WRT the reference production rate.
% Then we linearly propagate errors through the S.A.E. 
% We ignore the nominal error in production by muons. This is OK
% because it's small compared to the total error in the reference
% production rate. Future versions will use Monte Carlo error analysis. 

if nucl10 == 1;
	% A with integrated average Lsp
	Lsp_avg = interp1(tv,cumtrapz(tv,sample.Lsp),t_nu10)./t_nu10;
	A = l10 + sample.rho * sample.E ./Lsp_avg;
	
	N = N10;
	delN = delN10;
	
	% extract t, Pref, delPref for SF
	tt = t_nu10;
	tPref = consts.P10_ref_nu;
	tdelPref = consts.delP10_ref_nu;
	if tt < 1E7; % Not saturated, is an age
		% do most of computation
		FP = (N.*A)./(1 - exp(-A.*tt));
		delFP = (tdelPref / tPref) * FP;
		dtdN = 1./(FP - N.*A);
		dtdP = -N./(FP.*FP - N.*A.*FP);
		% make respective delt's
		delt_ext_nu10 = sqrt( dtdN.^2 * delN.^2 + dtdP.^2 * delFP.^2);
		delt_int_nu10 = sqrt(dtdN.^2 * delN.^2);
		FP_nu10 = FP;
	else; % t set to 1E7, was saturated - set unc to 1E7 (10Be)
		delt_ext_nu10 = 1E7;
		delt_int_nu10 = 1E7;
		FP_nu10 = 0;
	end;
end;

if nucl26 == 1;
	% A with integrated average Lsp
	Lsp_avg = interp1(tv,cumtrapz(tv,sample.Lsp),t_nu26)./t_nu26;
	A = l26 + sample.rho * sample.E ./Lsp_avg;
	
	N = N26;
	delN = delN26;
	
	% extract t, Pref, delPref for SF
	tt = t_nu26;
	tPref = consts.P26_ref_nu;
	tdelPref = consts.delP26_ref_nu;
	if tt < 1E7; % Not saturated, is an age
		% do most of computation
		FP = (N.*A)./(1 - exp(-A.*tt));
		delFP = (tdelPref / tPref) * FP;
		dtdN = 1./(FP - N.*A);
		dtdP = -N./(FP.*FP - N.*A.*FP);
		% make respective delt's
		delt_ext_nu26 = sqrt( dtdN.^2 * delN.^2 + dtdP.^2 * delFP.^2);
		delt_int_nu26 = sqrt(dtdN.^2 * delN.^2);
		FP_nu26 = FP;
	else; % t set to 1E7, was saturated - set age and unc to 5E6 (26Al)
		t_nu26 = 5E6;
		delt_ext_nu26 = 5E6;
		delt_int_nu26 = 5E6;
		FP_nu26 = 0;
	end;
end;


% Results structure assignment
if nucl10 == 1;
	results.t_nu10 = t_nu10;
	results.delt_int_nu10 = delt_int_nu10;
	results.delt_ext_nu10 = delt_ext_nu10;
end;
if nucl26 == 1;
	results.t_nu26 = t_nu26;
	results.delt_int_nu26 = delt_int_nu26;
	results.delt_ext_nu26 = delt_ext_nu26;
end;

% Version
results.version = ver;
