% Calculator for 10Be and 26Al erosion depth calculation for cases with prior exposure and a known
% exposure-burial-exposure history defined by age1 (time of initial exposure), age2 (time of initial
% burial), and age3 (time of last exposure / end of burial).
% Jakob Heyman - 2017

clear all;

tic();

% What version is this?
ver = '201702';

% max depth to check for prior exposure and number of depth points for production interpolation
maxd = 300; % (cm)
dpoints = 101;

% read input file
[samplein.sample_name,samplein.lat,samplein.long,samplein.elv,samplein.aa,samplein.thick,samplein.rho,samplein.othercorr,samplein.E,samplein.N10,samplein.delN10,samplein.be_stds,samplein.N26,samplein.delN26,samplein.al_stds,samplein.samplingyr,samplein.age1,samplein.age2,samplein.age3] = textread('input.txt','%s %n %n %n %s %n %n %n %n %n %n %s %n %n %s %n %n %n %n');

% fix strings in input
samplein.sample_name = strvcat(samplein.sample_name);
samplein.aa = strvcat(samplein.aa);
samplein.be_stds = strvcat(samplein.be_stds);
samplein.al_stds = strvcat(samplein.al_stds);

% run and load al_be constants
make_al_be_consts;
load al_be_consts;

% run and load LSD consts
make_consts_LSD;
load consts_LSD;

% constants
Pref10 = al_be_consts.P10_ref_nu; delPref10 = al_be_consts.delP10_ref_nu;
Pref26 = al_be_consts.P26_ref_nu; delPref26 = al_be_consts.delP26_ref_nu;
% Decay constant
l10 = al_be_consts.l10; dell10 = al_be_consts.dell10;
l26 = al_be_consts.l26; dell26 = al_be_consts.dell26;

% convert 10Be concentrations according to standards
for i = 1:numel(samplein.N10);
	be_mult(i,1) = al_be_consts.be_stds_cfs(strmatch(samplein.be_stds(i,:),al_be_consts.be_stds_names,'exact'));
end;

samplein.N10 = samplein.N10 .* be_mult;
samplein.delN10 = samplein.delN10 .* be_mult;

% convert 26Al concentrations according to standards
for i = 1:numel(samplein.N26);
	al_mult(i,1) = al_be_consts.al_stds_cfs(strmatch(samplein.al_stds(i,:),al_be_consts.al_stds_names,'exact'));
end;

samplein.N26 = samplein.N26 .* al_mult;
samplein.delN26 = samplein.delN26 .* al_mult;

% initial Lsp for simple age calculation
Lsp1 = al_be_consts.Lsp;

% pick out samples one by one
for i = 1:numel(samplein.lat);
	sample.sample_name = samplein.sample_name(i,:);
	sample.lat = samplein.lat(i);
	sample.long = samplein.long(i);
	sample.elv = samplein.elv(i);
	sample.aa = samplein.aa(i,:);
	sample.thick = samplein.thick(i);
	sample.rho = samplein.rho(i);
	sample.othercorr = samplein.othercorr(i);
	sample.E = samplein.E(i);
	sample.N10 = samplein.N10(i);
	sample.delN10 = samplein.delN10(i);
	sample.be_stds = samplein.be_stds(i,:);
	sample.N26 = samplein.N26(i);
	sample.delN26 = samplein.delN26(i);
	sample.al_stds = samplein.al_stds(i,:);
	sample.samplingyr = samplein.samplingyr(i);
	sample.age1 = samplein.age1(i);
	sample.age2 = samplein.age2(i);
	sample.age3 = samplein.age3(i);
	
	if sample.N10 + sample.delN10 + sample.N26 + sample.delN26 > 0;
		fprintf(1,'%.0f. %s',i,num2str(sample.sample_name))
		
		% define sample site atmospheric pressure
		if (strcmp(sample.aa,'std'));
			sample.pressure = ERA40atm(sample.lat,sample.long,sample.elv);
		elseif (strcmp(sample.aa,'ant'));
			sample.pressure = antatm(sample.elv);
		elseif (strcmp(sample.aa,'pre'));
			sample.pressure = sample.elv;
		end;
		
		% fix nucl10 and nucl26
		nucl10 = 0; nucl26 = 0;
		if (sample.N10 + sample.delN10) > 0; nucl10 = 1; end;
		if (sample.N26 + sample.delN26) > 0; nucl26 = 1; end;
		
		% define starting point
		mt = sample.age1 + 2010 - sample.samplingyr;
		
		% catch for negative longitudes before Rc interpolation
		if sample.long < 0; sample.long = sample.long + 360;end;
		
		% Age Relative to t0=2010 - LSD tv from LSDfix
		% tv = [0:10:50 60:100:50060 51060:1000:2000060 logspace(log10(2001060),7,200)];
		
		% Fix w,Rc,SPhi, for sp and mu prod rate scaling
		LSDfix = LSD_fix(sample.lat,sample.long,mt,-1,consts);
		
		% time vector tv0
		tv0 = LSDfix.tv;

		% adjust tv, Rc, and SPhi to sampling year
		if sample.samplingyr <= 2010;
			clipidx = min(find(tv0 > 2010-sample.samplingyr));
			tv = [2010-sample.samplingyr tv0(clipidx:end)];
			Rc = interp1(tv0,LSDfix.Rc,tv);
			SPhi = interp1(tv0,LSDfix.SPhi,tv);
			tv = tv - 2010 + sample.samplingyr;
		else; % assume 2010 value for all years >2010
			Rc = [LSDfix.Rc(1) LSDfix.Rc];
			SPhi = [LSDfix.SPhi(1) LSDfix.SPhi];
			tv = [0 (tv0 + sample.samplingyr - 2010)];
		end;
		
		% split up tv, Rc, Sphi to periods 1 and 2
		clipidx1 = min(find(tv > sample.age2));
		tv1 = [sample.age2 tv(clipidx1:end)];
		Rc1 = interp1(tv,Rc,tv1);
		Sphi1 = interp1(tv,SPhi,tv1);
		clipidx2 = max(find(tv < sample.age3));
		tv2 = [tv(1:clipidx2) sample.age3];
		Rc2 = interp1(tv,Rc,tv2);
		Sphi2 = interp1(tv,SPhi,tv2);
		
		
		% Production from muons
		dv = linspace(0,maxd,dpoints); % depth vector
		if sample.E > 0;
			dv = [dv (maxd + (sample.age1-sample.age2+sample.age3).*sample.E)];
		end;
		P_mu = P_mu_LSD((dv+sample.thick./2).*sample.rho,sample.pressure,LSDfix.RcEst,consts.SPhiInf,nucl10,nucl26,consts,'no');
		
		% Production from spallation
		LSDnu = LSDspal(sample.pressure,Rc,SPhi,LSDfix.w,nucl10,nucl26,consts);
		
		% interpolate Lsp using CRONUScalc method (Sato 2008; Marrero et al. 2016)
		Lsp1 = rawattenuationlength(sample.pressure,Rc1);
		Lsp2 = rawattenuationlength(sample.pressure,Rc2);
		
		% Thickness scaling factor.
		if sample.thick > 0;
			thickSF1 = thickness(sample.thick,Lsp1,sample.rho);
			thickSF2 = thickness(sample.thick,Lsp2,sample.rho);
		else
			thickSF1 = 1; thickSF2 = 1;
		end;
		
		% spallation depth dependence
		dpfs2 = exp(-tv2.*sample.E.*sample.rho./Lsp2);
		
		% erosion depth vector for tv2
		edv2 = tv2 .* sample.E;
		
		% erosion depth vector for tv1
		edv1 = (tv1-min(tv1)).*sample.E + sample.age3.*sample.E;
		
		% depth matrix for tv1 including all possible erosion
		dm1 = bsxfun(@plus,edv1',linspace(0,maxd,dpoints));
		
		% spallation depth dependence matrix for tv1
		dpfs1m = exp(-dm1.*repmat(sample.rho./Lsp1',1,dpoints));
		
		% if 10Be is measured
		if nucl10 == 1;
			% calculate N produced over tv2
			mu2_10 = interp1(dv,P_mu.Be,edv2,'pchip') .* sample.othercorr; % P_mu over tv2
			sp2_10 = interp1(tv,LSDnu.Be,tv2).*Pref10.*thickSF2.*sample.othercorr; % P_sp over tv2
			
			% Calculate N(t) including decay and erosion
			dcf2_10 = exp(-tv2.*l10); % decay factor;
			N2_10 = trapz(tv2,(sp2_10.*dcf2_10.*dpfs2 + mu2_10.*dcf2_10)); % N from tv2
			
			if N2_10 >= sample.N10; % if too low measured N10
				fprintf(1,'   10Be: no prior exposure!')
				output10(i,1) = maxd; % set depth of erosion to maxd (cm)
				if (sample.age2-sample.age3) > 0; % erosion rate based on maxd (mm/ka)
					output10(i,3) = maxd/(sample.age2-sample.age3)*1E4;
				end;
			else;
				N1_10 = sample.N10 - N2_10; % N10 produced over tv1
				
				% muon production matrix
				mu1m_10 = interp1(dv,P_mu.Be,dm1);
				
				% spallation production
				sp1_10 = interp1(tv,LSDnu.Be,tv1).*Pref10.*thickSF1.*sample.othercorr; % P_sp over tv1
				sp1m_10 = repmat(sp1_10',1,dpoints); % spal prod matrix
				
				% Calculate N(t) including decay and erosion
				dcf1m_10 = repmat(exp(-tv1.*l10)',1,dpoints); % decay factor;
				N1_10sim = trapz(tv1',(sp1m_10.*dcf1m_10.*dpfs1m + mu1m_10.*dcf1m_10)); % N from tv1 for various E
				
				% test prior exposure
				if N1_10 > max(N1_10sim);
					fprintf(1,'   10Be: too much prior exposure!')
					output10(i,1) = maxd+1;
					output10(i,2) = maxd+1;
					output10(i,3) = maxd+1;
					output10(i,4) = maxd+1;
				else;
					% interpolate depth from N1_10 and N1_10sim
					d10 = interp1(N1_10sim,linspace(0,maxd,dpoints),N1_10); % depth of erosion (cm)
					
					% uncertainty estimation - very simple and not to be used for anything serious!
					maxN10 = N1_10+sample.delN10;
					minN10 = N1_10-sample.delN10;
					if maxN10 > max(N1_10sim);
						deld10 = d10; % set uncertainty to d10
					elseif minN10 < min(N1_10sim);
						deld10 = d10; % set uncertainty to d10
					else;
						mindeld10 = interp1(N1_10sim,linspace(0,maxd,dpoints),maxN10);
						maxdeld10 = interp1(N1_10sim,linspace(0,maxd,dpoints),minN10);
						deld10 = sqrt(((maxdeld10-mindeld10)./2)^2 + (d10.*delPref10./Pref10)^2);
					end;
					
					% display E depth and save to output
					fprintf(1,'   10Be = %.1f ± %.1f cm',d10,deld10)
					output10(i,1) = d10;
					output10(i,2) = deld10;
					
					% if age2 > age3 (erosion rate possible)
					if (sample.age2-sample.age3) > 0;
						E10 = d10/(sample.age2-sample.age3)*1E4; % erosion rate (mm/ka)
						delE10 = deld10/(sample.age2-sample.age3)*1E4; % erosion rate (mm/ka)
						fprintf(1,' / %.1f ± %.1f mm/ka',E10,delE10)
						output10(i,3) = E10;
						output10(i,4) = delE10;
					end;
				end;
			end;	
		end;
		% if 26Al is measured
		if nucl26 == 1;
			% calculate N produced over tv2
			mu2_26 = interp1(dv,P_mu.Al,edv2,'pchip') .* sample.othercorr; % P_mu over tv2
			sp2_26 = interp1(tv,LSDnu.Al,tv2).*Pref26.*thickSF2.*sample.othercorr; % P_sp over tv2
			
			% Calculate N(t) including decay and erosion
			dcf2_26 = exp(-tv2.*l26); % decay factor;
			N2_26 = trapz(tv2,(sp2_26.*dcf2_26.*dpfs2 + mu2_26.*dcf2_26)); % N from tv2
			
			if N2_26 >= sample.N26; % if too low measured N26
				fprintf(1,'   26Al: no prior exposure!')
				output26(i,1) = maxd; % set depth of erosion to maxd (cm)
				if (sample.age2-sample.age3) > 0; % erosion rate based on maxd (mm/ka)
					output26(i,3) = maxd/(sample.age2-sample.age3)*1E4;
				end;
			else;
				N1_26 = sample.N26 - N2_26; % N26 produced over tv1
				
				% muon production matrix
				mu1m_26 = interp1(dv,P_mu.Al,dm1);
				
				% spallation production
				sp1_26 = interp1(tv,LSDnu.Al,tv1).*Pref26.*thickSF1.*sample.othercorr; % P_sp over tv1
				sp1m_26 = repmat(sp1_26',1,dpoints); % spal prod matrix
				
				% Calculate N(t) including decay and erosion
				dcf1m_26 = repmat(exp(-tv1.*l26)',1,dpoints); % decay factor;
				N1_26sim = trapz(tv1',(sp1m_26.*dcf1m_26.*dpfs1m + mu1m_26.*dcf1m_26)); % N from tv1 for various E
				
				% test prior exposure
				if N1_26 > max(N1_26sim);
					fprintf(1,'   26Al: too much prior exposure!')
					output26(i,1) = maxd+1;
					output26(i,2) = maxd+1;
					output26(i,3) = maxd+1;
					output26(i,4) = maxd+1;
				else;
					% interpolate depth from N1_26 and N1_26sim
					d26 = interp1(N1_26sim,linspace(0,maxd,dpoints),N1_26); % depth of erosion (cm)
					
					% uncertainty estimation - very simple and not to be used for anything serious!
					maxN26 = N1_26+sample.delN26;
					minN26 = N1_26-sample.delN26;
					if maxN26 > max(N1_26sim);
						deld26 = d26; % set uncertainty to d26
					elseif minN26 < min(N1_26sim);
						deld26 = d26; % set uncertainty to d26
					else;
						mindeld26 = interp1(N1_26sim,linspace(0,maxd,dpoints),maxN26);
						maxdeld26 = interp1(N1_26sim,linspace(0,maxd,dpoints),minN26);
						deld26 = sqrt(((maxdeld26-mindeld26)./2)^2 + (d26.*delPref26./Pref26)^2);
					end;
					
					% display E depth and save to output
					fprintf(1,'   26Al = %.1f ± %.1f cm',d26,deld26)
					output26(i,1) = d26;
					output26(i,2) = deld26;
					
					% if age2 > age3 (erosion rate possible)
					if (sample.age2-sample.age3) > 0;
						E26 = d26/(sample.age2-sample.age3)*1E4; % erosion rate (mm/ka)
						delE26 = deld26/(sample.age2-sample.age3)*1E4; % erosion rate (mm/ka)
						fprintf(1,' / %.1f ± %.1f mm/ka',E26,delE26)
						output26(i,3) = E26;
						output26(i,4) = delE26;
					end;
				end;
			end;	
		end;
		fprintf(1,'\n')
	end;
	
	clear sample;
end;

% if any 10Be: fix and save preexpE10.txt
if sum(samplein.N10 + samplein.delN10)>0;
	if numel(output10(:,1))<numel(samplein.N10);
		output10(numel(samplein.N10),1) = 0;
	end;
	
	nanmatr = output10 ~= 0;
	zeromatr = output10 <= maxd;
	output10 = output10.*nanmatr./nanmatr.*zeromatr;
	
	out10 = fopen('preexpE10.txt','w');
	dlmwrite('preexpE10.txt',output10,'delimiter','\t','precision','%.1f');
	fclose(out10);
end;

% if any 26Al: fix and save preexpE26.txt
if sum(samplein.N26 + samplein.delN26)>0;
	if numel(output26(:,1))<numel(samplein.N26);
		output26(numel(samplein.N26),1) = 0;
	end;
	
	nanmatr = output26 ~= 0;
	zeromatr = output26 <= maxd;
	output26 = output26.*nanmatr./nanmatr.*zeromatr;
	
	out26 = fopen('preexpE26.txt','w');
	dlmwrite('preexpE26.txt',output26,'delimiter','\t','precision','%.1f');
	fclose(out26);
end;

toc()
