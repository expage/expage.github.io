function LSD_fix_out = LSD_fix(lat,lon,atm,age,w)

% Fix w, Rc, and SPhi to be used by LSDmu and LSDspal.
% syntax : LSD(lat,lon,atm,age,w);

% lat = sample latitude in deg N (negative values for S hemisphere)
% lon = sample longitude in deg E (negative values for W longitudes, 
%     or 0-360 degrees E) 
% atm = atmospheric pressure
% age = age of sample
% w = gravimetric fractional water content - 0.066 is default 
%     typically about 14% volumetric per Fred Phillips. -1 gives default
%     value
% 
% Input values as scalars
%
% Based on code written by Greg Balco -- Berkeley
% Geochronology Center
% balcs@bgc.org
% 
% Modified by Brent Goehring and 
% Nat Lifton -- Purdue University
% nlifton@purdue.edu, bgoehrin@purdue.edu
%
% Modified by Jakob Heyman (jakob.heyman@gu.se) 2015-2016

% Copyright 2013, Berkeley Geochronology Center and
% Purdue University
% All rights reserved
% Developed in part with funding from the National Science Foundation.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License, version 3,
% as published by the Free Software Foundation (www.fsf.org).

load consts_LSD;

% Load the input data structure

sample.lat = lat;
sample.lon = lon;
sample.pressure = atm;
sample.age = age;

% Make the time vector
% Age Relative to t0=2010
tv = [0:10:50 60:100:50060 51060:1000:2000060 logspace(log10(2001060),7,200)];

LSDRc = zeros(1,length(tv));

% Need solar modulation parameter
this_SPhi = zeros(size(tv)) + consts.SPhiInf; % Solar modulation potential for Sato et al. (2008)
this_SPhi(1:120) = consts.SPhi; % Solar modulation potential for Sato et al. (2008)

% Fix w
if w < 0;
	LSD_fix_out.w = 0.066; % default gravimetric water content for Sato et al. (2008)
else;
	LSD_fix_out.w = w;
end;

% interpolate an M for tv > 7000...
temp_M = interp1(consts.t_M,consts.M,tv(77:end));

% catch for negative longitudes before Rc interpolation
if sample.lon < 0; sample.lon = sample.lon + 360;end;

% Make up the Rc vectors.

% Modified to work with new interpolation routines in MATLAB 2012a and later. 09/12
[loni,lati,tvi] = meshgrid(sample.lon,sample.lat,tv(1:76));
LSDRc(1:76) = interp3(consts.lon_Rc,consts.lat_Rc,consts.t_Rc,consts.TTRc,loni,lati,tvi);

% Fit to Trajectory-traced GAD dipole field as f(M/M0), as long-term average.
dd = [6.89901,-103.241,522.061,-1152.15,1189.18,-448.004;];

LSDRc(77:end) = temp_M.*(dd(1)*cosd(sample.lat) + ...
   dd(2)*(cosd(sample.lat)).^2 + ...
   dd(3)*(cosd(sample.lat)).^3 + ...
   dd(4)*(cosd(sample.lat)).^4 + ...
   dd(5)*(cosd(sample.lat)).^5 + ...
   dd(6)*(cosd(sample.lat)).^6); 

LSDRcEst = (dd(1)*cosd(sample.lat) + ...
   dd(2)*(cosd(sample.lat)).^2 + ...
   dd(3)*(cosd(sample.lat)).^3 + ...
   dd(4)*(cosd(sample.lat)).^4 + ...
   dd(5)*(cosd(sample.lat)).^5 + ...
   dd(6)*(cosd(sample.lat)).^6);

% Next, chop off tv
clipindex = find(tv <= sample.age, 1, 'last' );
tv2 = tv(1:clipindex);
if tv2(end) < sample.age;
	tv2 = [tv2 sample.age];
end;
% Now shorten the Rc's commensurately
LSDRc = interp1(tv,LSDRc,tv2);
LSDSPhi = interp1(tv,this_SPhi,tv2);

% output structure
LSD_fix_out.Rc = LSDRc;
LSD_fix_out.RcEst = LSDRcEst;
LSD_fix_out.SPhi = LSDSPhi;
LSD_fix_out.SPhiInf = consts.SPhiInf;
LSD_fix_out.SPhimu = consts.SPhimu;
LSD_fix_out.tv = tv2;
