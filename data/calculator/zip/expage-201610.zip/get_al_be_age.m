function results = get_al_be_age(sample,consts,nuclide);

% This function calculates the exposure age of a sample and
% packages the results.
%
% syntax : results = get_al_be_age(sample,consts,nuclide);
%
% argument sample is the structure assembled upstream by expage.m.
%
% argument consts is typically the al_be_consts structure derived from
% make_al_be_consts_vx.m. Many required fields.
%
% argument nuclide is 10 or 26. Number not string. 
%
% Many dependencies.
% 
% results is a structure with many fields:
%
% Non-scaling-scheme-dependent results:
%
% results.flags: Error messages, mostly about saturation
% results.main_version: version of this function
% results.P_mu: surface production rate by muons (atoms/g/yr)
% results.thick_sf: thickness scaling factor (nondimensional)
% results.tv: time vector against which to plot Rc and P
%
% Scaling-scheme-dependent results: two of each of these fields, one for
% each scaling scheme. XX in field names below indicates a two-letter code
% identifying each scaling scheme, as follows:
% sp Lifton et al. (2014) LSD spallation scaling
% nu Lifton et al. (2014) LSD nuclide-specific scaling
%
% results.P_XX: P(t) at site in scaling scheme XX (atoms/g/yr) (vector)
% results.t_XX: Exposure age WRT scaling scheme XX (yr)
% results.delt_int_XX: Internal uncertainty WRT scaling scheme XX (yr)
% results.delt_ext_XX: External uncertainty WRT scaling scheme XX (yr)
%
% NOTE: in this version only nu scaling is used and sp scaling is commented out with %
% 
% Modidied by Jakob Heyman (jakob.heyman@gu.se) 2015-2016
% from code written by Greg Balco -- UW Cosmogenic Nuclide Lab
% balcs@u.washington.edu
% April, 2007
%
% Copyright 2001-2007, University of Washington
% All rights reserved
% Developed in part with funding from the National Science Foundation.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License, version 2,
% as published by the Free Software Foundation (www.fsf.org).

% What version is this?
ver = '201606';

% 0. Select appropriate values for nuclide of interest

if nuclide == 10;
	% Atoms/g measurement
	N = sample.N10; delN = sample.delN10;
	% Production rates from spallation for one/two schemes
%	P_ref_sp = consts.P10_ref_sp; delP_ref_sp = consts.delP10_ref_sp;
	P_ref_nu = consts.P10_ref_nu; delP_ref_nu = consts.delP10_ref_nu;
	% Decay constant
	l = consts.l10; dell = consts.dell10;
elseif nuclide == 26;
	% Atoms/g measurement
	N = sample.N26; delN = sample.delN26;
	% Production rates for one/two schemes
%	P_ref_sp = consts.P26_ref_sp; delP_ref_sp = consts.delP26_ref_sp;
	P_ref_nu = consts.P26_ref_nu; delP_ref_nu = consts.delP26_ref_nu;
	% Decay constant
	l = consts.l26; dell = consts.dell26;
end;

% initial Lsp for simple age calculation
Lsp1 = consts.Lsp;

% Initial thickness scaling factor for simple age calculation
if sample.thick > 0;
	sample.thickSF = thickness(sample.thick,Lsp1,sample.rho);
else
	sample.thickSF = 1;
end;

% Catch confusion with pressure submission. If sample.pressure is already
% set, it should have a submitted value. If zero, something is wrong.
% This should never happen.
if sample.pressure == 0;
	error(['Sample.pressure = 0 on sample ' sample.sample_name]);
end;

% Initialize the result flags.
results.flags = [];

% First, find P according to Stone/Lal SF
% no muon production here!
% P_ref_nu used as ref prod rate
P_St = P_ref_nu * sample.thickSF * sample.othercorr * stone2000(sample.lat,sample.pressure,1);
A = l + sample.rho * sample.E ./Lsp1;

if (N >= (P_St./A));
	% if appears to be saturated in simple-age-world, simple age equation
	% would evaluate to NaN. Avoid this.
	% set results to -1; this flags it
	t_simple = -1;
else;
	% Actually do calculation if possible
	t_simple = (-1/A)*log(1-(N * A / P_St));
end;

% catch for negative longitudes before Rc interpolation
if sample.long < 0; sample.long = sample.long + 360;end;

% Use the non-time-dependent age t_simple to decide on a length for LSDfix. The
% factor of 1.5 is a W.A.G. Note that because the long-term magnetic field is 
% low, old PMC ages will nearly always be less than the simple age. If this goes
% wrong there is a diagnostic flag. 

mt = t_simple .* 1.5; % mt is max time. 

% clip to limit computations...
if mt < 0; % Saturated WRT simple age - use full tv
	mt = 1e7;
elseif  mt < 12060;
	mt = 12060; % Don't allow unreasonably short times
elseif mt > 1e7;
	mt = 1e7;
end;

% Age Relative to t0=2010 - LSD tv from LSDfix
% tv = [0:10:50 60:100:50060 51060:1000:2000060 logspace(log10(2001060),7,200)];

% Fix w,Rc,SPhi, for sp and nu prod rate scaling
LSDfix = LSD_fix(sample.lat,sample.long,sample.pressure,mt,-1);

% sp and nu spallation production scaling
% LSDsp = LSDspal(sample.pressure,LSDfix.Rc,LSDfix.SPhi,LSDfix.w,0);
LSDnu = LSDspal(sample.pressure,LSDfix.Rc,LSDfix.SPhi,LSDfix.w,nuclide);

% interpolate Lsp using CRONUScalc method (Sato 2008; Marrero et al. 2016)
Lsp2 = rawattenuationlength(sample.pressure,LSDfix.Rc);

% 1a. Thickness scaling factor.
if sample.thick > 0;
	sample.thickSF = thickness(sample.thick,Lsp2,sample.rho);
else
	sample.thickSF = 1;
end;

% Do the age calculation.
% Calculate P(t) separately to be sent back in the results.
% This is the surface production rate taking account of thickness and othercorr. 

% P_sp1 = LSDsp.sp.*P_ref_sp.*sample.thickSF.*sample.othercorr;

% special case for nuclide specific LSD P_nu
if nuclide == 10;
	P_nu1 = LSDnu.Be.*P_ref_nu.*sample.thickSF.*sample.othercorr;
elseif nuclide == 26;
	P_nu1 = LSDnu.Al.*P_ref_nu.*sample.thickSF.*sample.othercorr;
end;

% time vector tv1
tv1 = LSDfix.tv;

% adjust tv, P, and Lsp to sampling year
if sample.samplingyr <= 2010;
	clipidx = min(find(tv1 > 2010-sample.samplingyr));
	tv = [2010-sample.samplingyr tv1(clipidx:end)];
%	P_sp = interp1(tv1,P_sp1,tv);
	P_nu = interp1(tv1,P_nu1,tv);
	Lsp = interp1(tv1,Lsp2,tv);
	tv = tv - 2010 + sample.samplingyr;
else; % assume 2010 value for all years >2010
%	P_sp = [P_sp1(1) P_sp1];
	P_nu = [P_nu1(1) P_nu1];
	Lsp = [Lsp2(1) Lsp2];
	tv = [0 (tv1 + sample.samplingyr - 2010)];
end;

% Calculate N(t) including decay and erosion
dcf = exp(-tv.*l); % decay factor;
dpfs = exp(-tv.*sample.E.*sample.rho./Lsp); % spallation depth dependence

% Production from muons
if sample.E > 0;
	maxd = sample.E .* max(tv); % max depth
	mu_z = linspace(0,maxd,50).*sample.rho + sample.thick.*sample.rho./2; % depth vect (g/cm^2)
	P_mu_d = P_mu_LSD(mu_z,sample.pressure,LSDfix.RcEst,LSDfix.SPhimu,nuclide,'no').*sample.othercorr; % Pmu at depth
	tv_z = tv.*sample.E.*sample.rho + sample.thick.*sample.rho./2; % time - depth vect (g/cm^2)
	P_mu = interp1(mu_z,P_mu_d,tv_z,'pchip'); % P_mu over time
else;
	P_mu = P_mu_LSD((sample.thick.*sample.rho./2),sample.pressure,LSDfix.RcEst,LSDfix.SPhimu,nuclide,'no').*sample.othercorr; % P_mu if no erosion
end;

% N_sp = cumtrapz(tv,(P_sp.*dcf.*dpfs + P_mu.*dcf));
N_nu = cumtrapz(tv,(P_nu.*dcf.*dpfs + P_mu.*dcf));


% Look for saturation with respect to various scaling factors -- 
% If not saturated, get the age by reverse-interpolation.
% Note that this is not necessarily rigorous and doesn't attempt to take
% account of uncertainties in deciding if a sample is saturated. If you
% need rigorous analysis of close-to-saturation measurements, this code is
% not for you. Saturated -> age = 10 Ma.

if nuclide==10;nstring='Be-10';elseif nuclide==26;nstring='Al-26';end;

%if N > max(N_sp); 
%    flag = ['Sample ' sample.sample_name ' -- ' nstring ' appears to be saturated WRT LSD-sp SF.'];
%    results.flags = [results.flags '<br>' flag];
%    t_sp = 10000000;
%else;
%    t_sp = interp1(N_sp,tv,N);
%end;

if N > max(N_nu); 
    flag = ['Sample ' sample.sample_name ' -- ' nstring ' appears to be saturated WRT LSD-nu SF.'];
    results.flags = [results.flags '<br>' flag];
    t_nu = 10000000;
else;
    t_nu = interp1(N_nu,tv,N);
end;


% Error propagation scheme. 
% This is highly simplified. We approximate the error by figuring out what the
% effective production rate is (disregarding the special depth dependence
% for muons) which gives the right age in the simple age equation. 
% Error in this taken to be linear WRT the reference production rate.
% Then we linearly propagate errors through the S.A.E. 
% We ignore the nominal error in production by muons. This is OK
% because it's small compared to the total error in the reference
% production rate. Future versions will use Monte Carlo error analysis. 

% A with interpolated Lsp
Lsp_avg = interp1(tv,cumtrapz(tv,Lsp),t_nu)./t_nu;
A = l + sample.rho * sample.E ./Lsp_avg;

%sfa = ['sp';'nu'];
sfa = ['nu'];

% extract t, Pref, delPref for SF
tt = t_nu;
tPref = P_ref_nu;
tdelPref = delP_ref_nu;
if tt < 10000000; % Not saturated, is an age
	% do most of computation
	FP = (N.*A)./(1 - exp(-A.*tt));
	delFP = (tdelPref / tPref) * FP;
	dtdN = 1./(FP - N.*A);
	dtdP = -N./(FP.*FP - N.*A.*FP);
	% make respective delt's
	delt_ext_nu = sqrt( dtdN.^2 * delN.^2 + dtdP.^2 * delFP.^2);
	delt_int_nu = sqrt(dtdN.^2 * delN.^2);
	FP_nu = FP;
else; % t set to 10000000, was saturated - set unc to 1E7 (10Be) or 5E6 (26Al)
	if nuclide == 10;
		delt_ext_nu = 1E7;
		delt_int_nu = 1E7;
		FP_nu = 0;
	elseif nuclide == 26;
		t_nu = 5E6;
		delt_ext_nu = 5E6;
		delt_int_nu = 5E6;
		FP_nu = 0;
	end;
end;

% 5. Results structure assignment

% Thickness scaling factor
results.thick_sf = sample.thickSF;

% Muons
results.P_mu = P_mu;

% Time template
results.tv = tv;

% Results x 2 by scaling factor

%results.P_sp = P_sp;
%results.t_sp = t_sp;
%results.delt_int_sp = delt_int_sp;
%results.delt_ext_sp = delt_ext_sp;

results.P_nu = P_nu;
results.t_nu = t_nu;
results.delt_int_nu = delt_int_nu;
results.delt_ext_nu = delt_ext_nu;

% Version
results.main_version = ver;
