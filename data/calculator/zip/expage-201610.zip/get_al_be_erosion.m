function results = get_al_be_erosion(sample,albe_consts,nuclide);

% This function calculates the erosion rate for a sample by
% optimizing the forward model for E. It then packages the results.
%
% syntax : results = get_al_be_erosion(sample,albe_consts,nuclide);
%
% argument sample is the structure assembled upstream by erosion. 
%
% argument albe_consts is typically the al_be_consts structure derived from
% make_al_be_consts_vx.m. Many required fields.
%
% argument nuclide is 10 or 26.
% 
% results is a structure with fields:
%
% Non-scaling-scheme-specific information:
% 
% results.flags: Non-fatal error message string, mostly to do with
% saturation
% results.main_version: version of this function
% results.obj_version: version of objective function called in the erosion
% rate calculation
% results.mu_version: version of P_mu_LSD called internally
% results.Pmu0: surface production rate due to muons (atoms/g/yr)
%
% Scaling-scheme-specific information:
% NOTE: in this version only nuclide-specific LSD scaling (Lifton et al. 2014) is used (nu)
%
% results.Egcm2yr: erosion rate (g/cm2/yr) -- order of scaling schemes is St,De,Du,Li,Lm
% results.EmMyr: erosion rate (m/Myr)
% results.delE_int: internal uncertainty on erosion rate (m/Myr)
% results.delE_ext: external uncertainty on erosion rate (m/Myr)
%
% Diagnostics:
%
% results.time_mu_precalc: time required to calculate P_mu(z) (s)
% results.fzero_status: 1x5 array containing fzero output flags
% results.fval: 1x5 array containing objective function values at solution
% results.time_fzero: 1x5 array containing optimization times
%
% Modidied by Jakob Heyman (jakob.heyman@gu.se) 2015-2016
% from code written by Greg Balco -- UW Cosmogenic Nuclide Lab
% balcs@u.washington.edu
% April, 2007
%
% Copyright 2001-2007, University of Washington
% All rights reserved
% Developed in part with funding from the National Science Foundation.
%
% This program is free software; you can redistribute it and/or modify
% it under the terms of the GNU General Public License, version 2,
% as published by the Free Software Foundation (www.fsf.org).

% What version is this?
ver = '201606';

% load LSD constants
load consts_LSD;

% 0. Select appropriate values for nuclide of interest
if nuclide == 10;
	% Atoms/g measurement
	N = sample.N10; delN = sample.delN10;
	% Production rates from spallation for four schemes
	P_ref_nu = albe_consts.P10_ref_nu; delP_ref_nu = albe_consts.delP10_ref_nu;
	% Decay constant
	l = albe_consts.l10;
	nstring='Be-10';
	% Be-10 interaction cross-sections
	sigma0 = consts.sigma0_10nu;
	delsigma0 = consts.delsigma0_10nu;
	k_negpartial = consts.k_negpartial10;
	delk_negpartial = consts.delk_negpartial10;
	fstar = consts.fstar10nu;
	delfstar = consts.delfstar10nu;
elseif nuclide == 26;
	% Atoms/g measurement
	N = sample.N26; delN = sample.delN26;
	% Production rates for four schemes
	P_ref_nu = albe_consts.P26_ref_nu; delP_ref_nu = albe_consts.delP26_ref_nu;
	% Decay constant
	l = albe_consts.l26;
	nstring='Al-26';
	% Al-26 interaction cross-sections
	sigma0 = consts.sigma0_26nu;
	delsigma0 = consts.delsigma0_26nu;
	k_negpartial = consts.k_negpartial26;
	delk_negpartial = consts.delk_negpartial26;
	fstar = consts.fstar26nu;
	delfstar = consts.delfstar26nu;
end;

% -------------------- 1. INPUT CHECKING ---------------------------------

% Catch confusion with pressure submission. If sample.pressure is already 
% set, it should have a submitted value. If zero, something is wrong.
if isempty(sample.pressure);
	error(['Sample.pressure extant but empty on sample ' sample.sample_name]);
elseif (sample.pressure == 0);
	error(['Sample.pressure = 0 on sample ' sample.sample_name]);
end;

% Negative longitude catch
if sample.long < 0;
    sample.long = sample.long + 360;
end;

% Initialize the result flags. 
results.flags = [];

% LSD prod rate ------------------------------------------------
% Age Relative to t0=2010 - LSD tv from LSD_fix
% tv = [0:10:50 60:100:50060 51060:1000:2000060 logspace(log10(2001060),7,200)];

% Fix w,Rc,SPhi, for sp and nu prod rate scaling 10 Ma back in time
LSDfix = LSD_fix(sample.lat,sample.long,sample.pressure,1E7,-1);

% interpolate Lsp (Sato, 2008; Marrero et al., 2016)
Lsp2 = rawattenuationlength(sample.pressure,LSDfix.Rc);
Lsp = trapz(LSDfix.tv,Lsp2)./LSDfix.tv(end); % pick out average

% 1a. Thickness scaling factor.
if sample.thick > 0;
	sample.thickSF = thickness(sample.thick,Lsp,sample.rho);
else 
	sample.thickSF = 1;
end;

% sp and nu production scaling
% LSDsp = LSDspal(sample.pressure,LSDfix.Rc,LSDfix.SPhi,LSDfix.w,0);
LSDnu = LSDspal(sample.pressure,LSDfix.Rc,LSDfix.SPhi,LSDfix.w,nuclide);

% special case for nuclide specific LSD P_nu
if nuclide == 10;
	P_nu1 = LSDnu.Be.*P_ref_nu.*sample.othercorr;
elseif nuclide == 26;
	P_nu1 = LSDnu.Al.*P_ref_nu.*sample.othercorr;
end;

% muon production
P_mu_full = P_mu_LSD(0,sample.pressure,LSDfix.RcEst,LSDfix.SPhimu,nuclide,'yes');
P_mu = (P_mu_full.P_fast + P_mu_full.P_neg) .* sample.othercorr;
P_fast = P_mu_full.P_fast .* sample.othercorr;
P_neg = P_mu_full.P_neg .* sample.othercorr;

% time vector tv1
tv1 = LSDfix.tv;

% adjust tv and P to sampling year
if sample.samplingyr <= 2010;
	clipidx = min(find(tv1 > 2010-sample.samplingyr));
	tv = [2010-sample.samplingyr tv1(clipidx:end)];
	P_nu = interp1(tv1,P_nu1,tv);
	tv = tv - 2010 + sample.samplingyr;
else;
	P_nu = [P_nu1(1) P_nu1];
	tv = [0 (tv1 + sample.samplingyr - 2010)];
end;

% ---------------------- 3. INITIAL GUESS ---------------------------------
% average P_nu
P_nuAv = trapz(tv,P_nu)./tv(end);

P_temp = P_nuAv + P_mu;
E_lal = Lsp.*(P_temp./N - l);

x0 = E_lal;

% -------------------- 4. GET THE EROSION RATES -----------------------------

% Make P(t). Go out to 10M. See the hard-copy documentation for this
% function and get_al_be_age.m for more details. 

% Precompute P_mu(z) to ~200,000 g/cm2
% This log-spacing setup for the step size has relative accuracy near 
% 1e-3 at 1000 m/Myr erosion rate. 
% start at the mid-depth of the sample.
z_mu = [0 logspace(0,5.3,100)]+(sample.thick.*sample.rho./2);
P_mu_z = P_mu_LSD(z_mu,sample.pressure,LSDfix.RcEst,LSDfix.SPhimu,nuclide,'no').*sample.othercorr;

% Yet another constants block for ET_objective.m
c3.tv = tv;
c3.z_mu = z_mu-(sample.thick.*sample.rho./2); % take 1/2 depth away again so t will match P
c3.P_mu_z = P_mu_z;
c3.l = l;
c3.tsf = sample.thickSF;
c3.L = Lsp;

% Finally, ask fzero for the erosion rates. 
% First, test saturation
P_mud = interp1(z_mu,P_mu_z,sample.thick.*sample.rho./2); % P_mu at 1/2 sample depth
Ntest = cumtrapz(tv,(P_nu.*exp(-tv.*l) + P_mud.*exp(-tv.*l))); % zero erosion N
if N > max(Ntest); % if saturated
	x_nu = -1;
	diag_nu = 0;
	fval_nu = 0;
	exitflag_nu = 0;
else;
	opts = optimset('fzero');
	opts = optimset(opts,'tolx',1e-8,'display','off');

	c3.P_sp_t = P_nu;
	%tic;
	[x_nu,fval_nu,exitflag_nu,output] = ...
		fzero(@(x) ET_objective(x,c3,N),x0,opts);
	%opt_time_nu = toc;
	% diagnostics
	diag_nu = ET_objective(x_nu,c3,N,'yes');
end;

% -------------------- 5. ERROR PROPAGATION ---------------------------

% Common information
Pmu0 = P_mu_z(1);
delPfast = P_fast .* (delsigma0 ./ sigma0);
delPneg = P_neg .* sqrt((delk_negpartial ./ k_negpartial)^2 + (delfstar ./ fstar)^2);
delPmu0 = sqrt(delPfast.^2 + delPneg.^2);
L = Lsp;

% SF - varying variable assignments
diag = diag_nu;
thisx = x_nu;
rel_delP0 = delP_ref_nu./P_ref_nu;

% Conditional on actually having a result --
% this is the saturation check
if thisx > 0;
	% find what Lmu ought to be 
	Lmu = thisx ./ ((Pmu0./diag.Nmu) - l);
	
	% Find what P0 ought to be
	Psp0 = diag.Nsp.*(l + (thisx./L));
	delPsp0 = Psp0 .* rel_delP0;
	
	% Find the derivatives with respect to the uncertain parameters.  
	% Here we're calculating centered derivatives using fzero and
	% the subfunction E_simple.
	
	dEdN = (1e4./(sample.rho.*2.*delN)) .* ...
		( (fzero(@(y) E_simple(y,Psp0,Pmu0,L,Lmu,l,(N+delN)),thisx)) - ...
		(fzero(@(y) E_simple(y,Psp0,Pmu0,L,Lmu,l,(N-delN)),thisx)) );
	
	dEdPsp0 = (1e4./(sample.rho.*2.*delPsp0)) .* ...
		( (fzero(@(y) E_simple(y,(Psp0+delPsp0),Pmu0,L,Lmu,l,N),thisx)) - ...
		(fzero(@(y) E_simple(y,(Psp0-delPsp0),Pmu0,L,Lmu,l,N),thisx)) );
	
	dEdPmu0 = (1e4./(sample.rho.*2.*delPmu0)) .* ...
		( (fzero(@(y) E_simple(y,Psp0,(Pmu0+delPmu0),L,Lmu,l,N),thisx)) - ...
		(fzero(@(y) E_simple(y,Psp0,(Pmu0-delPmu0),L,Lmu,l,N),thisx)) );
	
	% Add in quadrature to get the uncertainties.
	
	delE_ext = sqrt( (dEdPsp0.*delPsp0).^2 + (dEdPmu0.*delPmu0).^2 + (dEdN.*delN).^2 );
	delE_int = abs(dEdN .* delN);
	
	% SF-specific assignments
	delE_ext_nu = delE_ext;
	delE_int_nu = delE_int;
else;
	x_nu = -1;
	delE_ext_nu = 1;
	delE_int_nu = 1;
end;
% end of uncertainty block

% ----------------------------- 6. REPORT -------------------------------

% Non-scaling-scheme-dependent 
results.main_version = ver;	% version of this function
%results.obj_version = diag.ver; % version of objective function
%results.mu_version = P_mu_0_diag.ver; % version of P_mu_LSD
results.Pmu0 = Pmu0; % Surface production rate due to muons;
% Scaling-scheme-dependent
results.Egcm2yr = [x_nu];	% erosion rate in gcm2/yr, 5 schemes
results.EmMyr = results.Egcm2yr * 1e4 / sample.rho;	% erosion rate in m/Myr
results.delE_int =	[delE_int_nu];	% internal error in m/Myr
results.delE_ext =	[delE_ext_nu];	% external error in m/Myr
% diagnostics
results.fzero_status = [exitflag_nu];% exit status of fzero
results.fval = [fval_nu];	% objective function value from fzero
%results.time_fzero = [opt_time_nu]; % elapsed time of optimization
%results.time_mu_precalc = time_mu_precalc; % elapsed time of P_mu(z) precalculation

% results.flags already contains whatever it's gonna contain. 

% ----------------------------- SUBROUTINES -------------------------------

% -------------------------------------------------------------------------

function out = E_simple(x,Psp,Pmu,Lsp,Lmu,l,target);

% calculates miss between N computed with simple erosion rate expression
% and measured N
%
% Used in simplified error-propagation scheme
%
% x is erosion rate (g/cm2/yr)

N = (Psp./(l + x./Lsp)) + (Pmu./(l + x./Lmu));

out = N - target;

% ------------------------------------------------------------------------
