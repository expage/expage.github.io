function out = make_al_be_consts();

% This function creates and saves a structure with relevant constants and
% external data for the Al-Be exposure age and erosion rate calculators.  
%
% Syntax: make_al_be_consts
% (no arguments)
%
% Additional updates to AMS standardizations Feb 15, 2011. 
%
% Modified by Jakob Heyman (jakob.heyman@gu.se) 2015-2017
% from code written by Greg Balco -- Berkeley Geochronology Center
% balcs@u.washington.edu -- balcs@bgc.org
% February, 2008
%
% Copyright 2001-2007, University of Washington
% 2008-, Greg Balco
% All rights reserved
% Developed in part with funding from the National Science Foundation.
%

al_be_consts.version = '201702';
al_be_consts.prepdate = fix(clock);

% Be-10 decay constant -- new Euro value
al_be_consts.l10 = -log(0.5)./1.387e6; % Chmeleff/Korschinek value

dldt = -log(0.5).*(1.387e6^-2);
al_be_consts.dell10 = sqrt((dldt.*0.012e6)^2); % Chmeleff/Korschinek value

% Note that the uncertainty is not used in exposure-age or erosion-rate
% calculators. Here only for development purposes.

% Al-26 decay constant -- value compatible with Nishiizumi standards
% lambda = 9.83e-7 --> t(1/2) = 0.705e6 yr
% See Nishiizumi (2004) for details.
al_be_consts.l26 = 9.83e-7;

% Note that the uncertainty is not used in exposure-age or erosion-rate
% calculators. Here only for development purposes. 
al_be_consts.dell26 = 2.5e-8;

% Effective attenuation length for spallation in rock
% Commonly accepted value: 160 g/cm2
% For discussion see Gosse and Phillips (2000)
% Only used for simple age calculation - else rawattenuationlength is used.
al_be_consts.Lsp = 160;

% Be-10 standardization info.
% Standards comparison/conversion lookup table. A zero placeholder is allowed.
al_be_consts.be_stds_names = strvcat('07KNSTD','KNSTD','NIST_Certified','NIST_30000',...
	'NIST_30200','NIST_30300','NIST_30500','NIST_30600','NIST_27900','LLNL31000','LLNL10000',...
	'LLNL3000','LLNL1000','LLNL300','S555','S2007','BEST433','S555N','S2007N','BEST433N','STD11',...
	'0');
al_be_consts.be_stds_cfs = [1 0.9042 1.0425 0.9313 0.9251 0.9221 0.9157 0.9130 1 0.8761 0.9042 ...
	0.8644 0.9313 0.8562 0.9124 0.9124 0.9124 1 1 1 1 1]';

% Same for Al-26. A zero placeholder is allowed.
al_be_consts.al_stds_names = strvcat('KNSTD','ZAL94','ZAL94N','SMAL11','ASTER','Z92-0222','0');
al_be_consts.al_stds_cfs = [1 0.9134 1 1.021 1.021 1 1]';

% Reference production rates at SLHL for spallation according to the two LSD
% scaling schemes. Letter codes sp and nu refer to the LSD spallation scaling
% and the LSD nuclide-specific scaling of Lifton et al. (2014), respectively.
%
% 10Be production rates are referenced to 07KNSTD.
% 26Al production rates are referenced to KNSTD.

% Be-10 production rates - updated global expage-201702 ref prod rate
al_be_consts.P10_ref_sp = 4; % not properly calibrated!
al_be_consts.delP10_ref_sp = 0.3; % not properly calibrated!
al_be_consts.P10_ref_nu = 3.98;
al_be_consts.delP10_ref_nu = 0.25;

% Al-26 production rates - updated global expage-201702 ref prod rate
al_be_consts.P26_ref_sp = 29; % not properly calibrated!
al_be_consts.delP26_ref_sp = 3; % not properly calibrated!
al_be_consts.P26_ref_nu = 28.42;
al_be_consts.delP26_ref_nu = 1.87;

% Finish up
save al_be_consts al_be_consts

disp(['al_be_consts v. ' al_be_consts.version ' saved']);
