% Wrapper script for 10Be and 26Al exposure age calculator.
% Read and fix input, use get_al_be_age to calculate exposure ages, and fix and write output.
% This is free software: you can use/copy/modify/distribute as long as you keep it free.
% Jakob Heyman - 2015-2017 (jakob.heyman@gu.se)

clear all;

tic();

% What version is this?
ver = '201702';

% plotting? (1 = yes)
plotpointages = 0; % plots exposure ages as points
plotprobdens = 0; % plots exposure ages as probability density curves (for single groups of ages)

% read input file
[samplein.sample_name,samplein.lat,samplein.long,samplein.elv,samplein.aa,samplein.thick,...
    samplein.rho,samplein.othercorr,samplein.E,samplein.N10,samplein.delN10,samplein.be_stds,...
    samplein.N26,samplein.delN26,samplein.al_stds,samplein.samplingyr] = ...
    textread('input.txt','%s %n %n %n %s %n %n %n %n %n %n %s %n %n %s %n');

% run and load al_be constants
make_al_be_consts;
load al_be_consts;

% run and load LSD consts
make_consts_LSD;
load consts_LSD;

% constants
P_ref_nu10 = al_be_consts.P10_ref_nu; delP_ref_nu10 = al_be_consts.delP10_ref_nu;
P_ref_nu26 = al_be_consts.P26_ref_nu; delP_ref_nu26 = al_be_consts.delP26_ref_nu;
% Decay constant
l10 = al_be_consts.l10; dell10 = al_be_consts.dell10;
l26 = al_be_consts.l26; dell26 = al_be_consts.dell26;

% convert 10Be concentrations according to standards
for i = 1:numel(samplein.N10);
    be_mult(i,1) = al_be_consts.be_stds_cfs(strcmp(samplein.be_stds(i),al_be_consts.be_stds_names));
end;
samplein.N10 = samplein.N10 .* be_mult;
samplein.delN10 = samplein.delN10 .* be_mult;

% convert 26Al concentrations according to standards
for i = 1:numel(samplein.N26);
    al_mult(i,1) = al_be_consts.al_stds_cfs(strcmp(samplein.al_stds(i),al_be_consts.al_stds_names));
end;
samplein.N26 = samplein.N26 .* al_mult;
samplein.delN26 = samplein.delN26 .* al_mult;

% fix erosion rate unit (mm/ka -> cm/yr)
samplein.E = samplein.E .* 1E-4;

% initial Lsp for simple age calculation
Lsp1 = al_be_consts.Lsp;

% define output cell arrays
output10 = cell();
output26 = cell();

% pick out samples one by one
for i = 1:numel(samplein.lat);
    sample.sample_name = samplein.sample_name(i);
    sample.lat = samplein.lat(i);
    sample.long = samplein.long(i);
    sample.elv = samplein.elv(i);
    sample.aa = samplein.aa(i);
    sample.thick = samplein.thick(i);
    sample.rho = samplein.rho(i);
    sample.othercorr = samplein.othercorr(i);
    sample.E = samplein.E(i);
    sample.N10 = samplein.N10(i);
    sample.delN10 = samplein.delN10(i);
    sample.be_stds = samplein.be_stds(i);
    sample.N26 = samplein.N26(i);
    sample.delN26 = samplein.delN26(i);
    sample.al_stds = samplein.al_stds(i);
    sample.samplingyr = samplein.samplingyr(i);
    
    % write sample name to output
    output(i,1) = sample.sample_name;
    output10(i,1) = {[]};
    output26(i,1) = {[]};
    
    % Set nucl and mt to 0 for both 10/26
    nucl10 = 0; nucl26 = 0; mt10 = 0; mt26 = 0;
    
    if sample.N10 + sample.delN10 + sample.N26 + sample.delN26 > 0;
        % display sample name
        fprintf(1,'%.0f. %s',i,sample.sample_name{1});
        
        % define sample site atmospheric pressure
        if (strcmp(sample.aa,'std'));
            sample.pressure = ERA40atm(sample.lat,sample.long,sample.elv);
        elseif (strcmp(sample.aa,'ant'));
            sample.pressure = antatm(sample.elv);
        elseif (strcmp(sample.aa,'pre'));
            sample.pressure = sample.elv;
        end;
        
        % Initial thickness scaling factor for simple age calculation
        if sample.thick > 0;
            thickSF = thickness(sample.thick,Lsp1,sample.rho);
        else
            thickSF = 1;
        end;
        
        % Find P scaling factor according to Stone/Lal
        P_St_SF = stone2000(sample.lat,sample.pressure,1) * thickSF * sample.othercorr;
    end;
    
    % if 10Be measured: calculate max time
    if (sample.N10 + sample.delN10) > 0;
        nucl10 = 1;
        
        % Find P according to Stone/Lal
        % no muon production here!
        % P_ref_nu used as ref prod rate
        P_St10 = P_ref_nu10 * P_St_SF;
        A10 = l10 + sample.rho * sample.E ./Lsp1;
        if (sample.N10 >= (P_St10./A10));
            % if appears to be saturated in simple-age-world, simple age equation
            % would evaluate to NaN. Avoid this.
            % set results to -1; this flags it
            t_simple10 = -1;
        else;
            % Actually do calculation if possible
            t_simple10 = (-1/A10)*log(1-(sample.N10 * A10 / P_St10));
        end;
        
        % max time (mt10) for 10Be in LSDfix
        mt10 = t_simple10 .* 1.5;
        
        % clip to limit computations...
        if mt10 < 0; % Saturated WRT simple age - use full tv
            mt10 = 1e7;
        elseif  mt10 < 12060;
            mt10 = 12060; % Don't allow unreasonably short times
        elseif mt10 > 1e7;
            mt10 = 1e7;
        end;
    end;
    
    % if 26Al measured: calculate max time
    if (sample.N26 + sample.delN26) > 0;
        nucl26 = 1;
        
        % Find P according to Stone/Lal
        % no muon production here!
        % P_ref_nu used as ref prod rate
        P_St26 = P_ref_nu26 * P_St_SF;
        A26 = l26 + sample.rho * sample.E ./Lsp1;
            if (sample.N26 >= (P_St26./A26));
            % if appears to be saturated in simple-age-world, simple age equation
            % would evaluate to NaN. Avoid this.
            % set results to -1; this flags it
            t_simple26 = -1;
        else;
            % Actually do calculation if possible
            t_simple26 = (-1/A26)*log(1-(sample.N26 * A26 / P_St26));
        end;
        
        % max time (mt26) for 26Al in LSDfix
        mt26 = t_simple26 .* 1.5;
        
        % clip to limit computations...
        if mt26 < 0; % Saturated WRT simple age - use full tv
            mt26 = 1e7;
        elseif  mt26 < 12060;
            mt26 = 12060; % Don't allow unreasonably short times
        elseif mt26 > 1e7;
            mt26 = 1e7;
        end;
    end;
    
    if nucl10+nucl26 > 0;
        % pick largest of mt10 and mt26 as max time
        mt = max(mt10,mt26);
        
        % catch for negative longitudes before Rc interpolation
        if sample.long < 0; sample.long = sample.long + 360;end;
        
        % Age Relative to t0=2010 - LSD tv from LSDfix
        % tv = [0:10:50 60:100:50060 51060:1000:2000060 logspace(log10(2001060),7,200)];
        
        % Fix w,Rc,SPhi, for sp and mu prod rate scaling
        LSDfix = LSD_fix(sample.lat,sample.long,mt,-1,consts);
        
        % time vector tv1
        tv1 = LSDfix.tv;
        
        % adjust tv, Rc, and SPhi to sampling year
        if sample.samplingyr <= 2010;
            clipidx = min(find(tv1 > 2010-sample.samplingyr));
            tv = [2010-sample.samplingyr tv1(clipidx:end)];
            Rc = interp1(tv1,LSDfix.Rc,tv);
            SPhi = interp1(tv1,LSDfix.SPhi,tv);
            tv = tv - 2010 + sample.samplingyr;
        else; % assume 2010 value for all years >2010
            Rc = [LSDfix.Rc(1) LSDfix.Rc];
            SPhi = [LSDfix.SPhi(1) LSDfix.SPhi];
            tv = [0 (tv1 + sample.samplingyr - 2010)];
        end;
        
        % Production from muons
        if sample.E <= 0;
            P_mu = P_mu_LSD(sample.thick.*sample.rho./2,sample.pressure,LSDfix.RcEst,...
                consts.SPhiInf,nucl10,nucl26,consts,'no');
            if nucl10 == 1; sample.mu10 = P_mu.Be .* sample.othercorr; end;
            if nucl26 == 1; sample.mu26 = P_mu.Al .* sample.othercorr; end;
        else;
            tv_z = (tv.*sample.E + sample.thick./2) .* sample.rho; % time - depth vect (g/cm^2)
            if nucl10 == 1;
                aged10 = sample.E .* t_simple10; % depth at t simple
                maxd10 = sample.E .* mt10; % max depth
                mu_z10 = ([linspace(0,aged10,9) maxd10] + sample.thick./2) .* sample.rho; % d vect
                if mu_z10(end) < tv_z(end);
                    mu_z10(end+1) = tv_z(end); % add value at end of mu_z if shorter than tv_z
                end;
                P_mu_d10 = P_mu_LSD(mu_z10,sample.pressure,LSDfix.RcEst,consts.SPhiInf,1,0,...
                    consts,'no'); % Pmu at d
                sample.mu10 = interp1(mu_z10,P_mu_d10.Be,tv_z,'pchip') .* sample.othercorr; % P_mu
            end;
            if nucl26 == 1;
                aged26 = sample.E .* t_simple26; % depth at t simple
                maxd26 = sample.E .* mt26; % max depth
                mu_z26 = ([linspace(0,aged26,9) maxd26] + sample.thick./2) .* sample.rho; % d vect (g/cm^2)
                if mu_z26(end) < tv_z(end);
                    mu_z26(end+1) = tv_z(end); % add value at end of mu_z if shorter than tv_z
                end;
                P_mu_d26 = P_mu_LSD(mu_z26,sample.pressure,LSDfix.RcEst,consts.SPhiInf,0,1,...
                    consts,'no'); % Pmu at d
                sample.mu26 = interp1(mu_z26,P_mu_d26.Al,tv_z,'pchip') .* sample.othercorr; % P_mu
            end;
        end;
        
        % sp and nu spallation production scaling
        %LSDsp = LSDspal(sample.pressure,LSDfix.Rc,LSDfix.SPhi,LSDfix.w,nucl10,nucl26);
        LSDnu = LSDspal(sample.pressure,Rc,SPhi,LSDfix.w,nucl10,nucl26,consts);
        
        % interpolate Lsp using CRONUScalc method (Sato 2008; Marrero et al. 2016)
        Lsp = rawattenuationlength(sample.pressure,Rc);
        
        % Thickness scaling factor.
        if sample.thick > 0;
            thickSF = thickness(sample.thick,Lsp,sample.rho);
        else
            thickSF = 1;
        end;
        
        if nucl10 == 1;
            % sample surface spallation production rate over time
            sample.nu10 = LSDnu.Be.*P_ref_nu10.*thickSF.*sample.othercorr;
        end;
        
        if nucl26 == 1;
            % sample surface spallation production rate over time
            sample.nu26 = LSDnu.Al.*P_ref_nu26.*thickSF.*sample.othercorr;
        end;
        
        sample.tv = tv;
        sample.Lsp = Lsp;
        
        results = get_al_be_age(sample,al_be_consts,nucl10,nucl26);
    end;
    
    if nucl10 == 1;
        if results.delt_ext_nu10 >= 0; % if normal exposure age
            output10(i,1) = num2str(results.t_nu10,'%.0f');
            output10(i,2) = num2str(results.delt_ext_nu10,'%.0f');
            output10(i,3) = num2str(results.delt_int_nu10,'%.0f');
            fprintf(1,' \t10Be = %s ± %s yr',output10{i,1},output10{i,2});
            plotm10(i,1) = i;
            plotm10(i,2) = round(results.t_nu10);
            plotm10(i,3) = round(results.delt_ext_nu10);
            plotm10(i,4) = round(results.delt_int_nu10);
        else;
            output10(i,1) = strcat('>',num2str(results.t_nu10,'%.0f'));
            output10(i,2) = '-';
            output10(i,3) = '-';
            fprintf(1,' \t10Be: %s yr',output10{i,1});
            if results.delt_ext_nu10 == -2; % if fully saturated
                fprintf(1,' (saturated)');
            else; % if one-sided saturated
                fprintf(1,' (one-sided saturated)');
            end;
        end;
        % fill plot matrix
        plotm10(i,1) = i;
        plotm10(i,2) = round(results.t_nu10);
        plotm10(i,3) = round(results.delt_ext_nu10);
        plotm10(i,4) = round(results.delt_int_nu10);
    end;
    
    if nucl26 == 1;
        if results.delt_ext_nu26 >= 0; % if normal exposure age
            output26(i,1) = num2str(results.t_nu26,'%.0f');
            output26(i,2) = num2str(results.delt_ext_nu26,'%.0f');
            output26(i,3) = num2str(results.delt_int_nu26,'%.0f');
            fprintf(1,' \t26Al = %s ± %s yr',output26{i,1},output26{i,2});
        else;
            output26(i,1) = strcat('>',num2str(results.t_nu26,'%.0f'));
            output26(i,2) = '-';
            output26(i,3) = '-';
            fprintf(1,' \t26Al: %s yr',output26{i,1});
            if results.delt_ext_nu26 == -2; % if fully saturated
                fprintf(1,' (saturated)');
            else; % if one-sided saturated
                fprintf(1,' (one-sided saturated)');
            end;
        end;
        % fill plot matrix
        plotm26(i,1) = i;
        plotm26(i,2) = round(results.t_nu26);
        plotm26(i,3) = round(results.delt_ext_nu26);
        plotm26(i,4) = round(results.delt_int_nu26);
    end;
    
    if nucl10+nucl26 > 0;
        fprintf(1,'\n')
    end;
    
    clear sample;
end;

% fix and save output ==============================================================================
% fix header and output string
outhead(1,1) = {'sample'};
outstr = '%s\t%s\t%s\t%s\n';
if sum(samplein.N10 + samplein.delN10)>0; % if any 10Be
    output(:,end+1:end+3) = output10;
    outhead(1,end+1:end+3) = {'10age(yr)','10uncext(yr)','10uncint(yr)'};
end;
if sum(samplein.N26 + samplein.delN26)>0; % if any 26Al
    output(:,end+1:end+3) = output26;
    outhead(1,end+1:end+3) = {'26age(yr)','26uncext(yr)','26uncint(yr)'};
end;
if sum(samplein.N10+samplein.delN10)>0 && sum(samplein.N26+samplein.delN26)>0; % if both 10 and 26
    outstr = '%s\t%s\t%s\t%s\t%s\t%s\t%s\n';
end;

% add headers
output(2:end+1,:) = output;
output(1,:) = outhead;

% fill empty cells with '-'
nullidx = cellfun(@isempty,output);
output(nullidx) = '-';

% write out-expage.txt
if sum(samplein.N10 + samplein.delN10 + samplein.N26 + samplein.delN26)>0;
    out = fopen('out-expage.txt','w');
    for i = 1:rows(output);
        fprintf(out,outstr,output{i,:});
    end;
    fclose(out);
end;

% plotting =========================================================================================
% plot points
% plots single ages with external uncertainty
if plotpointages == 1;
    % if 10Be ages exist
    if exist('plotm10');
        figure;
        hold on;
        
        % remove samples without n10
        rmidx = find(plotm10(:,3) == 0);
        plotm10(rmidx,:) = [];
        
        % plot uncertainty lines
        for i = 1:rows(plotm10);
            x = plotm10(i,1);
            if plotm10(i,3) > 0;
                y1 = plotm10(i,2) + plotm10(i,3);
                y2 = plotm10(i,2) - plotm10(i,3);
                ymax10(end+1) = y1;
                plot([x x],[y1 y2],'color','black');
            elseif plotm10(i,3) == -1;
                plot([x x],[1E7 plotm10(i,2)],'color','black');
                ymax10(end+1) = 1E7;
            end;
        end;
        
        % plot points
        plot(plotm10(:,1),plotm10(:,2),'.','markersize',15,'color','black');
        
        % fix plot
        axis([0 numel(samplein.lat)+1 0 max(ymax10)],'tic[y]','label[y]');
        xlabel('Samples');
        ylabel('^{10}Be exposure age (yr)');
        hold off;
    end;
    
    % if 26Al ages exist
    if exist('plotm26');
        figure;
        hold on;
        
        % remove samples without n26
        rmidx = find(plotm26(:,3) == 0);
        plotm26(rmidx,:) = [];
        
        % plot uncertainty lines
        for i = 1:rows(plotm26);
            x = plotm26(i,1);
            if plotm26(i,3) > 0;
                y1 = plotm26(i,2) + plotm26(i,3);
                y2 = plotm26(i,2) - plotm26(i,3);
                ymax26(end+1) = y1;
                plot([x x],[y1 y2],'color','black');
            elseif plotm26(i,3) == -1;
                plot([x x],[1E7 plotm26(i,2)],'color','black');
                ymax26(end+1) = 1E7;
            end;
        end;
        
        % plot points
        plot(plotm26(:,1),plotm26(:,2),'.','markersize',15,'color','black');
        
        % fix plot
        axis([0 numel(samplein.lat)+1 0 max(ymax26)],'tic[y]','label[y]');
        xlabel('Samples');
        ylabel('^{26}Al exposure age (yr)');
        hold off;
    end;
end;

% plot probability density curves
% red curves: single age probability density curves using internal uncertainty
% black curve: summed probability density curve
% black vertical line: weighted mean age
% grey area: weighted uncertainty with propagated production rate uncertainty added
if plotprobdens == 1;
    % if 10Be ages exist
    if exist('plotm10');
        figure;
        hold on;
        
        % find number of saturated samples
        nsat = numel(find(plotm10(:,3) < 0));
        
        % remove saturated samples and samples without n10
        rmidx = find(plotm10(:,3) <= 0);
        plotm10(rmidx,:) = [];
        
        % vectors and matrices for probability estimation
        ages = plotm10(:,2);
        uncs = plotm10(:,4);
        agemin = min(ages - 4.*uncs);
        agemax = max(ages + 4.*uncs);
        timev = linspace(agemin,agemax,500);
        timem = repmat(timev,numel(ages),1);
        agesm = repmat(ages,1,numel(timev));
        uncsm = repmat(uncs,1,numel(timev));
        
        % estimate probability distr and sum
        probdensmatr = normpdf(timem,agesm,uncsm);
        probsum = sum(probdensmatr);
        
        if numel(ages)>1;
            % calculate weigthed mean age
            wage = sum(ages./uncs.^2)/sum(1./uncs.^2);
            wunc = (sum(1./uncs.^2.*(ages-wage).^2)/sum(1./uncs.^2)*(numel(ages)-1)/numel(ages))^0.5;
            wunc = sqrt(wunc^2 + (wage*delP_ref_nu10/P_ref_nu10)^2); % add prodrate uncertainty
            
            % plot grey Pref uncertainty region
            uncage = linspace(max(wage-wunc,agemin),min(wage+wunc,agemax),100);
            uncprob = interp1(timev,probsum,uncage,'pchip');
            uncage = [uncage,wage+wunc,wage-wunc];
            uncprob = [uncprob 0 0];
            patch(uncage,uncprob,'facecolor',[0.85 0.85 0.85],'EdgeColor','none');
            
            % plot Pref line
            wageprob = interp1(timev,probsum,wage,'pchip');
            plot([wage wage],[0 wageprob],'color','black');
        end;
        
        % plot individual sample prob dens curves
        for i = 1:rows(probdensmatr);
            plot(timev,probdensmatr(i,:),'color','red');
        end
        
        if numel(ages)>1;
            % plot summed prob dens curve
            plot(timev,sum(probdensmatr),'color','black');
        end;
        
        % fix plot
        axis([max(agemin,0) min(agemax,1E7)],'tic[x]','label[x]');
        xlabel('^{10}Be exposure age (yr)');
        ylabel('Relative probability');
        set(gca,'layer','top'); % plot axis on top
        if nsat > 0; % if saturated samples: display number of excluded samples
            if nsat == 1; satstr = 'sample'; else satstr = 'samples'; end;
            xlims = xlim;
            ylims = ylim;
            xmin = xlims(1) + 0.75*(xlims(2)-xlims(1));
            text(xmin,0.9*ylims(2),{[num2str(nsat,'%.0f'),' saturated'],[satstr,' excluded']});
        end;
        hold off;
    end;
    
    % if 26Al ages exist
    if exist('plotm26');
        figure;
        hold on;
        
        % find number of saturated samples
        nsat = numel(find(plotm26(:,3) < 0));
        
        % remove saturated samples and samples without n26
        rmidx = find(plotm26(:,3) <= 0);
        plotm26(rmidx,:) = [];
        
        % vectors and matrices for probability estimation
        ages = plotm26(:,2);
        uncs = plotm26(:,4);
        agemin = min(ages - 4.*uncs);
        agemax = max(ages + 4.*uncs);
        timev = linspace(agemin,agemax,500);
        timem = repmat(timev,numel(ages),1);
        agesm = repmat(ages,1,numel(timev));
        uncsm = repmat(uncs,1,numel(timev));
        
        % estimate probability distr and sum
        probdensmatr = normpdf(timem,agesm,uncsm);
        probsum = sum(probdensmatr);
        
        if numel(ages)>1;
            % calculate weigthed mean age
            wage = sum(ages./uncs.^2)/sum(1./uncs.^2);
            wunc = (sum(1./uncs.^2.*(ages-wage).^2)/sum(1./uncs.^2)*(numel(ages)-1)/numel(ages))^0.5;
            wunc = sqrt(wunc^2 + (wage*delP_ref_nu26/P_ref_nu26)^2); % add prodrate uncertainty
            
            % plot grey Pref uncertainty region
            uncage = linspace(max(wage-wunc,agemin),min(wage+wunc,agemax),100);
            uncprob = interp1(timev,probsum,uncage,'pchip');
            uncage = [uncage,wage+wunc,wage-wunc];
            uncprob = [uncprob 0 0];
            patch(uncage,uncprob,'facecolor',[0.85 0.85 0.85],'EdgeColor','none');
            
            % plot Pref line
            wageprob = interp1(timev,probsum,wage,'pchip');
            plot([wage wage],[0 wageprob],'color','black');
        end;
        
        % plot individual sample prob dens curves
        for i = 1:rows(probdensmatr);
            plot(timev,probdensmatr(i,:),'color','red');
        end
        
        if numel(ages)>1;
            % plot summed prob dens curve
            plot(timev,sum(probdensmatr),'color','black');
        end;
        
        % fix plot
        axis([max(agemin,0) min(agemax,1E7)],'tic[x]','label[x]');
        xlabel('^{26}Al exposure age (yr)');
        ylabel('Relative probability');
        set(gca,'layer','top'); % plot axis on top
        if nsat > 0; % if saturated samples: display number of excluded samples
            if nsat == 1; satstr = 'sample'; else satstr = 'samples'; end;
            xlims = xlim;
            ylims = ylim;
            xmin = xlims(1) + 0.75*(xlims(2)-xlims(1));
            text(xmin,0.9*ylims(2),{[num2str(nsat,'%.0f'),' saturated'],[satstr,' excluded']});
        end;
        hold off;
    end;
end;
% end plotting =====================================================================================

toc()
