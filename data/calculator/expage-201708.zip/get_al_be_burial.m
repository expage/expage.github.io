function results = get_al_be_burial(sample,albe_consts,consts);

mc = 100000; % Monte Carlo size

% This function calculates the simple albe exposure and burial durations and packages the results.
%
% syntax : results = burial1026_get(sample,albe_consts,consts);
%
% argument sample is the structure assembled upstream by burial
%
% argument albe_consts is the al_be_consts structure derived from make_al_be_consts.m.
% Many required fields.
%
% argument consts is the LSD consts structure derived from make_consts_LSD.m. Many required fields.
%
% Code fixed and modified by Jakob Heyman 2015-2017 based mainly on code from the CRONUS calculator
% at http://hess.ess.washington.edu/math
%
% This program is free software; you can redistribute it and/or modify it under the terms of the GNU
% General Public License, version 2, as published by the Free Software Foundation (www.fsf.org).

% What version is this?
ver = '201708';

% Select appropriate values for nuclide of interest
% Atoms/g measurement
N10 = sample.N10; delN10 = sample.delN10;
N26 = sample.N26; delN26 = sample.delN26;
% Ref production rates
Pref10 = albe_consts.P10_ref_nu; delPref10 = albe_consts.delP10_ref_nu;
Pref26 = albe_consts.P26_ref_nu; delPref26 = albe_consts.delP26_ref_nu;
% Decay constants
l10 = albe_consts.l10;
l26 = albe_consts.l26;

% fix Rc SPhi and tv
LSDfix = LSD_fix(sample.lat,sample.long,1E7,-1,consts);

% interpolate Lsp (Sato, 2008; Marrero et al., 2016)
Lsp = rawattenuationlength(sample.pressure,LSDfix.RcEst);

% 1a. Thickness scaling factor.
if sample.thick > 0;
    thickSF = thickness(sample.thick,Lsp,sample.rho);
else 
    thickSF = 1;
end;

% nu production scaling
LSDnu = LSDspal(sample.pressure,LSDfix.RcEst,consts.SPhiInf,LSDfix.w,1,1,consts);

% randomized ref prod rates for Monte Carlo simulation
Pref10mc = normrnd(Pref10,delPref10,[mc,1]);
Pref26mc = normrnd(Pref26,delPref26,[mc,1]);

% spallation prod rates
P_nu10 = LSDnu.Be.*Pref10.*thickSF.*sample.othercorr;
P_nu26 = LSDnu.Al.*Pref26.*thickSF.*sample.othercorr;
P_nu10mc = LSDnu.Be.*Pref10mc.*thickSF.*sample.othercorr;
P_nu26mc = LSDnu.Al.*Pref26mc.*thickSF.*sample.othercorr;

% muon production
P_mu = P_mu_LSD((sample.thick.*sample.rho./2),sample.pressure,LSDfix.RcEst,consts.SPhiInf,1,1,...
    consts,'no');
P_mu10 = P_mu.Be.*sample.othercorr;
P_mu26 = P_mu.Al.*sample.othercorr;

% summed prod rates
P10 = P_nu10 + P_mu.Be;
P26 = P_nu26 + P_mu.Al;
P10mc = P_nu10mc + P_mu.Be;
P26mc = P_nu26mc + P_mu.Al;

% normalized N (sent out in result for plotting)
N10norm = N10./(P_nu10 + P_mu10);
N10norm_del = delN10./(P_nu10 + P_mu10);
N26norm = N26./(P_nu26 + P_mu26);
N26norm_del = delN26./(P_nu26 + P_mu26);

% randomized 10Be and 26Al concentrations for mc simulation
N10mc = normrnd(N10,delN10,[mc,1]);
N26mc = normrnd(N26,delN26,[mc,1]);

% test burial from -10M to 10M with 1M yr step
tv1 = (-10:1:10).*1e6;
burtest1 = 0;
burtest1mc = zeros(mc,1);
for i = 1:21;
    % calculate N before burial
    N10t1 = N10./exp(-l10.*tv1(i));
    N26t1 = N26./exp(-l26.*tv1(i));
    N10t1mc = N10mc./exp(-l10.*tv1(i));
    N26t1mc = N26mc./exp(-l26.*tv1(i));
    
    % check and exchange saturated N10 and N26
    N10t1 = N10t1.*(N10t1 <= P10./l10.*(1-exp(-l10.*1e7))) + ...
        (N10t1 > P10./l10.*(1-exp(-l10.*1e7))) .* P10./l10.*(1-exp(-l10.*1e7));
    N26t1 = N26t1.*(N26t1 <= P26./l26.*(1-exp(-l26.*1e7))) + ...
        (N26t1 > P26./l26.*(1-exp(-l26.*1e7))) .* P26./l26.*(1-exp(-l26.*1e7));
    N10t1mc = N10t1mc.*(N10t1mc <= P10mc./l10.*(1-exp(-l10.*1e7))) + ...
        (N10t1mc > P10mc./l10.*(1-exp(-l10.*1e7))) .* P10mc./l10.*(1-exp(-l10.*1e7));
    N26t1mc = N26t1mc.*(N26t1mc <= P26mc./l26.*(1-exp(-l26.*1e7))) + ...
        (N26t1mc > P26mc./l26.*(1-exp(-l26.*1e7))) .* P26mc./l26.*(1-exp(-l26.*1e7));
    
    % calculate simple exposure N26 assuming simple exposure N10t1
    N26t2 = P26./l26.*(1-exp(-l26.*log(1-N10t1.*l10./P10)./-l10));
    N26t2mc = P26mc./l26.*(1-exp(-l26.*log(1-N10t1mc.*l10./P10mc)./-l10));
    
    % test if N26 is too high (too long burial)
    burtest1 = burtest1 + (N26t1 < N26t2);
    burtest1mc = burtest1mc + (N26t1mc < N26t2mc);
end;

tv2 = 0;
tv2mc = zeros(mc,1);
burtest2 = zeros(1,6);
burtest2mc = zeros(mc,6);
for i = 1:6;
    tv2 = (burtest1-11).*1e6 + burtest2(1).*1e5 + burtest2(2).*1e4 + burtest2(3).*1e3 + ...
        burtest2(4).*100 + burtest2(5).*10 + burtest2(6); % time vector to start with
    tv2mc = (burtest1mc-11).*1e6 + burtest2mc(:,1).*1e5 + burtest2mc(:,2).*1e4 + ...
        burtest2mc(:,3).*1e3 + burtest2mc(:,4).*100 + burtest2mc(:,5).*10 + burtest2mc(:,6);
    
    for j = 1:10;
        % calculate N before burial
        N10t1 = N10./exp(-l10.*tv2);
        N26t1 = N26./exp(-l26.*tv2);
        N10t1mc = N10mc./exp(-l10.*tv2mc);
        N26t1mc = N26mc./exp(-l26.*tv2mc);
        
        % check and exchange saturated N10 and N26
        N10t1 = N10t1.*(N10t1 <= P10./l10.*(1-exp(-l10.*1e7))) + ...
            (N10t1 > P10./l10.*(1-exp(-l10.*1e7))) .* P10./l10.*(1-exp(-l10.*1e7));
        N26t1 = N26t1.*(N26t1 <= P26./l26.*(1-exp(-l26.*1e7))) + ...
            (N26t1 > P26./l26.*(1-exp(-l26.*1e7))) .* P26./l26.*(1-exp(-l26.*1e7));
        N10t1mc = N10t1mc.*(N10t1mc <= P10mc./l10.*(1-exp(-l10.*1e7))) + ...
            (N10t1mc > P10mc./l10.*(1-exp(-l10.*1e7))) .* P10mc./l10.*(1-exp(-l10.*1e7));
        N26t1mc = N26t1mc.*(N26t1mc <= P26mc./l26.*(1-exp(-l26.*1e7))) + ...
            (N26t1mc > P26mc./l26.*(1-exp(-l26.*1e7))) .* P26mc./l26.*(1-exp(-l26.*1e7));
        
        % calculate simple exposure N26 assuming simple exposure N10t1
        N26t2 = P26./l26.*(1-exp(-l26.*log(1-N10t1.*l10./P10)./-l10));
        N26t2mc = P26mc./l26.*(1-exp(-l26.*log(1-N10t1mc.*l10./P10mc)./-l10));
        
        % test if N26 is too high (too long burial)
        burtest2(1,i) = burtest2(1,i) + (N26t1 < N26t2);
        burtest2mc(:,i) = burtest2mc(:,i) + (N26t1mc < N26t2mc);
        
        % add time step to tv2
        tv2 = tv2 + 10^(6-i);
        tv2mc = tv2mc + 10^(6-i);
    end;
    burtest2(1,i) = burtest2(1,i)-1;
    burtest2mc(:,i) = burtest2mc(:,i)-1;
    clear tv2;
    clear tv2mc;
end;

% calculate burial ages
burialt = (burtest1-11).*1e6 + burtest2(1).*1e5 + burtest2(2).*1e4 + burtest2(3).*1e3 + ...
    burtest2(4).*100 + burtest2(5).*10 + burtest2(6);
burialtmc = (burtest1mc-11).*1e6 + burtest2mc(:,1).*1e5 + burtest2mc(:,2).*1e4 + ...
    burtest2mc(:,3).*1e3 + burtest2mc(:,4).*100 + burtest2mc(:,5).*10 + burtest2mc(:,6);

% calculate N at start of burial
burialN = N10./exp(-l10.*burialt);
burialNmc = N10mc./exp(-l10.*burialtmc);
% check and exchange saturated N10
burialN = burialN.*(burialN <= P10./l10.*(1-exp(-l10.*1e7))) + ...
    (burialN > P10./l10.*(1-exp(-l10.*1e7))) .* P10./l10.*(1-exp(-l10.*1e7));
burialNmc = burialNmc.*(burialNmc <= P10mc./l10.*(1-exp(-l10.*1e7))) + ...
    (burialNmc > P10mc./l10.*(1-exp(-l10.*1e7))) .* P10mc./l10.*(1-exp(-l10.*1e7));
% calculate simple exposure durations
expt = abs(log(1 - burialN.*l10./P10)./-l10);
exptmc = log(1 - burialNmc.*l10./P10mc)./-l10;

% calculate mean and stdev (mc simulation)
burialmc = mean(burialtmc);
del_burialmc = std(burialtmc);
expmc = mean(exptmc);
del_expmc = std(exptmc);

% fix for saturated samples
if round(expt)+del_expmc >= 1E7;
    del_expmc = -1; % signals 10Be saturation
end;

% max burial: 10 Ma
if burialt+del_burialmc >= 1E7;
    del_burialmc = -1; % signals too much burial
    if burialt > 1E7;
        burialt = 1E7;
    end;
end;

% max negative burial: 10 Ma
if burialt-del_burialmc <= -1E7;
    del_burialmc = -2; % signals too much negative burial
    if burialt < -1E7;
        burialt = -1E7;
    end;
end;

% 5. Results structure assignment
results.burial = burialt;
results.del_burial = del_burialmc;
results.expdur = expt;
results.del_expdur = del_expmc;
results.N10norm = N10norm;
results.N10norm_del = N10norm_del;
results.N26norm = N26norm;
results.N26norm_del = N26norm_del;
results.P10sp = P_nu10;
results.P26sp = P_nu26;
results.P_mu10 = P_mu10;
results.P_mu26 = P_mu26;
results.Lsp = Lsp;
results.RcEst = LSDfix.RcEst;
results.SPhiInf = consts.SPhiInf;
