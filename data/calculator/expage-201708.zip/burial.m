% Wrapper script for 10Be and 26Al burial/exposure age calculator.
% Read and fix input, use burial1026_get.m to calculate burial and exposure durations, and fix and
% write output. If plotting is on, display P-normalized 26/10 banana plot.
% This is free software: you can use/copy/modify/distribute as long as you keep it free.
% Jakob Heyman - 2015-2017 (jakob.heyman@gu.se)

clear all;

tic();

% What version is this?
ver = '201708';

% plot options, 1 = yes, 0 = no
expline = 1; % plot simple exposure line and burial lines
eline = 1; % plot erosion end point line
points = 1; % plot sample points
sigma1line = 1; % plot sample 1 sigma line
sigma2line = 0; % plot sample 2 sigma line
probcontours = 0; % plot probability contour lines

% write normalized conc data? (for later plotting)
normNout = 1;

% read input file
[samplein.sample_name,samplein.lat,samplein.long,samplein.elv,samplein.aa,samplein.thick,...
    samplein.rho,samplein.othercorr,samplein.E,samplein.N10,samplein.delN10,samplein.be_stds,...
    samplein.N26,samplein.delN26,samplein.al_stds,samplein.samplingyr] = ...
    textread('input.txt','%s %n %n %n %s %n %n %n %n %n %n %s %n %n %s %n');

% run and load al_be constants
make_al_be_consts;
load al_be_consts;

% run and load consts_LSD
make_consts_LSD;
load consts_LSD;

% convert 10Be concentrations according to standards
for i = 1:numel(samplein.N10);
    be_mult(i,1) = al_be_consts.be_stds_cfs(strcmp(samplein.be_stds(i),al_be_consts.be_stds_names));
end;
samplein.N10 = samplein.N10 .* be_mult;
samplein.delN10 = samplein.delN10 .* be_mult;

% convert 26Al concentrations according to standards
for i = 1:numel(samplein.N26);
    al_mult(i,1) = al_be_consts.al_stds_cfs(strcmp(samplein.al_stds(i),al_be_consts.al_stds_names));
end;
samplein.N26 = samplein.N26 .* al_mult;
samplein.delN26 = samplein.delN26 .* al_mult;

% fix erosion rate unit (mm/ka -> cm/yr)
samplein.E = samplein.E .* 1E-4;

% decay constants
l10 = al_be_consts.l10;
l26 = al_be_consts.l26;

n1026 = 0; % for plot data

% pick out samples one by one
for i = 1:numel(samplein.lat);
    sample.sample_name = samplein.sample_name(i,:);
    sample.lat = samplein.lat(i);
    sample.long = samplein.long(i);
    sample.elv = samplein.elv(i);
    sample.aa = samplein.aa(i,:);
    sample.thick = samplein.thick(i);
    sample.rho = samplein.rho(i);
    sample.othercorr = samplein.othercorr(i);
    sample.E = samplein.E(i);
    sample.N10 = samplein.N10(i);
    sample.delN10 = samplein.delN10(i);
    sample.be_stds = samplein.be_stds(i,:);
    sample.N26 = samplein.N26(i);
    sample.delN26 = samplein.delN26(i);
    sample.al_stds = samplein.al_stds(i,:);
    sample.samplingyr = samplein.samplingyr(i);
    
    % write sample name to output
    output(i,1) = sample.sample_name;
    
    % calculate simple exposure and burial ages
    if (sample.N10 + sample.delN10) .* (sample.N26 + sample.delN26) > 0;
        n1026 = n1026+1;
        
        % display sample name
        fprintf(1,'%.0f. %s',i,sample.sample_name{1});
        
        % define sample site atmospheric pressure
        if (strcmp(sample.aa,'std'));
            sample.pressure = ERA40atm(sample.lat,sample.long,sample.elv);
        elseif (strcmp(sample.aa,'ant'));
            sample.pressure = antatm(sample.elv);
        elseif (strcmp(sample.aa,'pre'));
            sample.pressure = sample.elv;
        end;
        
        % do calculations
        results = get_al_be_burial(sample,al_be_consts,consts);
        
        % write to output
        output(i,2) = num2str(results.expdur,'%.0f');
        output(i,3) = num2str(results.del_expdur,'%.0f');
        output(i,4) = num2str(results.burial,'%.0f');
        output(i,5) = num2str(results.del_burial,'%.0f');
        
        if normNout > 0; % if writing normalized conc data
            output(i,6) = num2str(results.N10norm,'%.6f');
            output(i,7) = num2str(results.N10norm_del,'%.6f');
            output(i,8) = num2str(results.N26norm,'%.6f');
            output(i,9) = num2str(results.N26norm_del,'%.6f');
        end;
        
        % display exposure and fix if saturated
        if results.del_expdur >= 0; % if initial exposure within bounds
            fprintf(1,' \texposure = %s ± %s yr',output{i,2},output{i,3});
        else;
            output(i,2) = strcat('>',num2str(results.expdur,'%.0f'));
            output(i,3) = '-';
            fprintf(1,' \texposure: %s yr (saturated 10Be)',output{i,2});
        end;
        
        % display burial and fix if too much/too negative
        if results.del_burial >= 0; % if burial within bounds
            % display results
            fprintf(1,' \tburial = %s ± %s yr\n',output{i,4},output{i,5});
        else;
            if results.del_burial == -1; % if too much burial
                burchar = '>';
            elseif results.del_burial == -2; % if too much negative burial
                burchar = '<';
            end;
            output(i,4) = strcat(burchar,num2str(results.burial,'%.0f'));
            output(i,5) = '-';
            fprintf(1,' \tburial: %s yr\n',output{i,4});
        end;
        
        % for plotting
        N10n(n1026,1) = results.N10norm;
        N10n_del(n1026,1) = results.N10norm_del;
        N26n(n1026,1) = results.N26norm;
        N26n_del(n1026,1) = results.N26norm_del;
        P10sp(n1026,1) = results.P10sp;
        P26sp(n1026,1) = results.P26sp;
        P_mu10(n1026,1) = results.P_mu10;
        P_mu26(n1026,1) = results.P_mu26;
        Lsp(n1026,1) = results.Lsp;
        RcEst(n1026,1) = results.RcEst;
        SPhiAv(n1026,1) = results.SPhiInf;
        thick_rho(n1026,1) = sample.thick * sample.rho;
        rho(n1026,1) = sample.rho;
        atm(n1026,1) = sample.pressure;
        othercorr(n1026,1) = sample.othercorr;
    end;
    
    clear sample;
end;

% plotting =========================================================================================
if (expline + eline + points + sigma1line + sigma2line + probcontours) > 0;
    set(gcf,'visible','off'); % hide plots
    hold on;
end;

% simple exposure line,
if expline > 0;
    % create data for the simple-exposure line including ratio uncertainties
    tempt = logspace(0,7,100);
    be = (1/l10)*(1-exp(-l10*tempt));
    al = (1/l26)*(1-exp(-l26*tempt));
    al_be = al./be;
    
    albe_P_del = sqrt((al_be_consts.delP10_ref_nu./al_be_consts.P10_ref_nu)^2 + ...
        (al_be_consts.delP26_ref_nu./al_be_consts.P26_ref_nu)^2);
    al_be_high = al_be.*(1 + albe_P_del);
    al_be_low = al_be.*(1 - albe_P_del);
    
    % plot ratio uncertainty area and simple exposure line
    patch([be flip(be)],[al_be_high flip(al_be_low)],'facecolor',[0.9 0.9 0.9],'EdgeColor','none');
    semilogx(be,al_be,'color','black');
    
    % make data for simple burial lines
    bu_be50 = be.*exp(-l10*500000);
    bu_al50 = al.*exp(-l26*500000);
    bu_be100 = be.*exp(-l10*1000000);
    bu_al100 = al.*exp(-l26*1000000);
    bu_be150 = be.*exp(-l10*1500000);
    bu_al150 = al.*exp(-l26*1500000);
    bu_be200 = be.*exp(-l10*2000000);
    bu_al200 = al.*exp(-l26*2000000);
    bu_be250 = be.*exp(-l10*2500000);
    bu_al250 = al.*exp(-l26*2500000);
    bu_be300 = be.*exp(-l10*3000000);
    bu_al300 = al.*exp(-l26*3000000);
    
    % plot simple burial lines
    semilogx(bu_be50,bu_al50./bu_be50,'b');
    semilogx(bu_be100,bu_al100./bu_be100,'b');
    semilogx(bu_be150,bu_al150./bu_be150,'b');
    semilogx(bu_be200,bu_al200./bu_be200,'b');
    semilogx(bu_be250,bu_al250./bu_be250,'b');
    semilogx(bu_be300,bu_al300./bu_be300,'b');
    
    % make data for burial pathways
    burv = (0:1E5:1E7);
    path_be10 = (1/l10)*(1-exp(-l10*1E4)).*exp(-l10.*burv);
    path_be100 = (1/l10)*(1-exp(-l10*1E5)).*exp(-l10.*burv);
    path_be1000 = (1/l10)*(1-exp(-l10*1E6)).*exp(-l10.*burv);
    path_be10000 = (1/l10)*(1-exp(-l10*1E7)).*exp(-l10.*burv);
    path_al10 = (1/l26)*(1-exp(-l26*1E4)).*exp(-l26.*burv);
    path_al100 = (1/l26)*(1-exp(-l26*1E5)).*exp(-l26.*burv);
    path_al1000 = (1/l26)*(1-exp(-l26*1E6)).*exp(-l26.*burv);
    path_al10000 = (1/l26)*(1-exp(-l26*1E7)).*exp(-l26.*burv);
    
    % plot burial pathways
    semilogx(path_be10,path_al10./path_be10,'linestyle','--','color','blue');
    semilogx(path_be100,path_al100./path_be100,'linestyle','--','color','blue');
    semilogx(path_be1000,path_al1000./path_be1000,'linestyle','--','color','blue');
    semilogx(path_be10000,path_al10000./path_be10000,'linestyle','--','color','blue');
end;

% erosion line
if eline > 0;
    fprintf(1,'calculating erosion end-point line...');
    % Precompute P_mu(z) to ~200,000 g/cm2 
    % start at the average sample mid-depth.
    z_sp = [0 logspace(0,5.3,100)];
    z_mu = z_sp+(mean(thick_rho)./2);
    P_mu_z = P_mu_LSD(z_mu,mean(atm),mean(RcEst),mean(SPhiAv),1,1,consts,'no');
    P_mu_z10 = P_mu_z.Be.*mean(othercorr);
    P_mu_z26 = P_mu_z.Al.*mean(othercorr);
    P10sp_z = mean(P10sp).*exp(-z_sp./mean(Lsp));
    P26sp_z = mean(P26sp).*exp(-z_sp./mean(Lsp));
    
    tempe = logspace(-5,1,100);
    for j = 1:numel(tempe);
        tv = z_sp./tempe(j);
        dcf10 = exp(-tv.*l10);
        dcf26 = exp(-tv.*l26);
        N10tv = cumtrapz(tv,(P10sp_z.*dcf10 + P_mu_z10.*dcf10));
        N26tv = cumtrapz(tv,(P26sp_z.*dcf26 + P_mu_z26.*dcf26));
        bee(j,1) = N10tv(end)./(mean(P10sp) + mean(P_mu10));
        ale(j,1) = N26tv(end)./(mean(P26sp) + mean(P_mu26));
    end;
    bee2(1,1) = be(end);
    ale2(1,1) = al(end);
    bee2(2:numel(bee)+1,1) = bee;
    ale2(2:numel(ale)+1,1) = ale;
    
    ale_bee = ale2./bee2;
    semilogx(bee2,ale_bee,'linestyle','--','color','black');
    fprintf(1,' done!\n');
end;

% probability contours
if probcontours > 0;
    % Estimate range and create mesh
    Rv = N26n./N10n;
    delRv = sqrt((N26n_del./N26n).^2 + (N10n_del./N10n).^2);
    
    xmin = min(N10n - 4.*N10n_del);
    xmax = max(N10n + 4.*N10n_del);
    Rmin = min(Rv.*(1 - 4.*delRv));
    Rmax = max(Rv.*(1 + 4.*delRv));
    
    [xa,ya] = meshgrid(xmin:0.1 * mean(N10n_del):xmax,Rmin:0.1.*mean(Rv).*mean(delRv):Rmax);
    
    Proba = zeros(rows(xa),columns(xa));
    
    for j = 1:numel(N10n(:,1));
        % calculate PDF
        Proba1 = xa.*exp(-0.5.*(((ya.*xa-N26n(j))./N26n_del(j)).^2+((xa-N10n(j))./N10n_del(j)).^2));
        Proba = Proba + Proba1;
    end;
    
    contour(xa,ya,Proba);
end;

% sigma lines
if sigma1line+sigma2line > 0;
    % loop for each sample with al/be data
    for j = 1:n1026;
        % only do plotting if N10 > 0
        if N10n(j) > 0;
            % Estimate range and create mesh
            R = (N26n(j)/N10n(j));
            delR = sqrt((N26n_del(j) / N26n(j))^2 + (N10n_del(j) / N10n(j))^2);
            
            [x,y] = meshgrid((N10n(j) - 4 * N10n_del(j)):(0.1 * N10n_del(j)):(N10n(j) + 4 * ...
                N10n_del(j)),(R * (1 - 4 * delR)):(0.1 * R * delR):(R * (1 + 4 * delR)));
            
            % calculate PDF
            Prob = x .* exp(-0.5 .* ((((y .* x) - N26n(j)) ./ N26n_del(j)).^2 + ...
                ((x - N10n(j)) ./ N10n_del(j)).^2));
            
            % Now find the 68% probability contour.
            % Normalize to volume = 1
            normP = Prob ./ sum(sum(Prob));
            
            % Now we need to figure out cumulative probabilities.
            % multiply by 10000 to achieve manageable number of values, round to get integers:
            normP = normP * 10000;
            intP = round(normP);
            
            for a = 1:max(max(intP));
                cumprob(a) = sum(intP(find(intP >= a)))/10000;
            end;
            
            probs = 1:max(max(intP));
            sigma1 = find(abs(cumprob - 0.6827) == min(abs(cumprob - 0.6827)));
            sigma2 = find(abs(cumprob - 0.9545) == min(abs(cumprob - 0.9545)));
            
            % weed out cases where adjacent probs are same -- rounding error
            if length(sigma1) ~= 1;
                sigma1 = min(sigma1);
            end;
            
            if length(sigma2) ~= 1;
                sigma2 = min(sigma2);
            end;
            
            % Now draw the contours.
            cmat = contourc(x(1,:),y(:,1),normP,[sigma1 sigma2]);
            
            if sigma1line > 0;
                % Sometimes contourc returns a bunch of contours for one level -- grid size issue?
                % This is spurious, so plot only the major one.
                contourStarts = find(cmat(1,:) == sigma1);
                contourSizes = cmat(2,contourStarts);
                contourToPlot = find(contourSizes == max(contourSizes));
                
                x1 = cmat(1,(contourStarts(contourToPlot)+1):(contourStarts(contourToPlot) + ...
                    contourSizes(contourToPlot)));
                y1 = cmat(2,(contourStarts(contourToPlot)+1):(contourStarts(contourToPlot) + ...
                    contourSizes(contourToPlot)));
                
                % plot 1 sigma uncertainty
                sd1 = plot(x1,y1,'color','red');
            end;
            
            if sigma2line > 0;
                % for sigma2 lines
                contourStarts = find(cmat(1,:) == sigma2);
                contourSizes = cmat(2,contourStarts);
                contourToPlot = find(contourSizes == max(contourSizes));
                
                x2 = cmat(1,(contourStarts(contourToPlot)+1):(contourStarts(contourToPlot) + ...
                    contourSizes(contourToPlot)));
                y2 = cmat(2,(contourStarts(contourToPlot)+1):(contourStarts(contourToPlot) + ...
                    contourSizes(contourToPlot)));
                
                % plot 2 sigma uncertainty
                sd2 = plot(x2,y2,'color','red');
            end;
        end;
    end;
end;

% sample points
if points > 0;
    for j = 1:n1026;
        % only do plotting if N10 > 0
        if N10n(j) > 0;
            plot(N10n(j),N26n(j)/N10n(j),'.','color','red','markersize',15);
        end;
    end;
end;

% fix and display plot
if (expline + eline + points + sigma1line + sigma2line + probcontours) > 0;
    % fix axis
    axis([1000 3000000 0.2 1.2]);
    xlabel('[^{10}Be]*');
    ylabel('[^{26}Al]*/[^{10}Be]*');
    
    set(gca,'layer','top'); % plot axis on top
    
    set(gcf,'visible','on'); % display plot
    hold off;
end;

% fix and save output ==============================================================================
% fix header and output string
outhead(1,:) = {'sample','exposure(yr)','exp-unc(yr)','burial(yr)','bur-unc(yr)'};
outstr = '%s\t%s\t%s\t%s\t%s\n';

% if writing normalized conc data
if normNout > 0;
    outhead(1,end+1:end+4) = {'N10norm','N10unc','N26norm','N26unc'};
    outstr = '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n';
end;

% add headers
output(2:end+1,:) = output;
output(1,:) = outhead;

% fill empty cells with '-'
nullidx = cellfun(@isempty,output);
output(nullidx) = '-';

% write out-burial.txt
if sum(samplein.N10 + samplein.delN10 + samplein.N26 + samplein.delN26)>0;
    out = fopen('out-burial.txt','w');
    for i = 1:rows(output);
        fprintf(out,outstr,output{i,:});
    end;
    fclose(out);
end;

toc()
