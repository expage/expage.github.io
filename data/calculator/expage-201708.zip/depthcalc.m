% Depth profile 10Be/26Al exposure age calculator calculating the best fit depth profile exposure
% age. The calculation is done using the expage calculator production rates (nuclide-specific LSD
% scaling). At least two concentrations must be given for the calculator to work.
% This is free software: you can use/copy/modify/distribute as long as you keep it free.
% Jakob Heyman - 2015-2017 (jakob.heyman@gu.se)

clear all;

% plotting? 1 = yes, 0 = no
% disabling plotting speeds up the calculation
plotting = 1;

tic();

% What version is this?
ver = '201708';

% read input file
% NOTE! sample thickness in standard input is here changed to sample mid-point depth (cm)
[sample_name,lat,long,elv,aa,depth,rho,othercorr,erosion,N10,delN10,be_stds,N26,delN26,al_stds,...
    samplingyr] = textread('input.txt','%s %n %n %n %s %n %n %n %n %n %n %s %n %n %s %n');

% run and load al_be constants
make_al_be_consts;
load al_be_consts;

% run and load LSD consts
make_consts_LSD;
load consts_LSD;

% constants
P_ref_nu10 = al_be_consts.P10_ref_nu; delP_ref_nu10 = al_be_consts.delP10_ref_nu;
P_ref_nu26 = al_be_consts.P26_ref_nu; delP_ref_nu26 = al_be_consts.delP26_ref_nu;
% Decay constant
l10 = al_be_consts.l10; dell10 = al_be_consts.dell10;
l26 = al_be_consts.l26; dell26 = al_be_consts.dell26;

% convert 10Be concentrations according to standards
for i = 1:numel(N10);
    mult10(i,1) = al_be_consts.be_stds_cfs(strcmp(be_stds(i),al_be_consts.be_stds_names));
end;
N10 = N10 .* mult10;
delN10 = delN10 .* mult10;

% convert 26Al concentrations according to standards
for i = 1:numel(N26);
    mult26(i,1) = al_be_consts.al_stds_cfs(strcmp(al_stds(i),al_be_consts.al_stds_names));
end;
N26 = N26 .* mult26;
delN26 = delN26 .* mult26;

% fix erosion rate unit (mm/ka -> cm/yr)
erosion = erosion .* 1E-4;

% check and fix inputs =============================================================================
diffstr = '';

if sum(lat ~= lat(1)) > 0;
    diffstr = [diffstr,' latitude'];
end;
if sum(long ~= long(1)) > 0;
    diffstr = [diffstr,' longitude'];
end;
if sum(elv ~= elv(1)) > 0;
    if (strcmp(aa(1),'pre'));
        diffstr = [diffstr,' atm-pressure'];
    else;
        diffstr = [diffstr,' elevation'];
    end;
end;
if sum(rho ~= rho(1)) > 0;
    diffstr = [diffstr,' density'];
end;
if sum(erosion ~= erosion(1)) > 0;
    diffstr = [diffstr,' erosion'];
end;
if sum(othercorr ~= othercorr(1)) > 0;
    diffstr = [diffstr,' shielding'];
end;

% if differences...
if numel(diffstr) > 0;
    fprintf(1,'The input samples have differences in the following parameter');
    if numel(diffstr) > 14; fprintf(1,'s'); end;
    fprintf(1,':%s\n',diffstr);
end;

lat = mean(lat);
long = mean(long);
elv = mean(elv);
shield = mean(othercorr);
rho = mean(rho);
erosion = mean(erosion);
samplingyr = mean(samplingyr);
% ==================================================================================================

% Define sample site atmospheric pressure
atm = ERA40atm(lat,long,elv);

% Set nucl to 0 for both 10/26
nucl10 = 0; nucl26 = 0;

% Check if 10Be and 26Al is measured
n10test = find(N10+delN10 > 0);
n26test = find(N26+delN26 > 0);
N10 = N10(n10test);
N26 = N26(n26test);
delN10 = delN10(n10test);
delN26 = delN26(n26test);
dv10 = depth(n10test);
dv26 = depth(n26test);
sample10 = sample_name(n10test);
sample26 = sample_name(n26test);
if numel(N10)>1; nucl10 = 1; end;
if numel(N26)>1; nucl26 = 1; end;

% catch for negative longitudes before Rc interpolation
if long < 0; long = long + 360; end;

% Age Relative to t0=2010 - LSD tv from LSDfix
% tv = [0:10:50 60:100:50060 51060:1000:2000060 logspace(log10(2001060),7,200)];

% Fix w,Rc,SPhi, for sp and mu prod rate scaling
LSDfix = LSD_fix(lat,long,1e7,-1,consts);

% time vector tv1
tv1 = LSDfix.tv;

% adjust tv, Rc, and SPhi to sampling year
if samplingyr <= 2010;
    clipidx = min(find(tv1 > 2010-samplingyr));
    tv = [2010-samplingyr tv1(clipidx:end)];
    Rc = interp1(tv1,LSDfix.Rc,tv);
    SPhi = interp1(tv1,LSDfix.SPhi,tv);
    tv = tv - 2010 + samplingyr;
else; % assume 2010 value for all years >2010
    Rc = [LSDfix.Rc(1) LSDfix.Rc];
    SPhi = [LSDfix.SPhi(1) LSDfix.SPhi];
    tv = [0 (tv1 + samplingyr - 2010)];
end;

% muon production
if erosion > 0;
    % depth vector for Pmu calculation
    derosion = linspace(min(depth),1e7.*erosion + max(depth),50);
    
    % calculate Pmu for depth vector
    P_mu = P_mu_LSD(derosion.*rho,atm,LSDfix.RcEst,consts.SPhiInf,nucl10,nucl26,consts,'no');
    
    % interpolate Pmu for individual samples
    if nucl10 == 1;
        for i = 1:numel(dv10);
            Pmu10(i,:) = interp1(derosion,P_mu.Be,dv10(i)+tv.*erosion,'pchip') .* shield;
        end;
    end;
    if nucl26 == 1;
        for i = 1:numel(dv26);
            Pmu26(i,:) = interp1(derosion,P_mu.Al,dv26(i)+tv.*erosion,'pchip') .* shield;
        end;
    end;
else; % no erosion
    P_mu = P_mu_LSD(depth.*rho,atm,LSDfix.RcEst,consts.SPhiInf,nucl10,nucl26,consts,'no');
    
    % pick out Pmu if data exists
    if nucl10 == 1; Pmu10 = P_mu.Be'(n10test) .* shield; end;
    if nucl26 == 1; Pmu26 = P_mu.Al'(n26test) .* shield; end;
end;

% spallation surface production scaling
Psp0 = LSDspal(atm,Rc,SPhi,LSDfix.w,nucl10,nucl26,consts);

% interpolate Lsp using CRONUScalc method (Sato 2008; Marrero et al. 2016)
Lsp = rawattenuationlength(atm,Rc);

% pick out Psp if data exists
if nucl10 == 1;
    for i = 1:numel(N10);
        Psp10(i,:) = Psp0.Be .* P_ref_nu10 .* shield .* exp(-rho.*(tv.*erosion+dv10(i))./Lsp);
    end;
end;
if nucl26 == 1;
    for i = 1:numel(N26);
        Psp26(i,:) = Psp0.Al .* P_ref_nu26 .* shield .* exp(-rho.*(tv.*erosion+dv26(i))./Lsp);
    end;
end;

% Calculate N(t) including decay
if nucl10 == 1; % if 10Be exists
    dcf10 = exp(-tv.*l10); % decay factor;
    for i = 1:numel(N10);
        N_nu10(i,:) = cumtrapz(tv,(Psp10(i,:).*dcf10 + Pmu10(i).*dcf10)); % potential N back in time
        % test saturation
        if N10(i) <= max(N_nu10(i,:));
            tt(i,1) = interp1(N_nu10(i,:),tv,N10(i)); % individual sample exposure age
        else;
            fprintf(1,'Sample %s appears to be saturated in 10Be!\n',sample10{i});
            tt(i,1) = 1E7;
        end;
        
        % uncertainty estimate
        % A with integrated average Lsp
        if tt(i,1) > 0;
            Lsp_avg = interp1(tv,cumtrapz(tv,Lsp),tt(i,1))./tt(i,1);
            A = l10./Lsp_avg;
            FP = (N10(i).*A)./(1 - exp(-A.*tt(i,1)));
            dtdN = 1./(FP - N10(i).*A);
            deltt(i,1) = sqrt(dtdN.^2 * delN10(i).^2);
        else; % t = 0, estimate uncertainty based on conc + unc
            deltt(i,1) = interp1(N_nu10(i,:),tv,N10(i)+delN10(i));
        end;
    end;
    
    % find min and max value for interpolation and make new time vector
    minage10 = round(min(tt) - (max(tt)-min(tt)));
    maxage10 = round(max(tt) + (max(tt)-min(tt)));
    if minage10 < 0; minage10 = 0; end;
    if maxage10 > 1e7; maxage10 = 1e7; end;
    tv10 = (minage10:1:maxage10);
    
    % interpret N vectors
    for i = 1:numel(N10);
        N_nu10v(i,:) = interp1(tv,N_nu10(i,:),tv10);
    end;
    
    % calculate chi square vector
    N10m = repmat(N10,1,numel(tv10));
    delN10m = repmat(delN10,1,numel(tv10));
    chi2v = sum((N_nu10v-N10m).^2 ./ delN10m.^2);
    
    % find minimum chi square and index
    [chimin10,idx10] = min(chi2v);
    
    % find best fit age (depth profile age)
    age10 = tv10(idx10);
    
    % estimate depth profile age uncertainty
    age10unc_int = sqrt(1./sum(deltt.^-2) .* 1./(numel(N10)-1) .* sum((age10-tt).^2./deltt.^2));
    age10unc_ext = sqrt(age10unc_int.^2 + (delP_ref_nu10./P_ref_nu10.*age10).^2);
    
    Rchi2_10 = chimin10./(numel(N10)-1);
    Pvalue10 = 1 - chi2cdf(chimin10,numel(N10)-1);
    
    fprintf(1,'10Be age = %.0f ± %.0f (%.0f) yr    R-chisq = %.3f    P-value = %.3f\n',...
        age10,age10unc_ext,age10unc_int,Rchi2_10,Pvalue10);
end;

if nucl26 == 1; % if 26Al exists
    dcf26 = exp(-tv.*l26); % decay factor;
    for i = 1:numel(N26);
        N_nu26(i,:) = cumtrapz(tv,(Psp26(i,:).*dcf26 + Pmu26(i).*dcf26)); % potential N back in time
        % test saturation
        if N26(i) <= max(N_nu26(i,:));
            tt(i,1) = interp1(N_nu26(i,:),tv,N26(i)); % individual sample exposure age
        else;
            fprintf(1,'Sample %s appears to be saturated in 26Al!\n',sample26{i});
            tt(i,1) = 1E7;
        end;
        
        % uncertainty estimate
        % A with integrated average Lsp
        if tt(i,1) > 0;
            Lsp_avg = interp1(tv,cumtrapz(tv,Lsp),tt(i,1))./tt(i,1);
            A = l26./Lsp_avg;
            FP = (N26(i).*A)./(1 - exp(-A.*tt(i,1)));
            dtdN = 1./(FP - N26(i).*A);
            deltt(i,1) = sqrt(dtdN.^2 * delN26(i).^2);
        else; % t = 0, estimate uncertainty based on conc + unc
            deltt(i,1) = interp1(N_nu26(i,:),tv,N26(i)+delN26(i));
        end;
    end;
    
    % find min and max value for interpolation and make new time vector
    minage26 = round(min(tt) - (max(tt)-min(tt)));
    maxage26 = round(max(tt) + (max(tt)-min(tt)));
    if minage26 < 0; minage26 = 0; end;
    if maxage26 > 1e7; maxage26 = 1e7; end;
    tv26 = (minage26:1:maxage26);
    
    % interpret N vectors
    for i = 1:numel(N26);
        N_nu26v(i,:) = interp1(tv,N_nu26(i,:),tv26);
    end;
    
    % calculate chi square vector
    N26m = repmat(N26,1,numel(tv26));
    delN26m = repmat(delN26,1,numel(tv26));
    chi2v = sum((N_nu26v-N26m).^2 ./ delN26m.^2);
    
    % find minimum chi square and index
    [chimin26,idx26] = min(chi2v);
    
    % find best fit age (depth profile age)
    age26 = tv26(idx26);
    
    % estimate depth profile age uncertainty
    age26unc_int = sqrt(1./sum(deltt.^-2) .* 1./(numel(N26)-1) .* sum((age26-tt).^2./deltt.^2));
    age26unc_ext = sqrt(age26unc_int.^2 + (delP_ref_nu26./P_ref_nu26.*age26).^2);
    
    Rchi2_26 = chimin26./(numel(N26)-1);
    Pvalue26 = 1 - chi2cdf(chimin26,numel(N26)-1);
    
    fprintf(1,'26Al age = %.0f ± %.0f (%.0f) yr    R-chisq = %.3f    P-value = %.3f\n',...
        age26,age26unc_ext,age26unc_int,Rchi2_26,Pvalue26);
end;


% plotting =========================================================================================
if plotting == 1;
    % make depth vect for plotting
    dplot = linspace(0,max(depth).*1.25,50);
    
    if erosion > 0;
        % pick out oldest age of 10/26
        agetest = [];
        if nucl10 == 1; agetest(end+1) = age10; end;
        if nucl26 == 1; agetest(end+1) = age26; end;
        agemax = max(agetest);
        
        %make depth vect for mu
        dplotmu = linspace(0,max(depth).*1.5 + agemax.*erosion,50);
    else; % if no erosion
        % make depth vect for mu
        dplotmu = dplot;
    end;
    
    % muon production for depth profile points
    fprintf('calculating depth profile P from muons...\n');
    Pmuplot = P_mu_LSD(dplotmu.*rho,atm,LSDfix.RcEst,consts.SPhiInf,nucl10,nucl26,consts,'no');
    
    if nucl10 == 1; % if 10Be exists and plotting = yes
        % clip Psp0 and Lsp for depth profile age
        clipidx10 = max(find(tv < age10));
        tvplot = [tv(1:clipidx10) age10];
        Psp0plot10 = interp1(tv,Psp0.Be,tvplot);
        Lspplot = interp1(tv,Lsp,tvplot);
        
        dcf10plot = exp(-tvplot.*l10); % decay factor;
        
        % pick out Pmu
        if erosion > 0;
            for i = 1:numel(dplot);
                % muon production for depth profile points
                Pmu10plot(i,:) = interp1(dplotmu,Pmuplot.Be.*shield,dplot(i)+tvplot.*erosion);
            end;
        else;
            % muon production for depth profile points
            Pmu10plot = Pmuplot.Be' .* shield;
        end;
        
        % calculate Psp for depth profile points
        for i = 1:numel(dplot);
            Psp10plot(i,:) = Psp0plot10 .* P_ref_nu10 .* shield .* ...
                exp(-rho.*(tvplot.*erosion+dplot(i))./Lspplot);
        end;
        
        % calculate N after age10 yr
        for i = 1:numel(dplot);
            N10plot(i,:) = trapz(tvplot,(Psp10plot(i,:).*dcf10plot + Pmu10plot(i).*dcf10plot));
        end;
        
        figure(1);
        hold on;
        
        % plot standard depth profile
        plot(N10plot,dplot,'color','black');
        plot(N10,dv10,'.','color','red','markersize',15);
        for i = 1:numel(N10);
            plot([N10(i)-delN10(i),N10(i)+delN10(i)],[dv10(i),dv10(i)],'r');
        end;
        
        axis('ij');
        set(gca,'xaxislocation','top');
        xlabel('^{10}Be (atoms/g)');
        ylabel('Depth (cm)');
        
        hold off
    end;

    if nucl26 == 1; % if 26Be exists and plotting = yes
        % clip Psp0 and Lsp for depth profile age
        clipidx26 = max(find(tv < age26));
        tvplot = [tv(1:clipidx26) age26];
        Psp0plot26 = interp1(tv,Psp0.Be,tvplot);
        Lspplot = interp1(tv,Lsp,tvplot);
        
        dcf26plot = exp(-tvplot.*l26); % decay factor;
        
        % pick out Pmu
        if erosion > 0;
            for i = 1:numel(dplot);
                % muon production for depth profile points
                Pmu26plot(i,:) = interp1(dplotmu,Pmuplot.Be.*shield,dplot(i)+tvplot.*erosion);
            end;
        else;
            % muon production for depth profile points
            Pmu26plot = Pmuplot.Be' .* shield;
        end;
        
        % calculate Psp for depth profile points
        for i = 1:numel(dplot);
            Psp26plot(i,:) = Psp0plot26 .* P_ref_nu26 .* shield .* ...
                exp(-rho.*(tvplot.*erosion+dplot(i))./Lspplot);
        end;
        
        % calculate N after age26 yr
        for i = 1:numel(dplot);
            N26plot(i,:) = trapz(tvplot,(Psp26plot(i,:).*dcf26plot + Pmu26plot(i).*dcf26plot));
        end;
        
        figure(2);
        hold on;
        
        % plot standard depth profile
        plot(N26plot,dplot,'color','black');
        plot(N26,dv26,'.','color','red','markersize',15);
        for i = 1:numel(N26);
            plot([N26(i)-delN26(i),N26(i)+delN26(i)],[dv26(i),dv26(i)],'r');
        end;
        
        axis('ij');
        set(gca,'xaxislocation','top');
        xlabel('^{26}Al (atoms/g)');
        ylabel('Depth (cm)');
        
        hold off
    end;
end;
% end plotting =====================================================================================

toc()
