% Calculator for 10Be and 26Al erosion depth calculation for cases with prior exposure and a known
% exposure-burial-exposure history defined by age1 (time of initial exposure), age2 (time of initial
% burial), and age3 (time of last exposure / end of burial).
% This is free software: you can use/copy/modify/distribute as long as you keep it free.
% Jakob Heyman - 2015-2017 (jakob.heyman@gu.se)

clear all;

tic();

% What version is this?
ver = '201708';

% max depth to check for prior exposure and number of depth points for production interpolation
maxd = 400; % (cm)
dpoints = 101; % number of points in depth vector

% read input file
[samplein.sample_name,samplein.lat,samplein.long,samplein.elv,samplein.aa,samplein.thick,...
    samplein.rho,samplein.othercorr,samplein.E,samplein.N10,samplein.delN10,samplein.be_stds,...
    samplein.N26,samplein.delN26,samplein.al_stds,samplein.samplingyr,samplein.age1,...
    samplein.age2,samplein.age3] = ...
    textread('input.txt','%s %n %n %n %s %n %n %n %n %n %n %s %n %n %s %n %n %n %n');

% run and load al_be constants
make_al_be_consts;
load al_be_consts;

% run and load LSD consts
make_consts_LSD;
load consts_LSD;

% display max depth testing
fprintf(1,'max erosion depth: %.0f cm   (maxd in preexpE.m line 15)\n',maxd);

% constants
Pref10 = al_be_consts.P10_ref_nu; delPref10 = al_be_consts.delP10_ref_nu;
Pref26 = al_be_consts.P26_ref_nu; delPref26 = al_be_consts.delP26_ref_nu;
% Decay constant
l10 = al_be_consts.l10; dell10 = al_be_consts.dell10;
l26 = al_be_consts.l26; dell26 = al_be_consts.dell26;

% convert 10Be concentrations according to standards
for i = 1:numel(samplein.N10);
    be_mult(i,1) = al_be_consts.be_stds_cfs(strcmp(samplein.be_stds(i),al_be_consts.be_stds_names));
end;
samplein.N10 = samplein.N10 .* be_mult;
samplein.delN10 = samplein.delN10 .* be_mult;

% convert 26Al concentrations according to standards
for i = 1:numel(samplein.N26);
    al_mult(i,1) = al_be_consts.al_stds_cfs(strcmp(samplein.al_stds(i),al_be_consts.al_stds_names));
end;
samplein.N26 = samplein.N26 .* al_mult;
samplein.delN26 = samplein.delN26 .* al_mult;

% fix erosion rate unit (mm/ka -> cm/yr)
samplein.E = samplein.E .* 1E-4;

% initial Lsp for simple age calculation
Lsp1 = al_be_consts.Lsp;

% define output cell arrays
output10 = cell(1,4);
output26 = cell(1,4);

% pick out samples one by one
for i = 1:numel(samplein.lat);
    sample.sample_name = samplein.sample_name(i,:);
    sample.lat = samplein.lat(i);
    sample.long = samplein.long(i);
    sample.elv = samplein.elv(i);
    sample.aa = samplein.aa(i,:);
    sample.thick = samplein.thick(i);
    sample.rho = samplein.rho(i);
    sample.othercorr = samplein.othercorr(i);
    sample.E = samplein.E(i);
    sample.N10 = samplein.N10(i);
    sample.delN10 = samplein.delN10(i);
    sample.be_stds = samplein.be_stds(i,:);
    sample.N26 = samplein.N26(i);
    sample.delN26 = samplein.delN26(i);
    sample.al_stds = samplein.al_stds(i,:);
    sample.samplingyr = samplein.samplingyr(i);
    sample.age1 = samplein.age1(i);
    sample.age2 = samplein.age2(i);
    sample.age3 = samplein.age3(i);
    
    % write sample name to output
    output(i,1) = sample.sample_name;
    output10(i,1) = {[]};
    output26(i,1) = {[]};
    
    % fix nucl10 and nucl26
    nucl10 = 0; nucl26 = 0;
    if (sample.N10 + sample.delN10) > 0; nucl10 = 1; end;
    if (sample.N26 + sample.delN26) > 0; nucl26 = 1; end;
    
    % if any 10 or 26 measurement
    if sample.N10 + sample.delN10 + sample.N26 + sample.delN26 > 0;
        fprintf(1,'%.0f. %s',i,sample.sample_name{1});
        
        % define sample site atmospheric pressure
        if (strcmp(sample.aa,'std'));
            sample.pressure = ERA40atm(sample.lat,sample.long,sample.elv);
        elseif (strcmp(sample.aa,'ant'));
            sample.pressure = antatm(sample.elv);
        elseif (strcmp(sample.aa,'pre'));
            sample.pressure = sample.elv;
        end;
        
        % define starting point
        mt = sample.age1 + 2010 - sample.samplingyr;
        
        % catch for negative longitudes before Rc interpolation
        if sample.long < 0; sample.long = sample.long + 360;end;
        
        % Age Relative to t0=2010 - LSD tv from LSDfix
        % tv = [0:10:50 60:100:50060 51060:1000:2000060 logspace(log10(2001060),7,200)];
        
        % Fix w,Rc,SPhi, for sp and mu prod rate scaling
        LSDfix = LSD_fix(sample.lat,sample.long,mt,-1,consts);
        
        % time vector tv0
        tv0 = LSDfix.tv;

        % adjust tv, Rc, and SPhi to sampling year
        if sample.samplingyr <= 2010;
            clipidx = min(find(tv0 > 2010-sample.samplingyr));
            tv = [2010-sample.samplingyr tv0(clipidx:end)];
            Rc = interp1(tv0,LSDfix.Rc,tv);
            SPhi = interp1(tv0,LSDfix.SPhi,tv);
            tv = tv - 2010 + sample.samplingyr;
        else; % assume 2010 value for all years >2010
            Rc = [LSDfix.Rc(1) LSDfix.Rc];
            SPhi = [LSDfix.SPhi(1) LSDfix.SPhi];
            tv = [0 (tv0 + sample.samplingyr - 2010)];
        end;
        
        % split up tv, Rc, Sphi to periods 1 and 2
        clipidx1 = min(find(tv > sample.age2));
        tv1 = [sample.age2 tv(clipidx1:end)];
        Rc1 = interp1(tv,Rc,tv1);
        Sphi1 = interp1(tv,SPhi,tv1);
        clipidx2 = max(find(tv < sample.age3));
        tv2 = [tv(1:clipidx2) sample.age3];
        Rc2 = interp1(tv,Rc,tv2);
        Sphi2 = interp1(tv,SPhi,tv2);
        
        % Production from muons
        dv = linspace(0,maxd,dpoints); % depth vector
        if sample.E > 0;
            dv = [dv (maxd + (sample.age1-sample.age2+sample.age3).*sample.E)];
        end;
        P_mu = P_mu_LSD((dv+sample.thick./2).*sample.rho,sample.pressure,LSDfix.RcEst,...
            consts.SPhiInf,nucl10,nucl26,consts,'no');
        
        % Production from spallation
        LSDnu = LSDspal(sample.pressure,Rc,SPhi,LSDfix.w,nucl10,nucl26,consts);
        
        % interpolate Lsp using CRONUScalc method (Sato 2008; Marrero et al. 2016)
        Lsp1 = rawattenuationlength(sample.pressure,Rc1);
        Lsp2 = rawattenuationlength(sample.pressure,Rc2);
        
        % Thickness scaling factor.
        if sample.thick > 0;
            thickSF1 = thickness(sample.thick,Lsp1,sample.rho);
            thickSF2 = thickness(sample.thick,Lsp2,sample.rho);
        else
            thickSF1 = 1; thickSF2 = 1;
        end;
        
        % spallation depth dependence
        dpfs2 = exp(-tv2.*sample.E.*sample.rho./Lsp2);
        
        % erosion depth vector for tv2
        edv2 = tv2 .* sample.E;
        
        % erosion depth vector for tv1
        edv1 = (tv1-min(tv1)).*sample.E + sample.age3.*sample.E;
        
        % depth matrix for tv1 including all possible erosion
        dm1 = bsxfun(@plus,edv1',linspace(0,maxd,dpoints));
        
        % spallation depth dependence matrix for tv1
        dpfs1m = exp(-dm1.*repmat(sample.rho./Lsp1',1,dpoints));
    end;
    
    % if 10Be is measured
    if nucl10 == 1;
        % calculate N produced over tv2
        mu2_10 = interp1(dv,P_mu.Be,edv2,'pchip') .* sample.othercorr; % P_mu over tv2
        sp2_10 = interp1(tv,LSDnu.Be,tv2).*Pref10.*thickSF2.*sample.othercorr; % P_sp over tv2
        
        % Calculate N(t) including decay and erosion
        dcf2_10 = exp(-tv2.*l10); % decay factor;
        N2_10 = trapz(tv2,(sp2_10.*dcf2_10.*dpfs2 + mu2_10.*dcf2_10)); % N from tv2
        
        N1_10 = sample.N10 - N2_10; % N10 produced over tv1
        minN10 = N1_10 - sample.delN10; % min N10 produced over tv1 including unc
        maxN10 = N1_10 + sample.delN10; % max N10 produced over tv1 including unc
        
        % muon production matrix
        mu1m_10 = interp1(dv,P_mu.Be,dm1);
        
        % spallation production
        sp1_10 = interp1(tv,LSDnu.Be,tv1).*Pref10.*thickSF1.*sample.othercorr; % P_sp over tv1
        sp1m_10 = repmat(sp1_10',1,dpoints); % spal prod matrix
        
        % Calculate N(t) including decay and erosion
        dcf1m_10 = repmat(exp(-tv1.*l10)',1,dpoints); % decay factor;
        N1_10sim = trapz(tv1',(sp1m_10.*dcf1m_10.*dpfs1m + mu1m_10.*dcf1m_10)); % N from tv1
        
        if minN10 < min(N1_10sim); % if too low measured N10
            if maxN10 >= min(N1_10sim); % if some overlap within uncertainty
                d10 = interp1(N1_10sim,linspace(0,maxd,dpoints),maxN10); % min erosion (cm)
            else; % no overlap within uncertainty
                d10 = maxd; % min erosion set to maxd
            end;
            % write min erosion to output
            output10(i,1) = strcat('>',num2str(d10,'%.0f'));
            fprintf(1,'   10Be: %s cm',output10{i,1});
            if d10 == maxd;
                fprintf(1,' (max depth!)');
            end;
            % if age2 > age3 (erosion rate possible)
            if (sample.age2-sample.age3) > 0; % erosion rate based on d10
                E10 = d10/(sample.age2-sample.age3)*1E4; % calculate erosion rate (mm/ka)
                output10(i,3) = strcat('>',num2str(E10,'%.0f'));
                fprintf(1,' | %s mm/ka',output10{i,3});
            end;
        elseif maxN10 > max(N1_10sim); % if too much prior exposure
            if minN10 <= max(N1_10sim); % if some overlap within uncertainty
                d10 = interp1(N1_10sim,linspace(0,maxd,dpoints),minN10); % max erosion (cm)
                output10(i,1) = strcat('<',num2str(d10,'%.0f'));
                fprintf(1,'   10Be: %s cm',output10{i,1});
            else; % no overlap within uncertainty
                d10 = 0; % erosion set to 0
                output10(i,1) = '0';
                fprintf(1,'   10Be = 0 cm (too much 10Be!)');
            end;
            % if age2 > age3 (erosion rate possible)
            if (sample.age2-sample.age3) > 0; % erosion rate based on d10
                E10 = d10/(sample.age2-sample.age3)*1E4; % calculate erosion rate (mm/ka)
                if d10 > 0;
                    output10(i,3) = strcat('<',num2str(E10,'%.0f'));
                    fprintf(1,' | %s mm/ka',output10{i,3});
                else;
                    output10(i,3) = '0';
                end;
            end;
        else; % N10 ± unc fits in N1_10sim
            % interpolate depth from N1_10 and N1_10sim
            d10 = interp1(N1_10sim,linspace(0,maxd,dpoints),N1_10); % depth of erosion (cm)
            output10(i,1) = num2str(d10,'%.0f');
            
            % uncertainty estimation: interpolate conc minus/plus delN to get +/-unc
            maxdeld10 = interp1(N1_10sim,linspace(0,maxd,dpoints),minN10)-d10; % max unc
            mindeld10 = d10-interp1(N1_10sim,linspace(0,maxd,dpoints),maxN10); % min unc
            % pick max of +/-unc (conservative approach) and add prod rate uncertainty
            deld10 = sqrt((max(maxdeld10,mindeld10))^2 + (d10*delPref10/Pref10)^2);
            output10(i,2) = num2str(deld10,'%.0f');
            
            % display E depth
            fprintf(1,'   10Be = %s ± %s cm',output10{i,1},output10{i,2});
            
            % if age2 > age3 (erosion rate possible)
            if (sample.age2-sample.age3) > 0;
                E10 = d10/(sample.age2-sample.age3)*1E4; % erosion rate (mm/ka)
                output10(i,3) = num2str(E10,'%.0f');
                % uncertainty from deld10
                delE10 = deld10/(sample.age2-sample.age3)*1E4; % erosion rate unc (mm/ka)
                output10(i,4) = num2str(delE10,'%.0f');
                % display E rate
                fprintf(1,' | %s ± %s mm/ka',output10{i,3},output10{i,4});
            end;
        end;    
    end;
    
    % if 26Al is measured
    if nucl26 == 1;
        % calculate N produced over tv2
        mu2_26 = interp1(dv,P_mu.Al,edv2,'pchip') .* sample.othercorr; % P_mu over tv2
        sp2_26 = interp1(tv,LSDnu.Al,tv2).*Pref26.*thickSF2.*sample.othercorr; % P_sp over tv2
        
        % Calculate N(t) including decay and erosion
        dcf2_26 = exp(-tv2.*l26); % decay factor;
        N2_26 = trapz(tv2,(sp2_26.*dcf2_26.*dpfs2 + mu2_26.*dcf2_26)); % N from tv2
        
        N1_26 = sample.N26 - N2_26; % N26 produced over tv1
        minN26 = N1_26 - sample.delN26; % min N26 produced over tv1 including unc
        maxN26 = N1_26 + sample.delN26; % max N26 produced over tv1 including unc
        
        % muon production matrix
        mu1m_26 = interp1(dv,P_mu.Al,dm1);
        
        % spallation production
        sp1_26 = interp1(tv,LSDnu.Al,tv1).*Pref26.*thickSF1.*sample.othercorr; % P_sp over tv1
        sp1m_26 = repmat(sp1_26',1,dpoints); % spal prod matrix
        
        % Calculate N(t) including decay and erosion
        dcf1m_26 = repmat(exp(-tv1.*l26)',1,dpoints); % decay factor;
        N1_26sim = trapz(tv1',(sp1m_26.*dcf1m_26.*dpfs1m + mu1m_26.*dcf1m_26)); % N from tv1
        
        if minN26 < min(N1_26sim); % if too low measured N26
            if maxN26 >= min(N1_26sim); % if some overlap within uncertainty
                d26 = interp1(N1_26sim,linspace(0,maxd,dpoints),maxN26); % min erosion (cm)
            else; % no overlap within uncertainty
                d26 = maxd; % min erosion set to maxd
            end;
            % write min erosion to output
            output26(i,1) = strcat('>',num2str(d26,'%.0f'));
            fprintf(1,'   26Al: %s cm',output26{i,1});
            if d26 == maxd;
                fprintf(1,' (max depth!)');
            end;
            % if age2 > age3 (erosion rate possible)
            if (sample.age2-sample.age3) > 0; % erosion rate based on d26
                E26 = d26/(sample.age2-sample.age3)*1E4; % calculate erosion rate (mm/ka)
                output26(i,3) = strcat('>',num2str(E26,'%.0f'));
                fprintf(1,' | %s mm/ka',output26{i,3});
            end;
        elseif maxN26 > max(N1_26sim); % if too much prior exposure
            if minN26 <= max(N1_26sim); % if some overlap within uncertainty
                d26 = interp1(N1_26sim,linspace(0,maxd,dpoints),minN26); % max erosion (cm)
                output26(i,1) = strcat('<',num2str(d26,'%.0f'));
                fprintf(1,'   26Al: %s cm',output26{i,1});
            else; % no overlap within uncertainty
                d26 = 0; % erosion set to 0
                output26(i,1) = '0';
                fprintf(1,'   26Al = 0 cm (too much 26Al!)');
            end;
            % if age2 > age3 (erosion rate possible)
            if (sample.age2-sample.age3) > 0; % erosion rate based on d26
                E26 = d26/(sample.age2-sample.age3)*1E4; % calculate erosion rate (mm/ka)
                if d26 > 0;
                    output26(i,3) = strcat('<',num2str(E26,'%.0f'));
                    fprintf(1,' | %s mm/ka',output26{i,3});
                else;
                    output26(i,3) = '0';
                end;
            end;
        else; % N26 ± unc fits in N1_26sim
            % interpolate depth from N1_26 and N1_26sim
            d26 = interp1(N1_26sim,linspace(0,maxd,dpoints),N1_26); % depth of erosion (cm)
            output26(i,1) = num2str(d26,'%.0f');
            
            % uncertainty estimation: interpolate conc minus/plus delN to get +/-unc
            maxdeld26 = interp1(N1_26sim,linspace(0,maxd,dpoints),minN26)-d26; % max unc
            mindeld26 = d26-interp1(N1_26sim,linspace(0,maxd,dpoints),maxN26); % min unc
            % pick max of +/-unc (conservative approach) and add prod rate uncertainty
            deld26 = sqrt((max(maxdeld26,mindeld26))^2 + (d26*delPref26/Pref26)^2);
            output26(i,2) = num2str(deld26,'%.0f');
            
            % display E depth
            fprintf(1,'   26Al = %s ± %s cm',output26{i,1},output26{i,2});
            
            % if age2 > age3 (erosion rate possible)
            if (sample.age2-sample.age3) > 0;
                E26 = d26/(sample.age2-sample.age3)*1E4; % erosion rate (mm/ka)
                output26(i,3) = num2str(E26,'%.0f');
                % uncertainty from deld26
                delE26 = deld26/(sample.age2-sample.age3)*1E4; % erosion rate unc (mm/ka)
                output26(i,4) = num2str(delE26,'%.0f');
                % display E rate
                fprintf(1,' | %s ± %s mm/ka',output26{i,3},output26{i,4});
            end;
        end;    
    end;
    
    if nucl10+nucl26 > 0;
        fprintf(1,'\n');
    end;
    clear sample;
end;

% fix and save output ==============================================================================
% fix header and output string
outhead(1,1) = {'sample'};
outstr = '%s\t%s\t%s\t%s\t%s\n';
if sum(samplein.N10 + samplein.delN10)>0; % if any 10Be
    output(:,end+1:end+4) = output10;
    outhead(1,end+1:end+4) = {'10Edepth(cm)','10unc(cm)','10Erate(mm/ka)','10unc(mm/ka)'};
end;
if sum(samplein.N26 + samplein.delN26)>0; % if any 26Al
    output(:,end+1:end+4) = output26;
    outhead(1,end+1:end+4) = {'26Edepth(cm)','26unc(cm)','26Erate(mm/ka)','26unc(mm/ka)'};
end;
if sum(samplein.N10+samplein.delN10)>0 && sum(samplein.N26+samplein.delN26)>0; % if both 10 and 26
    outstr = '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n';
end;

% add headers
output(2:end+1,:) = output;
output(1,:) = outhead;

% fill empty cells with '-'
nullidx = cellfun(@isempty,output);
output(nullidx) = '-';

% write out-preexpE.txt
if sum(samplein.N10 + samplein.delN10 + samplein.N26 + samplein.delN26)>0;
    out = fopen('out-preexpE.txt','w');
    for i = 1:rows(output);
        fprintf(out,outstr,output{i,:});
    end;
    fclose(out);
end;

toc()
