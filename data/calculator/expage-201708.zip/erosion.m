% Wrapper script for 10Be and 26Al erosion rate calculator.
% Read and fix input, use get_al_be_erosion to calculate erosion rates, and fix and write output.
% This is free software: you can use/copy/modify/distribute as long as you keep it free.
% Jakob Heyman - 2015-2017 (jakob.heyman@gu.se)

clear all;

tic();

% What version is this?
ver = '201702';

% read input file
[samplein.sample_name,samplein.lat,samplein.long,samplein.elv,samplein.aa,samplein.thick,...
    samplein.rho,samplein.othercorr,samplein.N10,samplein.delN10,samplein.be_stds,samplein.N26,...
    samplein.delN26,samplein.al_stds,samplein.samplingyr] = ...
    textread('input.txt','%s %n %n %n %s %n %n %n %n %n %s %n %n %s %n');

% run and load al_be constants
make_al_be_consts;
load al_be_consts;

% run and load LSD consts
make_consts_LSD;
load consts_LSD;

% convert 10Be concentrations according to standards
for i = 1:numel(samplein.N10);
    be_mult(i,1) = al_be_consts.be_stds_cfs(strcmp(samplein.be_stds(i),al_be_consts.be_stds_names));
end;
samplein.N10 = samplein.N10 .* be_mult;
samplein.delN10 = samplein.delN10 .* be_mult;

% convert 26Al concentrations according to standards
for i = 1:numel(samplein.N26);
    al_mult(i,1) = al_be_consts.al_stds_cfs(strcmp(samplein.al_stds(i),al_be_consts.al_stds_names));
end;
samplein.N26 = samplein.N26 .* al_mult;
samplein.delN26 = samplein.delN26 .* al_mult;

% define output cell arrays
output10 = cell();
output26 = cell();

% pick out samples one by one
for i = 1:numel(samplein.lat);
    sample.sample_name = samplein.sample_name(i);
    sample.lat = samplein.lat(i);
    sample.long = samplein.long(i);
    sample.elv = samplein.elv(i);
    sample.aa = samplein.aa(i);
    sample.thick = samplein.thick(i);
    sample.rho = samplein.rho(i);
    sample.othercorr = samplein.othercorr(i);
    sample.N10 = samplein.N10(i);
    sample.delN10 = samplein.delN10(i);
    sample.be_stds = samplein.be_stds(i);
    sample.N26 = samplein.N26(i);
    sample.delN26 = samplein.delN26(i);
    sample.al_stds = samplein.al_stds(i);
    sample.samplingyr = samplein.samplingyr(i);
    
    % write sample name to output
    output(i,1) = sample.sample_name;
    output10(i,1) = {[]};
    output26(i,1) = {[]};
    
    if sample.N10 + sample.N26 > 0;
        fprintf(1,'%.0f. %s',i,sample.sample_name{1});
        
        % define sample site atmospheric pressure
        if (strcmp(sample.aa,'std'));
            sample.pressure = ERA40atm(sample.lat,sample.long,sample.elv);
        elseif (strcmp(sample.aa,'ant'));
            sample.pressure = antatm(sample.elv);
        elseif (strcmp(sample.aa,'pre'));
            sample.pressure = sample.elv;
        end;
        
        % catch for negative longitudes before Rc interpolation
        if sample.long < 0; sample.long = sample.long + 360; end;
        
        results = get_al_be_erosion(sample,al_be_consts,consts);
        
        % report
        if sample.N10 > 0;
            if results.delE_ext10 >= 0; % if normal erosion rate
                output10(i,1) = num2str(results.EmMyr10,'%.3f');
                output10(i,2) = num2str(results.delE_ext10,'%.3f');
                output10(i,3) = num2str(results.delE_int10,'%.3f');
                fprintf(1,' \t10Be = %s ± %s mm/ka',output10{i,1},output10{i,2});
            elseif results.delE_ext10 == -2; % if fully saturated
                output10(i,1) = '0';
                output10(i,2) = '-';
                output10(i,3) = '-';
                fprintf(1,' \t10Be = 0 mm/ka (saturated)');
            else; % if one-sided saturated
                output10(i,1) = strcat('<',num2str(results.EmMyr10,'%.3f'));
                output10(i,2) = '-';
                output10(i,3) = '-';
                fprintf(1,' \t10Be: %s mm/ka (one-sided saturated)',output10{i,1});
            end;
        end;
        if sample.N26 > 0;
            if results.delE_ext26 >= 0; % if normal erosion rate
                output26(i,1) = num2str(results.EmMyr26,'%.3f');
                output26(i,2) = num2str(results.delE_ext26,'%.3f');
                output26(i,3) = num2str(results.delE_int26,'%.3f');
                fprintf(1,' \t26Al = %s ± %s mm/ka',output26{i,1},output26{i,2});
            elseif results.delE_ext26 == -2; % if fully saturated
                output26(i,1) = '0';
                output26(i,2) = '-';
                output26(i,3) = '-';
                fprintf(1,' \t26Al = 0 mm/ka (saturated)');
            else; % if one-sided saturated
                output26(i,1) = strcat('<',num2str(results.EmMyr26,'%.3f'));
                output26(i,2) = '-';
                output26(i,3) = '-';
                fprintf(1,' \t26Al: %s mm/ka (one-sided saturated)',output26{i,1});
            end;
        end;
        fprintf(1,'\n');
    end;
    clear sample;
end;

% fix and save output ==============================================================================
% fix header and output string
outhead(1,1) = {'sample'};
outstr = '%s\t%s\t%s\t%s\n';
if sum(samplein.N10) > 0; % if any 10Be
    output(:,end+1:end+3) = output10;
    outhead(1,end+1:end+3) = {'10Erate(mm/ka)','10uncext(mm/ka)','10uncint(mm/ka)'};
end;
if sum(samplein.N26) > 0; % if any 26Al
    output(:,end+1:end+3) = output26;
    outhead(1,end+1:end+3) = {'26Erate(mm/ka)','26uncext(mm/ka)','26uncint(mm/ka)'};
end;
if sum(samplein.N10)>0 && sum(samplein.N26)>0; % if both 10 and 26
    outstr = '%s\t%s\t%s\t%s\t%s\t%s\t%s\n';
end;

% add headers
output(2:end+1,:) = output;
output(1,:) = outhead;

% fill empty cells with '-'
nullidx = cellfun(@isempty,output);
output(nullidx) = '-';

% write out-erosion.txt
if sum(samplein.N10 + samplein.N26) > 0;
    out = fopen('out-erosion.txt','w');
    for i = 1:rows(output);
        fprintf(out,outstr,output{i,:});
    end;
    fclose(out);
end;

toc()
